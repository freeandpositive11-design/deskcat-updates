/* Desk Cat – Electron main process */
const { app, BrowserWindow, Tray, Menu, screen, ipcMain, globalShortcut, nativeImage, shell, Notification, powerMonitor, dialog } = require('electron');
const APP_VERSION = require('./package.json').version;
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const { Store } = require('./store');
const I18N = require('./i18n');

const isMac = process.platform === 'darwin';
const isWin = process.platform === 'win32';
const SHORTCUT = 'Control+Shift+M';

let store, catWin = null, settingsWin = null, tray = null;
let reminderTimer = null;
const fired = new Map();          // reminder id -> last fire marker
let lastScheduledWork = null;     // for schedule transitions
const startedAt = Date.now();

app.setAppUserModelId('sk.deskcat.app');

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => openSettings());
}

/* ---------------- pets ---------------- */

function userPetsDir() { return path.join(app.getPath('userData'), 'pets'); }

function listPets() {
  const out = [];
  const dirs = [[path.join(__dirname, 'pets'), true], [userPetsDir(), false]];
  for (const [dir, builtIn] of dirs) {
    let entries = [];
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { continue; }
    for (const e of entries) {
      if (!e.isDirectory()) continue;
      const petDir = path.join(dir, e.name);
      try {
        const meta = JSON.parse(fs.readFileSync(path.join(petDir, 'pet.json'), 'utf8'));
        out.push({ id: e.name, name: meta.name || e.name, dir: petDir, builtIn, meta, baseUrl: pathToFileURL(petDir + path.sep).href });
      } catch (err) { /* skip broken pet */ }
    }
  }
  return out;
}

function currentPet() {
  const pets = listPets();
  return pets.find((p) => p.id === store.get('pet')) || pets[0];
}

function petPayload(p) { return p ? { id: p.id, name: p.name, meta: p.meta, baseUrl: p.baseUrl, builtIn: !!p.builtIn } : null; }

/* ---------------- cat window ---------------- */

function workArea() { return screen.getPrimaryDisplay().workArea; }

function createCatWindow() {
  const wa = workArea();
  catWin = new BrowserWindow({
    x: wa.x, y: wa.y, width: wa.width, height: wa.height,
    transparent: true, frame: false, alwaysOnTop: true, skipTaskbar: true, hasShadow: false,
    resizable: false, movable: false, minimizable: false, maximizable: false, fullscreenable: false,
    focusable: false, acceptFirstMouse: true, show: false, title: 'Desk Cat',
    backgroundColor: '#00000000',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, backgroundThrottling: false, autoplayPolicy: 'no-user-gesture-required'
    }
  });
  catWin.setAlwaysOnTop(true, isMac ? 'floating' : 'screen-saver');
  if (isMac) catWin.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: false });
  catWin.setIgnoreMouseEvents(true, { forward: true });
  catWin.setMenuBarVisibility(false);
  catWin.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  catWin.once('ready-to-show', () => { if (!store.get('hidden')) catWin.showInactive(); });
  catWin.on('closed', () => { catWin = null; });
  catWin.webContents.on('did-finish-load', () => sendEngineSettings());
}

function fitToWorkArea() {
  if (!catWin) return;
  const wa = workArea();
  catWin.setBounds({ x: wa.x, y: wa.y, width: wa.width, height: wa.height });
}

function sendToCat(channel, ...args) { if (catWin && !catWin.isDestroyed()) catWin.webContents.send(channel, ...args); }
function sendEngineSettings() { sendToCat('cat:settings', store.engineSettings()); }

function setHidden(hidden) {
  store.set({ hidden });
  if (!catWin) return;
  if (hidden) catWin.hide(); else { catWin.showInactive(); fitToWorkArea(); }
  buildTray();
}

function setWorkMode(on) {
  store.set({ workMode: !!on });
  sendEngineSettings();
  buildTray();
  if (settingsWin) settingsWin.webContents.send('settings:changed', store.get());
}

/* ---------------- reminders ---------------- */

function hhmm(d) { return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }

function deliverReminder(r) {
  if (isQuiet() && !r.important && !r.force) return;        // quiet hours: only important ones
  const payload = { id: r.id, text: r.text, important: !!r.important, action: r.action || 'none' };
  if (store.get('hidden')) {
    if (r.important && Notification.isSupported()) {
      new Notification({ title: currentPet()?.name || 'Desk Cat', body: r.text }).show();
    }
    return;
  }
  sendToCat('cat:remind', payload);
}

let workSeconds = 0, workStart = 0, lastTick = Date.now(), onBreak = false;
const statsFile = () => path.join(app.getPath('userData'), 'stats.json');
let stats = null;
function todayKey() { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function loadStats() { if (stats) return stats; try { stats = JSON.parse(fs.readFileSync(statsFile(), 'utf8')); } catch (e) { stats = {}; } return stats; }
function today() { const st = loadStats(); const k = todayKey(); return (st[k] = st[k] || { work: 0, breaks: 0, pomodoros: 0 }); }
let statsDirty = 0;
function saveStats() { try { fs.writeFileSync(statsFile(), JSON.stringify(loadStats())); } catch (e) { /* ignore */ } }
function trackWork() {
  // keyboard/mouse activity is read from the system idle time (no key logging)
  const now = Date.now();
  const dt = Math.min(60, (now - lastTick) / 1000); lastTick = now;
  let idle = 0;
  try { idle = powerMonitor.getSystemIdleTime(); } catch (e) { idle = 0; }
  const t = today();
  if (idle < 120) {
    if (workSeconds === 0) workStart = now;
    workSeconds += dt; t.work += dt; onBreak = false;
  } else if (idle >= 300) {
    if (workSeconds > 0 && !onBreak) { onBreak = true; t.breaks += 1; }
    workSeconds = 0;
  }
  if (++statsDirty >= 8) { statsDirty = 0; saveStats(); }
}

function inRange(t, from, to) { return from <= to ? (t >= from && t < to) : (t >= from || t < to); }
let lastQuiet = null;
function isQuiet() {
  const q = store.get('quiet');
  return !!(q && q.enabled && inRange(hhmm(new Date()), q.from || '21:00', q.to || '08:00'));
}

/* pomodoro: the main process keeps the clock, the cat shows it and brings the break */
let pomo = null;   // { phase: 'work'|'break', endsAt }
function pomodoroStart() {
  const p = store.get('pomodoro') || {};
  pomo = { phase: 'work', endsAt: Date.now() + Math.max(1, Number(p.work) || 25) * 60000 };
  sendPomodoro(); buildTray();
}
function pomodoroStop() { pomo = null; sendPomodoro(); buildTray(); }
function sendPomodoro() { sendToCat('cat:pomodoro', pomo ? { phase: pomo.phase, endsAt: pomo.endsAt } : null); }
function tickPomodoro() {
  if (!pomo) return;
  if (Date.now() < pomo.endsAt) return;
  const P = I18N.get(store.get('lang')).pomodoro;
  const p = store.get('pomodoro') || {};
  if (pomo.phase === 'work') {
    today().pomodoros += 1; saveStats();
    pomo = { phase: 'break', endsAt: Date.now() + Math.max(1, Number(p.brk) || 5) * 60000 };
    deliverReminder({ id: 'pomo-work', text: P.workEnd, important: false, action: 'come', force: true });
  } else {
    pomo = { phase: 'work', endsAt: Date.now() + Math.max(1, Number(p.work) || 25) * 60000 };
    deliverReminder({ id: 'pomo-break', text: P.breakEnd, important: false, action: 'hop', force: true });
  }
  sendPomodoro();
}

function summaryText() {
  const t = today();
  const W = I18N.get(store.get('lang')).summaryWords;
  const mins = Math.round(t.work / 60), h = Math.floor(mins / 60), m = mins % 60;
  const br = t.breaks === 1 ? W.breaks[0] : (t.breaks >= 2 && t.breaks <= 4 ? W.breaks[1] : W.breaks[2]);
  return `${W.today}: ${h ? h + ' h ' : ''}${m} min ${W.work}, ${t.breaks} ${br}${t.pomodoros ? ', ' + t.pomodoros + ' ' + W.pomo : ''}.`;
}
function tellSummary() { if (store.get('hidden')) setHidden(false); sendToCat('cat:remind', { id: 'summary', text: summaryText(), important: false, action: 'sit', ms: 15000 }); }
let summaryFired = '';

function checkReminders() {
  trackWork();
  tickPomodoro();
  const q = isQuiet();
  if (q !== lastQuiet) { lastQuiet = q; sendToCat('cat:quiet', q); }
  const now = new Date();
  const sm = store.get('summary');
  if (sm && sm.enabled && sm.at === hhmm(now) && summaryFired !== now.toDateString()) { summaryFired = now.toDateString(); tellSummary(); }
  const key = now.toDateString() + ' ' + hhmm(now);
  const day = now.getDay();
  for (const r of store.get('reminders') || []) {
    if (!r.enabled || !r.text) continue;
    if (r.kind === 'time') {
      if (Array.isArray(r.days) && r.days.length && !r.days.includes(day)) continue;
      if (r.at === hhmm(now) && fired.get(r.id) !== key) { fired.set(r.id, key); deliverReminder(r); }
    } else if (r.kind === 'work') {
      // after N minutes of working without a real break (a break = 5 minutes without keyboard/mouse activity)
      const need = Math.max(5, Number(r.every) || 50) * 60;
      if (workSeconds >= need && (fired.get(r.id) || 0) < workStart) { fired.set(r.id, now.getTime()); deliverReminder(r); }
    } else {
      const every = Math.max(1, Number(r.every) || 30) * 60000;
      const last = fired.get(r.id) || startedAt;
      if (now.getTime() - last >= every) { fired.set(r.id, now.getTime()); deliverReminder(r); }
    }
  }
  // work mode schedule (acts only on transitions so a manual toggle sticks until the next change)
  const sch = store.get('workSchedule');
  if (sch && sch.enabled) {
    const t = hhmm(now);
    const inDays = !sch.days || !sch.days.length || sch.days.includes(day);
    const active = inDays && (sch.from <= sch.to ? (t >= sch.from && t < sch.to) : (t >= sch.from || t < sch.to));
    if (lastScheduledWork === null) lastScheduledWork = active;
    if (active !== lastScheduledWork) { lastScheduledWork = active; if (store.get('workMode') !== active) setWorkMode(active); }
  } else {
    lastScheduledWork = null;
  }
}

/* ---------------- tray & menus ---------------- */

function trayIcon() {
  const file = isMac ? 'tray.png' : 'tray-win.png';
  const img = nativeImage.createFromPath(path.join(__dirname, 'assets', file));
  return img;
}

/* While a menu is open (and a moment after) the global click watcher ignores the mouse: the click that picks
   "Pet her" or "Go to sleep" would otherwise also count as a click on the desktop and send the cat there. */
let menuOpen = false, menuOpenedAt = 0, menuClosedAt = 0;
function watchMenu(menu) {
  menu.on('menu-will-show', () => { menuOpen = true; menuOpenedAt = Date.now(); });
  menu.on('menu-will-close', () => { menuOpen = false; menuClosedAt = Date.now(); });
  return menu;
}
function menuClick() {
  if (menuOpen && Date.now() - menuOpenedAt > 60000) menuOpen = false;     // never stuck if a close went unnoticed
  return menuOpen || Date.now() - menuClosedAt < 900;
}

function buildTray() {
  const T = I18N.get(store.get('lang')).tray;
  const pet = currentPet();
  if (!tray) {
    tray = new Tray(trayIcon());
    tray.on('click', () => { if (!isMac) tray.popUpContextMenu(); });
  }
  tray.setToolTip(pet ? pet.name : 'Desk Cat');
  const upd = updater && updater.state.status === 'available' ? updater.state.latest : null;
  const menu = Menu.buildFromTemplate([
    { label: pet ? pet.name : 'Desk Cat', enabled: false },
    ...(upd ? [{ label: T.updateInstall.replace('{v}', upd), click: () => { openSettings('general'); updater.install(); } }] : []),
    { type: 'separator' },
    { label: store.get('hidden') ? T.show : T.hide, click: () => setHidden(!store.get('hidden')) },
    { label: T.work, type: 'checkbox', checked: !!store.get('workMode'), click: (mi) => setWorkMode(mi.checked) },
    { label: T.mode, submenu: ['spontaneous', 'click', 'hunt'].map((m) => ({ label: T.modes[m], type: 'radio', checked: store.get('mode') === m, click: () => setMode(m) })) },
    { label: T.callHere, click: () => { const p = screen.getCursorScreenPoint(); const wa = workArea(); sendToCat('cat:call', p.x - wa.x); } },
    { label: T.sleep, click: () => sendToCat('cat:sleep') },
    { type: 'separator' },
    { label: pomo ? T.pomoStop : T.pomoStart, click: () => (pomo ? pomodoroStop() : pomodoroStart()) },
    { label: T.summary, click: () => tellSummary() },
    { type: 'separator' },
    { label: T.reminders, click: () => openSettings('reminders') },
    { label: T.settings, click: () => openSettings() },
    { label: T.launch, type: 'checkbox', checked: !!store.get('launchAtLogin'), click: (mi) => applyLaunchAtLogin(mi.checked) },
    { type: 'separator' },
    { label: T.shortcut, enabled: false },
    { label: T.quit, click: () => { app.isQuitting = true; saveStats(); app.quit(); } }
  ]);
  tray.setContextMenu(watchMenu(menu));
}

function catContextMenu(pos) {
  const C = I18N.get(store.get('lang')).ctx;
  const T = I18N.get(store.get('lang')).tray;
  const menu = Menu.buildFromTemplate([
    { label: C.pet, click: () => sendToCat('cat:pet-action') },
    { label: C.sleep, click: () => sendToCat('cat:sleep') },
    { label: C.wake, click: () => sendToCat('cat:wake') },
    { type: 'separator' },
    { label: C.work, type: 'checkbox', checked: !!store.get('workMode'), click: (mi) => setWorkMode(mi.checked) },
    { label: C.hide, click: () => setHidden(true) },
    { type: 'separator' },
    { label: T.reminders, click: () => openSettings('reminders') },
    { label: C.settings, click: () => openSettings() },
    { label: T.quit, click: () => { app.isQuitting = true; app.quit(); } }
  ]);
  watchMenu(menu);
  menuOpen = true; menuOpenedAt = Date.now();
  menu.popup({ window: catWin || undefined, callback: () => { menuOpen = false; menuClosedAt = Date.now(); } });
}

function applyLaunchAtLogin(on) {
  store.set({ launchAtLogin: !!on });
  try { app.setLoginItemSettings({ openAtLogin: !!on, openAsHidden: true }); } catch (e) { /* unpackaged dev build */ }
  buildTray();
}

/* ---------------- settings window ---------------- */

function openSettings(tab) {
  if (settingsWin) {
    settingsWin.show(); settingsWin.focus();
    if (tab) settingsWin.webContents.send('settings:tab', tab);
    return;
  }
  const S = I18N.get(store.get('lang')).settings;
  settingsWin = new BrowserWindow({
    width: 560, height: 680, minWidth: 480, minHeight: 520, title: S.title, show: false,
    autoHideMenuBar: true, backgroundColor: '#f2f3f6',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  settingsWin.loadFile(path.join(__dirname, 'settings', 'index.html'), { hash: tab || 'cat' });
  settingsWin.once('ready-to-show', () => {
    if (isMac && app.dock) app.dock.show();
    settingsWin.show();
    app.focus({ steal: true });
  });
  settingsWin.on('closed', () => {
    settingsWin = null;
    if (isMac && app.dock) app.dock.hide();
  });
}


/* ---------------- window edges (the cat rubs against windows that reach the floor) ---------------- */

let edgeTimer = null, psProc = null, psQueue = [];

function macWindows() {
  return new Promise((resolve) => {
    const js = "ObjC.import('CoreGraphics');var raw=$.CGWindowListCopyWindowInfo(17,0);var arr=null;" +
      "try{arr=ObjC.deepUnwrap(ObjC.castRefToObject(raw));}catch(e){}if(!arr||!arr.length){try{arr=ObjC.deepUnwrap(raw);}catch(e){}}if(!arr||!arr.length)arr=[];var out=[];" +
      "for(var i=0;i<arr.length;i++){var w=arr[i];if(w.kCGWindowLayer!==0)continue;if((w.kCGWindowAlpha==null?1:w.kCGWindowAlpha)<0.5)continue;var b=w.kCGWindowBounds;if(!b)continue;" +
      "out.push({x:b.X,y:b.Y,w:b.Width,h:b.Height,pid:w.kCGWindowOwnerPID});}JSON.stringify(out);";
    const { execFile } = require('child_process');
    execFile('osascript', ['-l', 'JavaScript', '-e', js], { timeout: 4000 }, (err, stdout) => {
      if (err) return resolve([]);
      try { resolve(JSON.parse(String(stdout).trim())); } catch (e) { resolve([]); }
    });
  });
}

function winWindows() {
  return new Promise((resolve) => {
    if (!psProc) {
      const script = path.join(app.getPath('userData'), 'windows.ps1');
      const src = `Add-Type -TypeDefinition @"
using System; using System.Runtime.InteropServices; using System.Text;
public class DeskCatWin {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr h);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr h, int a, out RECT r, int s);
  [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr h, int a, out int v, int s);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  public static string Get() {
    var sb = new StringBuilder();
    IntPtr fg = GetForegroundWindow();
    EnumWindows(delegate(IntPtr h, IntPtr l) {
      if (!IsWindowVisible(h) || IsIconic(h) || GetWindowTextLength(h) == 0) return true;
      int cloaked = 0; DwmGetWindowAttribute(h, 14, out cloaked, 4); if (cloaked != 0) return true;
      RECT r; if (DwmGetWindowAttribute(h, 9, out r, 16) != 0) GetWindowRect(h, out r);
      uint pid; GetWindowThreadProcessId(h, out pid);
      sb.Append(r.L).Append(',').Append(r.T).Append(',').Append(r.R).Append(',').Append(r.B).Append(',').Append(pid).Append(',').Append(h == fg ? 1 : 0).Append(';');
      return true; }, IntPtr.Zero);
    return sb.ToString();
  }
}
"@
while ($true) { $line = [Console]::In.ReadLine(); if ($line -eq $null) { break }; [Console]::Out.WriteLine([DeskCatWin]::Get()); [Console]::Out.Flush() }
`;
      try { fs.mkdirSync(path.dirname(script), { recursive: true }); fs.writeFileSync(script, src); } catch (e) { return resolve([]); }
      const { spawn } = require('child_process');
      try {
        psProc = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script], { windowsHide: true, stdio: ['pipe', 'pipe', 'ignore'] });
      } catch (e) { psProc = null; return resolve([]); }
      let buf = '';
      psProc.stdout.on('data', (d) => {
        buf += String(d);
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          const cb = psQueue.shift(); if (!cb) continue;
          const sf = screen.getPrimaryDisplay().scaleFactor || 1;
          const out = [];
          for (const part of line.split(';')) {
            const v = part.split(',').map(Number);
            if (v.length < 5 || v.some(isNaN)) continue;
            out.push({ x: v[0] / sf, y: v[1] / sf, w: (v[2] - v[0]) / sf, h: (v[3] - v[1]) / sf, pid: v[4], active: v[5] === 1 });
          }
          cb(out);
        }
      });
      psProc.on('exit', () => { psProc = null; while (psQueue.length) psQueue.shift()([]); });
      psProc.on('error', () => { psProc = null; });
    }
    if (!psProc || !psProc.stdin.writable) return resolve([]);
    psQueue.push(resolve);
    try { psProc.stdin.write('go\n'); } catch (e) { psQueue.pop(); resolve([]); }
    setTimeout(() => { const i = psQueue.indexOf(resolve); if (i >= 0) { psQueue.splice(i, 1); resolve([]); } }, 4000);
  });
}

let lastSeen = { at: 0, windows: 0, edges: 0 };
async function pollEdges() {
  if (!catWin || store.get('hidden')) return;
  let rects = [];
  try { rects = isMac ? await macWindows() : (isWin ? await winWindows() : []); } catch (e) { rects = []; }
  const wa = workArea();
  const floorY = wa.y + wa.height;
  const edges = [];
  for (const r of rects) {
    if (r.pid === process.pid) continue;
    if (!(r.w >= 200 && r.h >= 150)) continue;
    if (r.y + r.h < floorY - 30) continue;     // must reach (nearly) down to the cat's floor
    if (r.y > floorY - 120) continue;          // and not sit entirely below it
    const win = { x: r.x - wa.x, y: r.y - wa.y, w: r.w, h: r.h };
    edges.push({ x: win.x, side: 'left', kind: 'window', win });
    edges.push({ x: win.x + win.w, side: 'right', kind: 'window', win });
  }
  lastSeen = { at: Date.now(), windows: rects.filter((r) => r.pid !== process.pid && r.w >= 200 && r.h >= 120).length, edges: edges.length / 2 };
  sendToCat('cat:edges', edges);
  sendToCat('cat:windows', rects.filter((r) => r.pid !== process.pid && r.w >= 200 && r.h >= 120).map((r) => ({ x: r.x - wa.x, y: r.y - wa.y, w: r.w, h: r.h })));
  if (isMac && store.get('playFolders')) pollIcons();
  pollActive(rects);
}

/* the window being used (for "sits on the window you type in") */
function macActiveWindow() {
  return new Promise((resolve) => {
    const script = 'tell application "System Events" to tell (first process whose frontmost is true) to get {position, size} of front window';
    const { execFile } = require('child_process');
    execFile('osascript', ['-e', script], { timeout: 3000 }, (err, stdout) => {
      if (err) return resolve(null);
      const v = String(stdout).trim().split(',').map((x) => Number(x.trim()));
      resolve(v.length === 4 && v.every(Number.isFinite) ? { x: v[0], y: v[1], w: v[2], h: v[3] } : null);
    });
  });
}
let lastActive = 0;
async function pollActive(rects) {
  if (!store.get('sitActive') || Date.now() - lastActive < 12000) return;
  lastActive = Date.now();
  const wa = workArea();
  let r = null;
  try { r = isMac ? await macActiveWindow() : (rects.find((x) => x.active) || null); } catch (e) { r = null; }
  sendToCat('cat:active', r && r.w >= 200 ? { x: r.x - wa.x, y: r.y - wa.y, w: r.w, h: r.h } : null);
}

/* desktop icons (macOS: Finder tells us where they are; the cat plays with the ones near the floor) */
function macIcons() {
  return new Promise((resolve) => {
    const script = 'tell application "Finder"\nset out to ""\nrepeat with it in (every item of desktop)\ntry\nset p to desktop position of it\nset out to out & (item 1 of p) & "," & (item 2 of p) & ";"\nend try\nend repeat\nout\nend tell';
    const { execFile } = require('child_process');
    execFile('osascript', ['-e', script], { timeout: 4000 }, (err, stdout) => {
      if (err) return resolve([]);
      const out = [];
      for (const part of String(stdout).trim().split(';')) {
        const v = part.split(',').map(Number);
        if (v.length === 2 && v.every((n) => Number.isFinite(n))) out.push({ x: v[0], y: v[1] });
      }
      resolve(out);
    });
  });
}
let lastIcons = 0;
async function pollIcons() {
  if (Date.now() - lastIcons < 30000) return;
  lastIcons = Date.now();
  let pts = [];
  try { pts = await macIcons(); } catch (e) { pts = []; }
  const wa = workArea();
  const S = 64;   // Finder's default icon size; the position is the icon's centre
  sendToCat('cat:icons', pts.map((p) => ({ x: p.x - S / 2 - wa.x, y: p.y - S / 2 - wa.y, w: S, h: S })));
}

function startEdgeWatch() {
  if (edgeTimer) return;
  edgeTimer = setInterval(pollEdges, 6000);
  setTimeout(pollEdges, 2000);
}

/* ---------------- IPC ---------------- */

ipcMain.handle('cat:init', () => ({
  quiet: isQuiet(), pomodoro: pomo ? { phase: pomo.phase, endsAt: pomo.endsAt } : null,
  settings: store.engineSettings(),
  pet: petPayload(currentPet()),
  platform: process.platform
}));
ipcMain.on('cat:interactive', (e, on) => { if (catWin) catWin.setIgnoreMouseEvents(!on, { forward: true }); });
ipcMain.on('cat:contextmenu', (e, pos) => catContextMenu(pos));
ipcMain.on('cat:event', (e, name, data) => { /* reserved for future stats */ });

ipcMain.handle('settings:get', () => ({
  data: store.get(),
  pets: listPets().map(petPayload),
  strings: I18N.get(store.get('lang')),
  version: APP_VERSION,
  platform: process.platform,
  userPetsDir: userPetsDir()
}));

ipcMain.handle('settings:set', (e, partial) => {
  const prevPet = store.get('pet');
  const prevLang = store.get('lang');
  const prevLaunch = store.get('launchAtLogin');
  store.set(partial);
  if (partial.pet && partial.pet !== prevPet) sendToCat('cat:pet', petPayload(currentPet()));
  if (partial.launchAtLogin !== undefined && partial.launchAtLogin !== prevLaunch) applyLaunchAtLogin(partial.launchAtLogin);
  if (partial.hidden !== undefined) setHidden(partial.hidden);
  sendEngineSettings();
  buildTray();
  if (partial.lang && partial.lang !== prevLang && settingsWin) settingsWin.setTitle(I18N.get(partial.lang).settings.title);
  return store.get();
});

ipcMain.on('settings:testReminder', (e, r) => {
  if (store.get('hidden')) setHidden(false);
  sendToCat('cat:remind', { id: 'test', text: r.text || '…', important: !!r.important, action: r.action || 'none' });
});

ipcMain.on('settings:close', () => { if (settingsWin) settingsWin.close(); });

/* ---------------- online updates (GitHub Releases) ---------------- */
let updater = null;
function updateRepo() { return store.get('updateRepo') || ((require('./package.json').deskcat || {}).updateRepo) || ''; }
function initUpdater() {
  const { Updater } = require('./updater');
  let lastStatus = null;
  updater = new Updater({ version: APP_VERSION, repo: updateRepo(), appDir: __dirname, onChange: (st) => {
    if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send('update:state', st);
    if (st.status !== lastStatus && (st.status === 'available' || lastStatus === 'available')) { lastStatus = st.status; buildTray(); }
    lastStatus = st.status;
  } });
  setTimeout(autoCheckUpdates, 90 * 1000);
  setInterval(autoCheckUpdates, 60 * 60 * 1000);
}
async function autoCheckUpdates() {
  if (!updater || !store.get('autoUpdate')) return;
  updater.repo = updateRepo(); updater.state.repo = updater.repo;
  if (Date.now() - (store.get('lastUpdateCheck') || 0) < 24 * 3600 * 1000) { return; }
  const st = await updater.check();
  store.set({ lastUpdateCheck: Date.now() });
  if (st.status === 'available' && store.get('updateNotified') !== st.latest) {
    store.set({ updateNotified: st.latest });
    const T = I18N.get(store.get('lang')).tray;
    deliverReminder({ id: 'update', text: T.updateBubble.replace('{v}', st.latest), important: false, action: 'hop' });
  }
}
ipcMain.handle('update:get', () => (updater ? updater.state : null));
ipcMain.handle('update:check', async () => { if (!updater) return null; updater.repo = updateRepo(); updater.state.repo = updater.repo; const st = await updater.check(); store.set({ lastUpdateCheck: Date.now() }); return st; });
ipcMain.handle('update:install', async () => (updater ? updater.install() : { ok: false }));

/* ---------------- updates from a zip package (offline) ---------------- */
ipcMain.handle('app:diag', () => ({ windows: lastSeen.windows, edges: lastSeen.edges, age: lastSeen.at ? Math.round((Date.now() - lastSeen.at) / 1000) : null, clicks: !!clickProc, mac: isMac }));
ipcMain.handle('app:updateInfo', () => ({ version: APP_VERSION, packaged: app.isPackaged, dir: app.isPackaged ? require('./update').overrideDir(app) : __dirname }));
ipcMain.handle('app:updateFromZip', async () => {
  const res = await dialog.showOpenDialog(settingsWin || undefined, { properties: ['openFile'], filters: [{ name: 'Desk Cat update', extensions: ['zip'] }] });
  if (res.canceled || !res.filePaths.length) return { ok: false, reason: 'cancelled' };
  try {
    const U = require('./update');
    // unpacked install: copy over the app folder. Installed app (.dmg/.exe): build an updated copy in the
    // user data folder; boot.js starts that copy when it is newer than the installed version.
    const n = app.isPackaged ? U.applyToOverride(res.filePaths[0], __dirname, U.overrideDir(app)) : U.applyZip(res.filePaths[0], __dirname);
    setTimeout(() => { app.relaunch(); app.exit(0); }, 600);
    return { ok: true, files: n };
  } catch (e) { return { ok: false, reason: String(e && e.message || e) }; }
});

ipcMain.handle('pets:import', (e, p) => {
  const base = (p.name || 'cat').toLowerCase().normalize('NFD').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'cat';
  let id = base, n = 2;
  while (fs.existsSync(path.join(userPetsDir(), id)) || fs.existsSync(path.join(__dirname, 'pets', id))) id = base + '-' + n++;
  const dir = path.join(userPetsDir(), id);
  fs.mkdirSync(dir, { recursive: true });
  const frames = {};
  for (const f of p.frames) {
    const m = /^data:image\/png;base64,(.+)$/.exec(f.dataUrl || '');
    if (!m) continue;
    fs.writeFileSync(path.join(dir, f.name + '.png'), Buffer.from(m[1], 'base64'));
    frames[f.name] = { file: f.name + '.png', w: f.w, h: f.h };
  }
  const meta = { name: p.name || id, frames, facing: 'right', baseHeight: p.baseHeight || 300 };
  fs.writeFileSync(path.join(dir, 'pet.json'), JSON.stringify(meta, null, 2));
  return { id, pets: listPets().map(petPayload) };
});

ipcMain.handle('pets:delete', (e, id) => {
  const dir = path.join(userPetsDir(), id);
  if (dir.startsWith(userPetsDir()) && fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
  if (store.get('pet') === id) { store.set({ pet: 'mycat' }); sendToCat('cat:pet', petPayload(currentPet())); }
  return listPets().map(petPayload);
});

ipcMain.on('pets:openFolder', () => { fs.mkdirSync(userPetsDir(), { recursive: true }); shell.openPath(userPetsDir()); });

/* ---------------- clicks on the desktop (the cat goes where you click) ----------------
   Only the state of the left mouse button is polled (no events are captured, nothing needs a permission):
   macOS through a small JXA script (NSEvent.pressedMouseButtons), Windows through PowerShell (GetAsyncKeyState). */
let clickProc = null, clickDown = null, lastClickAt = 0;
function startClickWatch() {
  if (clickProc || !(isMac || isWin)) return;
  const { spawn } = require('child_process');
  try {
    if (isMac) {
      const js = "ObjC.import('AppKit');var out=$.NSFileHandle.fileHandleWithStandardOutput;var prev=0,n=0;" +
        "var par=$.NSRunningApplication.runningApplicationWithProcessIdentifier(" + process.pid + ");" +
        "while(true){var b=$.NSEvent.pressedMouseButtons;var d=(b&1)?1:0;" +
        "if(d!==prev){prev=d;out.writeData($(d?'D\\n':'U\\n').dataUsingEncoding($.NSUTF8StringEncoding));}" +
        "if(++n%60===0){try{if(par&&par.terminated===true)break;}catch(e){}}$.NSThread.sleepForTimeInterval(0.03);}";
      clickProc = spawn('osascript', ['-l', 'JavaScript', '-e', js], { stdio: ['ignore', 'pipe', 'ignore'] });
    } else {
      const script = path.join(app.getPath('userData'), 'mouse.ps1');
      const src = `Add-Type -TypeDefinition @"
using System; using System.Runtime.InteropServices;
public class DeskCatMouse { [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int k); [DllImport("user32.dll")] public static extern int GetSystemMetrics(int i); }
"@
$parentPid = ${process.pid}; $prev = 0; $n = 0
while ($true) {
  $vk = 1; if ([DeskCatMouse]::GetSystemMetrics(23) -ne 0) { $vk = 2 }
  $d = 0; if (([DeskCatMouse]::GetAsyncKeyState($vk) -band 0x8000) -ne 0) { $d = 1 }
  if ($d -ne $prev) { $prev = $d; if ($d -eq 1) { [Console]::Out.WriteLine('D') } else { [Console]::Out.WriteLine('U') }; [Console]::Out.Flush() }
  $n++; if ($n % 60 -eq 0) { if (-not (Get-Process -Id $parentPid -ErrorAction SilentlyContinue)) { exit } }
  Start-Sleep -Milliseconds 30
}
`;
      fs.mkdirSync(path.dirname(script), { recursive: true }); fs.writeFileSync(script, src);
      clickProc = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script], { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
    }
  } catch (e) { clickProc = null; return; }
  let buf = '';
  clickProc.stdout.on('data', (d) => {
    buf += String(d);
    let i;
    while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); onMouseButton(line); }
  });
  clickProc.on('exit', () => { clickProc = null; });
  clickProc.on('error', () => { clickProc = null; });
}
function onMouseButton(s) {
  const p = screen.getCursorScreenPoint();
  if (s === 'D') { clickDown = menuClick() ? null : { x: p.x, y: p.y, t: Date.now() }; return; }
  if (s !== 'U' || !clickDown) return;
  if (menuClick()) { clickDown = null; return; }
  const d = clickDown; clickDown = null;
  if (Math.hypot(p.x - d.x, p.y - d.y) > 6 || Date.now() - d.t > 600) return;      // a drag, not a click
  if (store.get('mode') === 'spontaneous' || store.get('hidden') || store.get('workMode')) return;   // she goes her own way
  if (Date.now() - lastClickAt < 700) return;                                        // double clicks count once
  const wa = workArea();
  if (p.x < wa.x || p.x > wa.x + wa.width || p.y < wa.y || p.y > wa.y + wa.height) return;   // menu bar, Dock, taskbar
  if (settingsWin && !settingsWin.isDestroyed() && settingsWin.isVisible()) {
    const b = settingsWin.getBounds();
    if (p.x >= b.x && p.x <= b.x + b.width && p.y >= b.y && p.y <= b.y + b.height) return;
  }
  lastClickAt = Date.now();
  sendToCat('cat:goto', { x: p.x - wa.x, y: p.y - wa.y });
}

/* the pointer position for the "hunt" mode (she watches where it comes to rest); polled, nothing is captured */
let lastCursor = null;
function pollCursor() {
  if (store.get('mode') !== 'hunt' || store.get('hidden') || store.get('workMode') || !catWin || catWin.isDestroyed()) return;
  const p = screen.getCursorScreenPoint();
  if (lastCursor && lastCursor.x === p.x && lastCursor.y === p.y) return;
  lastCursor = p;
  const wa = workArea();
  sendToCat('cat:cursor', { x: p.x - wa.x, y: p.y - wa.y });
}
function setMode(m) {
  store.set({ mode: m });
  sendEngineSettings(); buildTray();
  if (settingsWin && !settingsWin.isDestroyed()) settingsWin.webContents.send('settings:changed', store.get());
}

/* ---------------- app lifecycle ---------------- */

app.whenReady().then(() => {
  store = new Store();
  if (isMac && app.dock) app.dock.hide();
  if (isMac) {
    Menu.setApplicationMenu(Menu.buildFromTemplate([
      { label: app.name, submenu: [{ role: 'about' }, { type: 'separator' }, { role: 'hide' }, { role: 'quit' }] },
      { role: 'editMenu' },
      { role: 'windowMenu' }
    ]));
  } else {
    Menu.setApplicationMenu(null);
  }
  createCatWindow();
  buildTray();
  globalShortcut.register(SHORTCUT, () => setHidden(!store.get('hidden')));
  screen.on('display-metrics-changed', fitToWorkArea);
  screen.on('display-added', fitToWorkArea);
  screen.on('display-removed', fitToWorkArea);
  reminderTimer = setInterval(checkReminders, 15000);
  startEdgeWatch();
  startClickWatch();
  setInterval(pollCursor, 120);
  initUpdater();
  checkReminders();
  try { if (store.get('launchAtLogin')) app.setLoginItemSettings({ openAtLogin: true, openAsHidden: true }); } catch (e) { /* dev */ }
});

/* Headless self-test: DESKCAT_SELFTEST=/path/dir → screenshots + console log, then quit. */
if (process.env.DESKCAT_SELFTEST) {
  app.whenReady().then(() => {
    const out = process.env.DESKCAT_SELFTEST;
    fs.mkdirSync(out, { recursive: true });
    const log = (...a) => fs.appendFileSync(path.join(out, 'log.txt'), a.join(' ') + '\n');
    const hook = (win, name) => win.webContents.on('console-message', (e, level, msg) => log(name, 'console', level, msg));
    log('version', APP_VERSION, 'packaged', app.isPackaged, 'dir', __dirname);
    if (process.env.DESKCAT_SELFTEST_ONLINE) {
      setTimeout(async () => {
        const st = await updater.check(); log('online check', st.status, st.latest || '', st.error || '');
        if (st.status === 'available') { const r = await updater.install(); log('online install', JSON.stringify(r)); }
      }, 1500);
    }
    if (process.env.DESKCAT_SELFTEST_ZIP) {
      try { const U = require('./update'); log('update', U.applyToOverride(process.env.DESKCAT_SELFTEST_ZIP, __dirname, U.overrideDir(app)), 'files ->', U.overrideDir(app)); }
      catch (e) { log('update failed', e && e.message); }
    }
    setTimeout(async () => {
      try {
        hook(catWin, 'cat');
        sendToCat('cat:remind', { id: 't', text: 'Napi sa vody 💧', important: true });
        await new Promise((r) => setTimeout(r, 1500));
        const img = await catWin.webContents.capturePage();
        fs.writeFileSync(path.join(out, 'cat.png'), img.toPNG());
        const st = await catWin.webContents.executeJavaScript('document.querySelector(".cat-root") && document.querySelector(".cat-root").dataset.state');
        log('cat state', st, 'bounds', JSON.stringify(catWin.getBounds()));
        openSettings('reminders');
        await new Promise((r) => setTimeout(r, 2500));
        hook(settingsWin, 'settings');
        const img2 = await settingsWin.webContents.capturePage();
        fs.writeFileSync(path.join(out, 'settings.png'), img2.toPNG());
        await settingsWin.webContents.executeJavaScript('document.querySelector("[data-tab=pets]").click()');
        await new Promise((r) => setTimeout(r, 800));
        fs.writeFileSync(path.join(out, 'settings-pets.png'), (await settingsWin.webContents.capturePage()).toPNG());
        await settingsWin.webContents.executeJavaScript('document.querySelector("[data-tab=general]").click()');
        await new Promise((r) => setTimeout(r, 1500));
        fs.writeFileSync(path.join(out, 'settings-general.png'), (await settingsWin.webContents.capturePage()).toPNG());
        await settingsWin.webContents.executeJavaScript('document.querySelector("[data-tab=cat]").click()');
        await new Promise((r) => setTimeout(r, 800));
        fs.writeFileSync(path.join(out, 'settings-cat.png'), (await settingsWin.webContents.capturePage()).toPNG());
        if (process.env.DESKCAT_SELFTEST_HUNT) {
          // hunt mode: a click with the pointer left still sends her after it
          const prevMode = store.get('mode');
          setMode('hunt');
          log('settings mode select', await settingsWin.webContents.executeJavaScript('document.getElementById("mode").value + " | " + document.getElementById("mode-hint").textContent'));
          await catWin.webContents.executeJavaScript('document.querySelector(".cat-bubble-x").click()');   // close the test reminder
          await new Promise((r) => setTimeout(r, 2500));
          const wa = workArea(); const p = { x: Math.round(wa.width * 0.8), y: wa.height - 60 };
          sendToCat('cat:cursor', p); sendToCat('cat:goto', p);
          const seen = [];
          for (let i = 0; i < 24; i++) { await new Promise((r) => setTimeout(r, 1000)); seen.push(await catWin.webContents.executeJavaScript('document.querySelector(".cat-root").dataset.state')); }
          log('hunt states', [...new Set(seen)].join(' > '));
          setMode(prevMode);
        }
        if (process.env.DESKCAT_SELFTEST_MENU) {
          // menu commands, each followed by the click that picked the menu item (it must not send her away)
          const prevMode = store.get('mode'); setMode('click');
          try { await catWin.webContents.executeJavaScript('document.querySelector(".cat-bubble-x") && document.querySelector(".cat-bubble-x").click()'); } catch (e) { /* no bubble */ }
          const states = async (n) => { const seen = []; for (let i = 0; i < n; i++) { await new Promise((r) => setTimeout(r, 1000)); seen.push(await catWin.webContents.executeJavaScript('document.querySelector(".cat-root").dataset.state')); } return [...new Set(seen)].join(' > '); };
          await new Promise((r) => setTimeout(r, 2000));
          sendToCat('cat:pet-action'); menuClosedAt = Date.now(); onMouseButton('D'); onMouseButton('U');
          log('menu pet', await states(12));
          sendToCat('cat:sleep'); menuClosedAt = Date.now(); onMouseButton('D'); onMouseButton('U');
          log('menu sleep', await states(14));
          sendToCat('cat:wake');
          log('menu wake', await states(8));
          setMode(prevMode);
        }
        log('done');
      } catch (e) { log('ERROR', e.stack || e); }
      app.isQuitting = true; app.quit();
    }, 3000);
  });
}

app.on('window-all-closed', () => { /* keep running in the tray */ });
app.on('activate', () => { if (!catWin) createCatWindow(); });
app.on('before-quit', () => { app.isQuitting = true; clearInterval(reminderTimer); clearInterval(edgeTimer); globalShortcut.unregisterAll(); if (psProc) { try { psProc.stdin.end(); psProc.kill(); } catch (e) { /* ignore */ } } if (clickProc) { try { clickProc.kill(); } catch (e) { /* ignore */ } } });
