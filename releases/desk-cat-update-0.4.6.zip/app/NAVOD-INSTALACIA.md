# Desk Cat – inštalácia krok za krokom

## A. Windows 10 – hotová appka (netreba nič inštalovať)

1. Skopíruj `DeskCat-0.4.4-win-x64.zip` do Windows notebooku (USB kľúč, e-mail, Disk Google…).
2. **Pravý klik na zip → Vlastnosti →** dole zaškrtni **Odblokovať** (ak tam je) → OK.
3. Pravý klik na zip → **Extrahovať všetko…** → cieľ napr. `C:\DeskCat` → Extrahovať.
4. V priečinku dvojklik na **Desk Cat.exe**. Ak vyskočí „Systém Windows ochránil váš počítač“:
   **Ďalšie informácie → Spustiť aj tak** (appka nie je podpísaná certifikátom).
5. Menu je **vpravo dole pri hodinách** (ak ikonu nevidíš, klikni na šípku **˄**).
6. Menu → **Spustiť po prihlásení**. Priečinok `C:\DeskCat` potom už nepresúvaj.

Ďalšie verzie si appka stiahne sama (časť C) – hneď po inštalácii klikni v Nastaveniach → Všeobecné
na **Vyhľadať aktualizácie** a dostaneš najnovšiu verziu.

## B. Mac – jednorazový prechod zo starej verzie (bez Terminálu)

Ak už máš **0.4.4 alebo novšiu**, nerob nič z tejto časti – stačí Nastavenia → Všeobecné → **Vyhľadať aktualizácie**.


Verzia 0.4.0 má skryté tlačidlo aktualizácie, preto tento jediný raz novú verziu vložíš ručne
na miesto, odkiaľ ju appka pri štarte sama načíta:

1. Rozbaľ `desk-cat-update-0.4.6.zip` – vznikne priečinok `app`. **Premenuj ho na `app-update`.**
2. Vo Finderi menu **Prejsť → Prejsť do priečinka…** (⇧⌘G), napíš
   `~/Library/Application Support/Desk Cat` a stlač Enter.
3. Potiahni tam priečinok `app-update` (vnútri má byť priamo `package.json`, `main.js`, …).
   Ak sa opýta, či nahradiť existujúci, daj **Nahradiť**.
4. Ukonči mačku (menu v lište → Ukončiť) a spusti ju znova z Aplikácií.
5. V Nastaveniach → Všeobecné má byť **Verzia 0.4.6**. Od teraz už všetko ide cez tlačidlo.

Ak máš 0.4.2 alebo 0.4.3, stačí Nastavenia → Všeobecné → **Nainštalovať z .zip…** a vybrať `desk-cat-update-0.4.6.zip`.

### Mac: kliknutie na prázdnu plochu odsúva okná nabok

To robí macOS (od verzie Sonoma), nie mačka: klik na tapetu „odkryje plochu“ a všetky okná odsunie
nabok. Kým je to zapnuté, mačka nemôže prísť na miesto kliknutia na prázdnej ploche a pri ťahaní
mačky nad tapetou sa okná tiež môžu odsunúť. Vypnutie:

**Systémové nastavenia → Plocha a Dock →** v časti Plocha a Stage Manager položka
**„Kliknutím na tapetu zobraziť plochu“ → zvoľ „Iba v Stage Manageri“**.

Potom klik na prázdnu plochu nič neodsunie a mačka tam príde.

## C. Aktualizácie cez internet

**Nastavenia → Všeobecné → Vyhľadať aktualizácie.** Ak je nová verzia, objaví sa tlačidlo
**Aktualizovať na X.Y.Z** – appka ju stiahne, nainštaluje a reštartuje sa. Keď je zapnuté
**Kontrolovať automaticky (raz za deň)**, appka to skontroluje sama; pri novej verzii ti to mačka
povie a v menu v lište pribudne položka **⬆︎ Nainštalovať aktualizáciu**.

- Nové verzie zverejňujem ja do verejného repozitára **github.com/freeandpositive11-design/deskcat-updates**
  (súbor `latest.json` + balík v priečinku `releases`). Ty nemusíš robiť nič – appky si ich nájdu.
  Adresa sa dá zmeniť v Nastaveniach → Všeobecné → Zdroj aktualizácií.

- Nová verzia sa uloží k nastaveniam (Mac: `~/Library/Application Support/Desk Cat/app-update`,
  Windows: `%APPDATA%\Desk Cat\app-update`); ak by nešla spustiť, appka sa vráti k nainštalovanej.
- Bez internetu: **Nainštalovať z .zip…** a vybrať balík, ktorý ti niekto pošle.
- Nastavenia, pripomienky a štatistiky sa pri aktualizácii nemenia.
- Novší Electron (veľká zmena) by vyžadoval nový inštalátor – vtedy to napíšem k vydaniu.

## D. Ovládanie

- **Klik na mačku** – zareaguje; keď sedí, vyvalí sa na chrbát. **Kým leží na chrbáte, nedá sa ťahať** –
  hladkáš ju ťukaním alebo podržaním tlačidla a pohybom zo strany na stranu (srdiečka, so zapnutými
  zvukmi pradie a ostáva ležať, kým ju hladkáš).
- **Ťahanie** – presunieš ju; pusti ju nad oknom a vyskočí naň. Spiacu mačku ťahanie nezobudí.
- **Režim** (Nastavenia → Mačka → Režim, alebo menu v lište → Režim):
  - **Spontánna** – robí si, čo chce, a spí, kde sa jej zachce; kliknutia na plochu ju neposielajú.
  - **Ide tam, kam klikneš** – klik na plochu: príde tam a chvíľu tam ostane; klik na okno: vylezie
    naň (okno musí siahať až dole; ak vedľa neho nie je miesto, vyšplhá sa po jeho prednej strane)
    a sadne si alebo ľahne.
  - **Naháňa kurzor** (namiesto motýľa) – klikni a nechaj kurzor stáť: pribehne, skočí po ňom,
    sadne si a čaká, kým sa pohne. Keď kurzor presunieš a necháš stáť, ide zas (pár kôl, potom
    ju to prestane baviť). Keď len klikneš a ideš ďalej, nevšíma si to.
  - Keď spí, kliknutia ani kurzor ju nezobudia – zobudí ju len klik priamo na ňu.
- **Nastavenia → Všeobecné** ukazuje, koľko okien mačka vidí – ak je tam 0, pošli mi to.
- **Pravý klik na mačku** – menu: Pohladkať, Choď spať, Zobuď sa… (v každom režime). **Ctrl+Shift+M** – schová / ukáže.
- **Menu v lište** (Mac hore vpravo, Windows vpravo dole): pracovný režim, zavolať ku kurzoru,
  spať, Pomodoro, Dnešný súhrn, pripomienky, nastavenia, spustiť po prihlásení, ukončiť.

## E. Čo kde nastaviť

- **Mačka**: veľkosť, rýchlosť, aktivita (pokojná / normálna / hravá – ako často sa niečo deje,
  ako dlho sedí a ako veľa spí), režim, obtieranie, šplhanie, priečinky, motýľ,
  sadne si na okno, v ktorom píšeš, zvuky (pradenie), nočný režim.
- **Pracovný režim**: spí v rohu alebo sa schová; zapínanie podľa času a dní; tiché hodiny;
  dĺžky pomodora; denný súhrn.
- **Pripomienky**: text + kedy (každých N minút / o čase v dňoch / po N minútach práce bez
  prestávky) + čo mačka pri tom urobí + dôležitá áno/nie. Tlačidlo Vyskúšať.

## F. Pre vývoj (voliteľné)

Spustenie zo zdrojákov: Node.js LTS z https://nodejs.org, potom v priečinku `app`
`npm install` a `npm start`. Inštalátory: `npm run dist:mac` (len na Macu),
`npm run dist:winzip` (prenosný zip pre Windows, ide aj z Macu), `npm run dist:win`
(inštalátor .exe, najlepšie priamo na Windowse).
