# Desk Cat – mačka na ploche

Desktopový maznáčik pre macOS a Windows. Mačka sa túla po spodnom okraji obrazovky nad tvojimi oknami,
klik mimo nej prechádza na okná pod ňou. Vie pripomínať (voda, prestávka, vlastné pripomienky)
a má pracovný režim, v ktorom ťa nevyrušuje.

## 1. Spustenie na Macu (vývojová verzia)

Podrobný postup pre Mac aj Windows 10 vrátane inštalátorov a aktualizácií je v **NAVOD-INSTALACIA.md**.

Potrebuješ **Node.js** (LTS, napr. 22) – stiahni z https://nodejs.org a nainštaluj.

V Termináli:

```bash
cd cesta/k/priecinku/desk-cat      # priečinok, kde je tento README
npm install                        # stiahne Electron (raz, ~100 MB)
npm start                          # spustí mačku
```

Mačka sa objaví dole na obrazovke, v lište hore vpravo pribudne ikona s mačacou hlavou (menu).
Ukončenie: menu v lište → **Ukončiť**, alebo v Termináli `Ctrl+C`.

Skratka **Ctrl+Shift+M** mačku schová / ukáže.

## 2. Ovládanie

- **Klik** na mačku – zareaguje (so zvukmi pradie). **Ťahanie** – presunieš ju; nad oknom vyskočí naň,
  spiacu mačku to nezobudí. **Klik na plochu / okno** – podľa režimu (nižšie).
- **Pravý klik** na mačku – menu (pohladkať, spať, pracovný režim, schovať, nastavenia) – v každom režime.
- **Na chrbáte** sa nedá ťahať: ťukaním alebo ťahaním zo strany na stranu ju hladkáš.
- **Ikona v lište** – rovnaké menu + pripomienky, nastavenia, spustiť po prihlásení.

## 3. Nastavenia

Menu → **Nastavenia…**

- **Mačka**: veľkosť, rýchlosť, aktivita (pokojná / normálna / hravá), režim, obtieranie,
  šplhanie na okná, hra s priečinkami, motýľ, zvuky, nočný režim.
- **Režim** (aj v menu v lište → Režim):
  - **Spontánna** – robí si, čo chce: chodí, lezie na okná, spí, kde sa jej zachce (na okne, v rohu,
    pri priečinku…). Kliknutia na plochu ju neposielajú.
  - **Ide tam, kam klikneš** – klik na plochu ju privolá, klik na okno ju pošle naň; chvíľu tam ostane.
  - **Naháňa kurzor** – namiesto motýľa: klikneš a kurzor ostane stáť → pribehne, skočí po ňom, sadne
    si a čaká; keď sa kurzor pohne a znova zastaví, ide zas (pár kôl). Klik a pohyb ďalej ignoruje,
    spiacu mačku kurzor nezobudí.
- **Pracovný režim**: spí v rohu (priehľadnejšia) alebo sa úplne schová. Dá sa zapínať podľa času a dní
  (napr. Po–Pi 9:00–17:00). V pracovnom režime ťa vyruší iba pripomienka označená ako **dôležitá**.
  Tu sú aj **tiché hodiny** (mačka len odpočíva, prídu iba dôležité pripomienky), dĺžky **pomodora**
  (spúšťa sa z menu v lište; pri mačke beží odpočet, na konci príde s prestávkou a po nej zavolá späť)
  a **denný súhrn** (koľko si dnes pracovala a koľko bolo prestávok – o nastavenom čase alebo z menu).
- **Pripomienky**: text, kedy („každých N minút“, „o čase“ + dni, „po N minútach práce bez prestávky“),
  čo mačka pri tom urobí (príde, poskočí, sadne si, spí, vyvalí sa, obtrie sa, priečinok, okno), dôležitá áno/nie, Vyskúšať.
- **Mačky**: výber aktívnej mačky (pozri nižšie).
- **Všeobecné**: jazyk (SK/EN), spustiť po prihlásení, aktualizácia z .zip balíka.

Nastavenia sa ukladajú do `~/Library/Application Support/Desk Cat/settings.json`
(Windows: `%APPDATA%\Desk Cat\settings.json`). Tam je aj `stats.json` (denný súhrn) a po aktualizácii
zo zipu priečinok `app-update` s novou verziou.

## 4. Animácie z videa

Vstavaná mačka používa 34 klipov vygenerovaných vo Flow (Veo) z kľúčových snímok (`keyframes/out3`):
státie, chôdza (rozbeh, slučka, zastavenie) oboma smermi, otočenie, sadnutie, sedenie, vstanie,
zaspávanie, spánok, zobudenie, umývanie, beh oboma smermi, poskok, skok za motýľom, vyvalenie,
obtieranie, hra s priečinkom, číhanie a skok, šplhanie na okno (skok na hranu, lezenie, vylezenie
na vrch, zoskok). Sú uložené ako WebM (VP9 s priehľadnosťou) v `pets/mycat/*.webm`, popis je
v `pet.json` → `video.clips`.

Každý klip má vlastný výrez a dva kotviace body (`startAnchor`, `endAnchor`) – ten istý fyzický bod
mačky na prvej a poslednej snímke. Engine (`renderer/cat-engine.js`) klipy spája podľa grafu póz
(stojí → kráča → stojí → sedí → spí…), takže každý pohyb nadväzuje na ďalší bez skokov. Smer je
súčasťou pózy: pre chôdzu doľava sú samostatné klipy (`walkL`, `standL`…), nič sa nezrkadlí – oko je
vždy na správnej strane. Do tváre sa pri spracovaní nezasahuje; mení sa iba zelené/modré pozadie
na priehľadnosť. Zdrojové videá a skripty sú v `video3` (`extract.py` → `build3.py` → `make_pet3.py`).

Čo ešte chýba: slučka behu doprava (klip `18-beh`; zatiaľ je vystrihnutá z rozbehu) a prechod
stoj → číha (`29-cihanie`); bez neho sa číhanie a skok z číhania nepoužijú.

Chôdza a beh sú riadené nameranou rýchlosťou nôh v každej snímke klipu, takže sa nikdy nešmýka ani
nebeží na mieste. Občas si sadne aj na vrch okna, v ktorom práve píšeš (ak sa naň dá vyliezť).

Nálady: mačka má striedavo ospalú, pokojnú, maznavú a hravú náladu (každá pár minút; aktivita
v nastaveniach určuje pomer a ako dlho oddychuje). Maznavá si príde sadnúť k kurzoru, pýta si
hladkanie („Škrabkaj ma!“) a vyvalí sa na chrbát – klikaním ju hladkáš (srdiečka, pradie, ostáva
ležať). Hravá naháňa motýľa, behá (aj cez okraj obrazovky a späť z druhej strany), lezie na okná
a hrá sa s priečinkom. Mačku môžeš položiť myšou na vrch okna alebo k priečinku na ploche.

Správanie navyše: **obtieranie** o hranu okna, ktoré siaha dole k mačke (appka každých 6 s zisťuje
polohu okien – na Macu cez `osascript`, na Windowse cez PowerShell; len polohu, nie obsah),
**šplhanie** po ľavej hrane takého okna až na jeho vrch (tam sedí, chodí, spí a zoskočí dole),
**hra s priečinkom** pri spodnom okraji plochy (na Macu sa polohy ikon pýta Findera – systém sa raz
opýta na povolenie; na Windowse zatiaľ nie je) a **naháňanie motýľa** (motýľa kreslí appka).
Všetko sa dá vypnúť v Nastaveniach → Mačka.

## 5. Vlastná mačka

Táto verzia hrá iba videoklipy, takže vlastná mačka = vlastná sada klipov v rovnakej štruktúre
(`pets/<id>/pet.json` + `*.webm`). Postup je rovnaký ako pri vstavanej: pózy z ChatGPT →
`keyframes/make_keyframes3.py` → klipy vo Flow podľa `keyframes/out3/NAVOD.md` → `video3`.
Import zo sprite sheetu (statické pózy) z predchádzajúcej verzie už nie je podporovaný.

## 6. Inštalačné balíky

```bash
npm run dist:mac    # vytvorí dist/DeskCat-0.3.0-mac.dmg
npm run dist:win    # vytvorí dist/DeskCat-0.3.0-setup.exe (najlepšie priamo na Windowse)
```

Balíky nie sú podpísané certifikátom, takže:

- **macOS** pri prvom otvorení povie, že appku nemôže overiť. Riešenie: pravý klik na appku → **Otvoriť**,
  alebo Systémové nastavenia → Súkromie a bezpečnosť → **Otvoriť aj tak**.
- **Windows** (SmartScreen): **Ďalšie informácie → Spustiť aj tak**.

## 7. Známe obmedzenia

- Mačka beží na hlavnom monitore.
- Na Macu sa automaticky nezobrazuje nad aplikáciami na celú obrazovku (to je zámer).
  Na Windowse pri hre / videu na celú obrazovku ju schovaj skratkou Ctrl+Shift+M alebo pracovným režimom „schová sa“.
- Pripomienky „každých N minút“ sa počítajú od spustenia appky.

## Štruktúra projektu

```
main.js              hlavný proces (okno, lišta, pripomienky, nastavenia)
preload.js           most medzi oknom a hlavným procesom
store.js             ukladanie nastavení
i18n.js              texty SK/EN
renderer/            priehľadné okno s mačkou (cat-engine.js = správanie)
settings/            okno nastavení
pets/mycat/          vstavaná mačka (pet.json + webm klipy)
assets/, build/      ikony
```
