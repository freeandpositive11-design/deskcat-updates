/* Entry point. An installed app (.dmg / .exe) cannot overwrite itself, so updates from a .zip package are
 * unpacked into <userData>/app-update (see update.js). When that copy is newer than the installed version
 * it is started instead; if it fails to load, the installed version runs. */
const { app } = require('electron');
const fs = require('fs');
const path = require('path');

function newer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0); }
  return false;
}

let started = false;
if (app.isPackaged) {
  try {
    const dir = path.join(app.getPath('userData'), 'app-update');
    const own = require('./package.json').version;
    const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
    if (newer(pkg.version, own) && fs.existsSync(path.join(dir, 'main.js'))) {
      require(path.join(dir, 'main.js'));
      started = true;
    }
  } catch (e) {
    if (e && e.code !== 'ENOENT') { try { fs.renameSync(path.join(app.getPath('userData'), 'app-update'), path.join(app.getPath('userData'), 'app-update-broken-' + Date.now())); } catch (e2) { /* ignore */ } }
  }
}
if (!started) require('./main.js');
