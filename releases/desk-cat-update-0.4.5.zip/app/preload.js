const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('deskcat', {
  // cat window
  init: () => ipcRenderer.invoke('cat:init'),
  setInteractive: (on) => ipcRenderer.send('cat:interactive', !!on),
  contextMenu: (pos) => ipcRenderer.send('cat:contextmenu', pos),
  event: (name, data) => ipcRenderer.send('cat:event', name, data),
  on: (channel, fn) => { ipcRenderer.on(channel, (e, ...args) => fn(...args)); },
  // settings window
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (partial) => ipcRenderer.invoke('settings:set', partial),
  testReminder: (r) => ipcRenderer.send('settings:testReminder', r),
  closeWindow: () => ipcRenderer.send('settings:close'),
  importPet: (p) => ipcRenderer.invoke('pets:import', p),
  deletePet: (id) => ipcRenderer.invoke('pets:delete', id),
  openPetsFolder: () => ipcRenderer.send('pets:openFolder'),
  updateInfo: () => ipcRenderer.invoke('app:updateInfo'),
  diag: () => ipcRenderer.invoke('app:diag'),
  updateState: () => ipcRenderer.invoke('update:get'),
  updateCheck: () => ipcRenderer.invoke('update:check'),
  updateInstall: () => ipcRenderer.invoke('update:install'),
  updateFromZip: () => ipcRenderer.invoke('app:updateFromZip')
});
