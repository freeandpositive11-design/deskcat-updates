/* Online updates from a public GitHub repository: latest.json on the main branch points to the package
 * (releases/desk-cat-update-X.Y.Z.zip); GitHub Releases (tag vX.Y.Z + that asset) work as a fallback.
 * The package is downloaded and applied with update.js (installed app → <userData>/app-update, started by
 * boot.js; unpacked app → copied over the app folder), then the app restarts. */
const fs = require('fs');
const path = require('path');
const { app, net } = require('electron');
const U = require('./update');

function newer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0); }
  return false;
}

class Updater {
  constructor({ version, repo, appDir, onChange }) {
    this.version = version; this.repo = repo; this.appDir = appDir; this.onChange = onChange || (() => {});
    this.state = { status: 'idle', current: version, latest: null, notes: '', error: null, progress: 0, checkedAt: null, repo };
  }
  _set(p) { Object.assign(this.state, p); this.onChange(Object.assign({}, this.state)); }

  async check() {
    if (!this.repo) { this._set({ status: 'nosource', error: null }); return this.state; }
    if (this.state.status === 'downloading') return this.state;
    this._set({ status: 'checking', error: null });
    // 1) latest.json in the repository (main branch):
    //    { "version": "0.4.5", "file": "releases/desk-cat-update-0.4.5.zip", "size": 123, "notes": "…" }
    try {
      const rawBase = process.env.DESKCAT_UPDATE_RAW || 'https://raw.githubusercontent.com';
      const res = await net.fetch(`${rawBase}/${this.repo}/main/latest.json?t=${Date.now()}`, { headers: { 'User-Agent': 'DeskCat/' + this.version, 'Cache-Control': 'no-cache' } });
      if (res.ok) {
        const j = await res.json();
        const latest = String(j.version || '').replace(/^v/i, '').trim();
        const url = j.url || (j.file ? `${rawBase}/${this.repo}/main/${j.file}` : null);
        this.release = { version: latest, url, size: j.size || 0, notes: j.notes || '' };
        if (latest && url && newer(latest, this.version)) this._set({ status: 'available', latest, notes: this.release.notes, checkedAt: Date.now() });
        else this._set({ status: 'uptodate', latest: latest || null, checkedAt: Date.now() });
        return this.state;
      }
    } catch (e) { /* fall back to GitHub Releases */ }
    // 2) GitHub Releases (tag vX.Y.Z with an asset desk-cat-update-X.Y.Z.zip)
    try {
      const apiBase = process.env.DESKCAT_UPDATE_API || 'https://api.github.com';      // overridable for testing
      const res = await net.fetch(`${apiBase}/repos/${this.repo}/releases/latest`, {
        headers: { Accept: 'application/vnd.github+json', 'User-Agent': 'DeskCat/' + this.version }
      });
      if (res.status === 404) { this._set({ status: 'uptodate', latest: null, checkedAt: Date.now() }); return this.state; }
      if (!res.ok) throw new Error('GitHub ' + res.status);
      const j = await res.json();
      const latest = String(j.tag_name || j.name || '').replace(/^v/i, '').trim();
      const asset = (j.assets || []).find((a) => /^desk-cat-update.*\.zip$/i.test(a.name));
      this.release = { version: latest, url: asset && asset.browser_download_url, size: asset ? asset.size : 0, page: j.html_url, notes: j.body || '' };
      if (latest && newer(latest, this.version) && asset) this._set({ status: 'available', latest, notes: this.release.notes, checkedAt: Date.now() });
      else this._set({ status: 'uptodate', latest: latest || null, checkedAt: Date.now() });
    } catch (e) {
      this._set({ status: 'error', error: String((e && e.message) || e), checkedAt: Date.now() });
    }
    return this.state;
  }

  /** download the package, apply it and restart */
  async install() {
    if (this.state.status !== 'available' || !this.release || !this.release.url) return { ok: false, reason: 'nothing to install' };
    this._set({ status: 'downloading', progress: 0, error: null });
    try {
      const res = await net.fetch(this.release.url, { headers: { 'User-Agent': 'DeskCat/' + this.version } });
      if (!res.ok) throw new Error('download ' + res.status);
      const total = Number(res.headers.get('content-length')) || this.release.size || 0;
      const reader = res.body.getReader();
      const chunks = []; let got = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(Buffer.from(value)); got += value.length;
        if (total) this._set({ progress: Math.min(0.99, got / total) });
      }
      const file = path.join(app.getPath('temp'), `desk-cat-update-${this.release.version}.zip`);
      fs.writeFileSync(file, Buffer.concat(chunks));
      this._set({ status: 'installing', progress: 1 });
      const n = app.isPackaged ? U.applyToOverride(file, this.appDir, U.overrideDir(app)) : U.applyZip(file, this.appDir);
      try { fs.unlinkSync(file); } catch (e) { /* ignore */ }
      this._set({ status: 'restarting' });
      setTimeout(() => { app.relaunch(); app.exit(0); }, 800);
      return { ok: true, files: n };
    } catch (e) {
      this._set({ status: 'error', error: String((e && e.message) || e) });
      return { ok: false, reason: this.state.error };
    }
  }
}

module.exports = { Updater, newer };
