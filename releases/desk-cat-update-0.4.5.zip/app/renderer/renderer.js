/* Cat window: wires the shared engine to Electron through window.deskcat (preload). */
(async function () {
  const api = window.deskcat;
  const stage = document.getElementById('stage');
  let cat = null;
  let settings = {};

  const bounds = () => ({ left: 0, right: window.innerWidth, floorY: window.innerHeight - 1 });

  function createCat(pet) {
    if (cat) { cat.destroy(); cat = null; }
    if (!pet) return;
    cat = new CatEngine.Cat({
      container: stage,
      pet: pet.meta,
      baseUrl: pet.baseUrl,
      bounds,
      settings,
      onInteractive: (on) => api.setInteractive(on),
      onEvent: (name, data) => {
        if (name === 'contextmenu') api.contextMenu(data);
        else api.event(name, data);
      }
    });
  }

  const init = await api.init();
  settings = init.settings || {};
  createCat(init.pet);
  if (cat) { cat.setQuiet(!!init.quiet); cat.setPomodoro(init.pomodoro || null); }

  api.on('cat:settings', (s) => { settings = s; if (cat) cat.setSettings(s); });
  api.on('cat:pet', (pet) => createCat(pet));
  api.on('cat:remind', (r) => { if (cat) cat.remind(r); });
  api.on('cat:call', (x) => { if (cat) cat.callTo(x); });
  api.on('cat:sleep', () => { if (cat) cat.sleepNow(); });
  api.on('cat:wake', () => { if (cat) cat.wakeUp(); });
  api.on('cat:pet-action', () => { if (cat) cat.pet(); });
  api.on('cat:edges', (edges) => { if (cat) cat.setEdges(edges); });
  api.on('cat:icons', (icons) => { if (cat) cat.setIcons(icons); });
  api.on('cat:windows', (wins) => { if (cat) cat.setWindows(wins); });
  api.on('cat:active', (r) => { if (cat) cat.setActiveWindow(r); });
  api.on('cat:quiet', (on) => { if (cat) cat.setQuiet(on); });
  api.on('cat:goto', (p) => { if (cat && !cat.dragging && !cat._hit(p.x, p.y)) cat.goToPoint(p.x, p.y); });
  api.on('cat:pomodoro', (p) => { if (cat) cat.setPomodoro(p); });
  api.on('cat:cursor', (p) => { if (cat) cat.setCursor(p.x, p.y); });

  // when the pointer leaves the window entirely, make sure clicks pass through again
  document.addEventListener('mouseleave', () => api.setInteractive(false));
  window.addEventListener('blur', () => { if (cat && !cat.dragging) api.setInteractive(cat.hovering); });
})();
