/* Desk Cat – behaviour engine v4 (video clips only).
 * Shared by the Electron renderer and the browser preview.
 * Exposes window.CatEngine = { Cat, DEFAULT_SETTINGS } (or module.exports).
 *
 * pet.json.video:
 *   fps, clips: { id: { file, frames, fps, loop, from, to, w, h, startAnchor:[x,y], endAnchor:[x,y], box,
 *                       speed?, syncTimes?, panelX?, panelTop?, folderBox?, climbSpeed?, air?, holdTime? } }
 * Every clip is a VP9-alpha webm with its own crop. `startAnchor` / `endAnchor` mark the same physical point of
 * the cat (feet on the ground for standing poses) at the first / last frame, in clip pixels at scale 1, so
 * clips chain by moving the world position: pos += endAnchor(A) - startAnchor(B).
 *
 * Poses: stand walk run sit sleep crouch (facing right), standL walkL runL (facing left), cling (on a window
 * edge), sitTop is the sit pose on top of a window. The cat lives on a "surface": the floor or a window top.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CatEngine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const DEFAULT_SETTINGS = {
    size: 150,            // displayed height (px) of the standing cat
    speed: 1.0,           // 0.5 … 2 (playback and walking speed)
    activity: 'normal',   // calm | normal | playful
    mode: 'click',        // spontaneous (lives on her own) | click (goes where you click) | hunt (hunts the resting pointer)
    followMouse: true,    // older setting: false = spontaneous when no mode is given
    rubWindows: true,     // rub against window edges that reach the floor
    rubScreenEdges: true,
    climbWindows: true,   // climb onto windows whose edge reaches the floor
    playFolders: true,    // play with desktop icons near the floor
    butterfly: true,      // chase a butterfly now and then
    sitActive: true,      // now and then climbs onto the window being used
    sounds: false,
    bubbleSeconds: 12,
    workMode: false,
    workBehavior: 'sleep', // sleep | hide
    workCorner: 'right',   // left | right
    workOpacity: 0.65,
    nightStart: 22,
    nightEnd: 7,
    reduceMotion: false,
    lang: 'sk'
  };

  const PHRASES = {
    sk: { click: ['Mňau!', 'Prrr…', 'Mrrp?', '♥', 'Mňa-au~'], wake: ['Hmm?', 'Už idem…', '*zíva*'], drop: ['Hej!', 'Ups.', 'Mňau?!'], pet: ['Škrabkaj ma!', 'Pohladkaj mi bruško 🐾', 'Poď ma pohladkať'], purr: ['Prrr…', 'Prrrrr ♥', 'Ešte…', 'Mrrr~'] },
    en: { click: ['Meow!', 'Purrr…', 'Mrrp?', '♥', 'Mee-ow~'], wake: ['Hmm?', 'Coming…', '*yawns*'], drop: ['Hey!', 'Oops.', 'Meow?!'], pet: ['Pet me!', 'Rub my belly 🐾', 'Come pet me'], purr: ['Purrr…', 'Purrrr ♥', 'More…', 'Mrrr~'] }
  };

  const ACTIVITY = {   // the activity setting shapes the mood mix and how long she rests between things
    calm:    { moodSleepy: 2, moodCalm: 5, moodCuddly: 2, moodPlayful: 0.8, moodScale: 1.4, restScale: 1.5, sleepScale: 1.4, sleepWeight: 1.0, minSit: 90, speed: 0.9 },
    normal:  { moodSleepy: 1.5, moodCalm: 3, moodCuddly: 2, moodPlayful: 2, moodScale: 1.0, restScale: 1.0, sleepScale: 1.0, sleepWeight: 0.8, minSit: 120, speed: 1.0 },
    playful: { moodSleepy: 0.6, moodCalm: 2, moodCuddly: 2, moodPlayful: 4, moodScale: 0.7, restScale: 0.7, sleepScale: 0.6, sleepWeight: 0.3, minSit: 180, speed: 1.15 }
  };

  const FADE_MS = 200;
  const GRAVITY = 2600;
  const FACING = { stand: 1, walk: 1, run: 1, sit: 1, sleep: 1, crouch: 1, cling: 1, sitTop: 1, standL: -1, walkL: -1, runL: -1 };
  const GAIT = {
    1:  { walk: { start: 'walkStart', loop: 'walk', stop: 'walkStop', stand: 'stand' }, run: { start: 'runStart', loop: 'run', stop: 'runStop', stand: 'stand' } },
    '-1': { walk: { start: 'walkStartL', loop: 'walkL', stop: 'walkStopL', stand: 'standL' }, run: { start: 'runStartL', loop: 'runL', stop: 'runStopL', stand: 'standL' } }
  };

  const rand = (a, b) => a + Math.random() * (b - a);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const smooth = (u) => { u = clamp(u, 0, 1); return u * u * (3 - 2 * u); };
  const weighted = (obj) => {
    let total = 0;
    for (const k in obj) total += Math.max(0, obj[k]);
    let r = Math.random() * total;
    for (const k in obj) { r -= Math.max(0, obj[k]); if (r <= 0) return k; }
    return Object.keys(obj)[0];
  };

  function videoSupported() {
    try {
      const v = document.createElement('video');
      return !!v.canPlayType && v.canPlayType('video/webm; codecs="vp9"') !== '';
    } catch (e) { return false; }
  }

  class Cat {
    constructor(o) {
      this.container = o.container;
      this.pet = o.pet;
      this.baseUrl = o.baseUrl || '';
      this.boundsFn = o.bounds;
      this.settings = Object.assign({}, DEFAULT_SETTINGS, o.settings || {});
      this.onInteractive = o.onInteractive || (() => {});
      this.onEvent = o.onEvent || (() => {});
      this.V = this.pet.video;
      this.clips = (this.V && this.V.clips) || {};

      this.state = 'idle';            // idle | loop | transition | walking | stopping | climbing | drag | fall | hidden
      this.pose = 'stand';
      this.pos = { x: 0, y: 0 };      // world position of the active clip's start anchor (container px)
      this.surface = { kind: 'floor', y: 0, left: 0, right: 0 };
      this.plan = [];
      this.stateUntil = 0;
      this.mouse = { x: null, y: null, cx: null, cy: null, seen: 0 };
      this.cur = { x: null, y: null, ax: 0, ay: 0, movedAt: 0, t: 0 };   // pointer anywhere on the screen (container px)
      this.huntReq = null; this.huntGame = null; this.huntBusy = 0; this.lastHuntAt = 0;
      this.hovering = false;
      this.dragging = null;
      this.queue = [];
      this.visible = true;
      this.destroyed = false;
      this.lastTs = 0;
      this.zzzTimer = 0;
      this.edges = [];                // window edges reaching the floor: [{x, side, kind, win:{x,y,w,h}}]
      this.icons = [];                // desktop icons: [{x,y,w,h}]
      this.activeClip = null;
      this.vel = { x: 0, y: 0 };
      this.walk = null;
      this.ready = false;
      this.lastTop = null;
      this.windows = [];              // all visible windows: [{x,y,w,h}] (landing spots when dropped)
      this.mood = null; this.moodUntil = 0;

      this._buildDom();
      const ok = this.V && videoSupported() && !o.forceSprites;
      const load = ok ? this._buildVideos() : Promise.resolve(false);
      load.then((good) => {
        if (!good) { this._unsupported(); return; }
        const b = this.bounds();
        this._setSurfaceFloor(b);
        this.pos.x = clamp(b.left + (b.right - b.left) * rand(0.3, 0.7), b.left, b.right);
        this.pos.y = b.floorY;
        this.ready = true;
        this._play('stand');
        this.state = 'loop'; this.stateUntil = performance.now() + rand(1500, 3000);
        this._setDataState('stand');
        this._applySize();
        this._loop = this._loop.bind(this);
        requestAnimationFrame(this._loop);
      });
    }

    /* ---------- public API ---------- */

    setSettings(partial) {
      const prev = Object.assign({}, this.settings);
      Object.assign(this.settings, partial);
      const s = this.settings;
      if (s.size !== prev.size) { this._applySize(); }
      if (s.speed !== prev.speed || s.activity !== prev.activity) this._applyRates();
      this.root.style.opacity = (s.workMode && s.workBehavior === 'sleep') ? s.workOpacity : 1;
      if (s.workMode !== prev.workMode) this._workModeChanged();
      else if (s.workMode && (s.workBehavior !== prev.workBehavior || s.workCorner !== prev.workCorner)) this._workModeChanged();
      if (s.mode !== prev.mode || s.followMouse !== prev.followMouse) {
        this.huntReq = null; this.huntGame = null; this.stay = null; this.excited = 0;
        if (this._mode() === 'hunt' && this.butterfly) { this.butterfly = null; this.bfly.hidden = true; }
      }
    }
    _mode() { const m = this.settings.mode; return m === 'spontaneous' || m === 'hunt' || m === 'click' ? m : (this.settings.followMouse === false ? 'spontaneous' : 'click'); }
    /** the pointer position from the app (it is not over the cat window's own events everywhere) */
    setCursor(x, y) { if (x != null && y != null) this._cursorAt(x, y); }
    setWorkMode(on) { this.setSettings({ workMode: !!on }); }
    setEdges(edges) {
      this.edges = Array.isArray(edges) ? edges : [];
      // the window we sit on (or climb) moved or closed?
      const same = (w) => this.edges.find((e) => e.win && Math.abs(e.win.x - w.x) < 3 && Math.abs(e.win.y - w.y) < 3 && Math.abs(e.win.w - w.w) < 3);
      if (this.ready && this.surface.kind === 'window' && !same(this.surface.win)) this._fallOff();
      else if (this.ready && this.climb && (this.state === 'climbing' || this.state === 'transition') && !same(this.climb.t.win)) this._fallOff();
    }
    setIcons(icons) { this.icons = Array.isArray(icons) ? icons : []; }
    setWindows(wins) { this.windows = Array.isArray(wins) ? wins : []; }
    setActiveWindow(r) { this.activeWin = r && r.w ? r : null; }
    setQuiet(on) {
      on = !!on;
      if (on === this.quiet) return;
      this.quiet = on;
      if (on) { this.mood = 'sleepy'; this.moodUntil = performance.now() + 3600000; if (this.butterfly) { this.butterfly = null; this.bfly.hidden = true; } }
      else this.moodUntil = 0;
      this.onEvent('quiet', { on });
    }
    setPomodoro(p) {
      this.pomodoro = p && p.endsAt ? p : null;
      this.timerEl.hidden = !this.pomodoro;
      this.timerEl.dataset.phase = this.pomodoro ? this.pomodoro.phase : '';
      this._tickTimer(true);
    }

    remind(r) {
      const rem = Object.assign({ important: false }, typeof r === 'string' ? { text: r } : r);
      if (this.settings.workMode && !rem.important) { this.onEvent('reminderSuppressed', rem); return false; }
      this.queue.push(rem);
      this._nextBubble();
      return true;
    }
    say(text, ms, always) { if (this.quiet && !always) return; this.queue.push({ text, ms: ms || 2000, chatter: true }); this._nextBubble(); }
    hide() { this.visible = false; this.root.hidden = true; this._interactive(false); }
    show() { this.visible = true; this.root.hidden = false; }
    isVisible() { return this.visible; }
    callTo(x) { if (!this.ready || this.state === 'drag') return; this._leaveTopThen([{ go: x, mode: Math.abs(x - this.pos.x) > 500 ? 'run' : 'walk' }, { loop: 'stand', seconds: rand(2, 4) }]); }
    sleepNow() { if (!this.ready || this.state === 'drag') return; this._setPlan(this._pathTo('sleep').concat([{ loop: 'sleep', seconds: rand(60, 200) }])); }
    wakeUp() { if (this.ready && this.pose === 'sleep') this._setPlan([{ clip: 'wakeUp' }, { clip: 'standUp' }, { loop: 'stand', seconds: 2 }]); }
    pet() { this._clicked(); }
    /** the user clicked somewhere on the desktop: go there (onto the window if it is one) and stay */
    goToPoint(x, y) {
      const mode = this._mode();
      if (mode === 'spontaneous') return false;                 // she decides for herself
      if (mode === 'hunt') return this._huntClick(x, y);
      if (!this.ready || this.settings.workMode || this.quiet || !this.visible) return false;
      if (this.pose === 'sleep' || this.activeClip === 'lieDown' || this.activeClip === 'sleep') return false;   // asleep: only a click on her wakes her
      if (this.state === 'drag' || this.state === 'fall' || this.state === 'climbing' || this.state === 'jumping') return false;
      const now = performance.now();
      this.stay = { until: now + rand(8, 15) * 60000 };
      const restOnTop = Math.random() < 0.55 ? 'sit' : 'sleep';
      // sitting down moves the body forward: aim so that the sitting cat ends up where the click was
      const sd = this.clips.sitDown, k = this._k();
      const sitShift = sd ? (sd.endAnchor[0] - sd.startAnchor[0]) * k : 0;
      x -= sitShift;
      const win = this._windowAt(x + sitShift, y);
      if (win) {
        const half = this._halfWidth();
        const topX = clamp(x, win.x + half * 0.5, win.x + win.w - half * 0.5 - sitShift);
        if (this.surface.kind === 'window' && this._sameWin(this.surface.win, win)) {
          this._setPlan([{ go: topX, mode: 'walk' }, { settle: restOnTop, seconds: rand(120, 400) }], true);
          this.onEvent('goto', { x, y, win: true }); return true;
        }
        // a climb up the window's front ends sitting this far right of the claws: climb so she ends at the click
        const cj = this.clips.climbJump, ct = this.clips.climbTop;
        const climbShift = (cj && ct) ? (-(cj.panelX - cj.startAnchor[0]) + (cj.endAnchor[0] - cj.startAnchor[0]) + (ct.endAnchor[0] - ct.startAnchor[0])) * k : 0;
        const t = this._climbTargetFor(win, x + sitShift - climbShift);
        if (t) {
          this._leaveTopThen([{ go: t.standX, mode: Math.abs(t.standX - this.pos.x) > 600 ? 'run' : 'walk', face: 1 }, { nudge: t.standX, face: 1 }, { climb: t },
            { go: t.face ? x + sitShift : topX, mode: 'walk', within: t.face ? 140 * k * 2 : 30 * k }, { settle: restOnTop, seconds: rand(120, 400) }]);
          this.onEvent('goto', { x, y, win: true }); return true;
        }
      }
      const bd = { left: this.bounds().left + this._halfWidth(), right: this.bounds().right - this._halfWidth() };
      const tx = clamp(x, bd.left, bd.right);
      this._leaveTopThen([{ go: tx, mode: Math.abs(tx - this.pos.x) > 650 ? 'run' : 'walk' }, { settle: 'sit', seconds: rand(60, 200) }]);
      this.onEvent('goto', { x, y, win: false });
      return true;
    }
    chase() { if (this.ready) this._startChase(true); }
    climbNow() { if (!this.ready) return false; const t = this._climbTarget(); if (!t) return false; this._planClimb(t); return true; }
    get status() { return this.state; }
    destroy() { this.destroyed = true; this.root.remove(); }

    /* ---------- dom ---------- */

    bounds() { const b = this.boundsFn(); return { left: b.left || 0, right: b.right, floorY: b.floorY }; }

    _buildDom() {
      const root = document.createElement('div');
      root.className = 'cat-root is-video';
      root.innerHTML = '<div class="cat-clips"></div><div class="cat-anchor"><div class="cat-bubble" hidden><span class="cat-bubble-text"></span><button class="cat-bubble-x" type="button" aria-label="OK">✓</button></div><div class="cat-fx"></div><div class="cat-timer" hidden><span class="cat-timer-dot"></span><span class="cat-timer-text">25:00</span></div></div><div class="cat-butterfly" hidden><svg viewBox="0 0 40 30" width="40" height="30"><g class="wing wl"><path d="M19 15 C 10 2, 0 4, 2 13 C 3 19, 12 20, 19 15 Z" fill="#ffb347"/><path d="M19 15 C 10 26, 2 28, 2 20 C 2 16, 12 15, 19 15 Z" fill="#ff8c42"/></g><g class="wing wr"><path d="M21 15 C 30 2, 40 4, 38 13 C 37 19, 28 20, 21 15 Z" fill="#ffb347"/><path d="M21 15 C 30 26, 38 28, 38 20 C 38 16, 28 15, 21 15 Z" fill="#ff8c42"/></g><rect x="18.6" y="7" width="2.8" height="16" rx="1.4" fill="#4a3728"/></svg></div>';
      this.container.appendChild(root);
      this.root = root;
      this.clipsEl = root.querySelector('.cat-clips');
      this.anchorEl = root.querySelector('.cat-anchor');
      this.bubble = root.querySelector('.cat-bubble');
      this.bubbleText = root.querySelector('.cat-bubble-text');
      this.fx = root.querySelector('.cat-fx');
      this.bfly = root.querySelector('.cat-butterfly');
      this.timerEl = root.querySelector('.cat-timer');
      this.timerText = root.querySelector('.cat-timer-text');

      window.addEventListener('mousemove', (e) => this._pointerMove(e.clientX, e.clientY), { passive: true });
      window.addEventListener('mouseleave', () => { this.mouse.x = null; this._setHover(false); });
      window.addEventListener('mousedown', (e) => { if (e.button === 0 && this.visible && this.ready && this._hit(e.clientX, e.clientY, true, 8)) this._dragStart(e); });
      window.addEventListener('mouseup', (e) => this._dragEnd(e));
      window.addEventListener('contextmenu', (e) => { if (this.visible && this.ready && this._hit(e.clientX, e.clientY, true)) { e.preventDefault(); this.onEvent('contextmenu', { x: e.clientX, y: e.clientY }); } });
      this.bubble.querySelector('.cat-bubble-x').addEventListener('click', (e) => { e.stopPropagation(); this._closeBubble(); });
      this.bubble.addEventListener('click', () => this._closeBubble());
      window.addEventListener('touchstart', (e) => { const t = e.touches[0]; if (t && this.visible && this.ready && this._hit(t.clientX, t.clientY, true)) this._dragStart({ clientX: t.clientX, clientY: t.clientY, preventDefault() {} }); }, { passive: true });
      window.addEventListener('touchmove', (e) => { const t = e.touches[0]; if (t) this._pointerMove(t.clientX, t.clientY); }, { passive: true });
      window.addEventListener('touchend', (e) => this._dragEnd(e));
    }

    _unsupported() {
      this.root.classList.add('is-unsupported');
      const n = document.createElement('div');
      n.className = 'cat-unsupported';
      n.textContent = this.settings.lang === 'en' ? 'This browser cannot play the transparent cat clips (VP9 alpha). Please open the preview in Chrome.' : 'Tento prehliadač nevie prehrať priehľadné klipy mačky (VP9 alpha). Otvor náhľad v Chrome.';
      this.root.appendChild(n);
      this.onEvent('fallback', {});
    }

    _buildVideos() {
      this.videos = {};
      const jobs = [];
      for (const id in this.clips) {
        const c = this.clips[id];
        const v = document.createElement('video');
        v.muted = true; v.playsInline = true; v.preload = 'auto'; v.loop = !!c.loop; v.disablePictureInPicture = true;
        v.setAttribute('muted', ''); v.setAttribute('playsinline', '');
        v.dataset.clip = id;
        v.src = this.baseUrl + c.file;
        this.clipsEl.appendChild(v);
        this.videos[id] = v;
        jobs.push(new Promise((res) => {
          const done = () => res();
          v.addEventListener('loadeddata', done, { once: true });
          v.addEventListener('error', done, { once: true });
          setTimeout(done, 15000);
        }));
        v.addEventListener('ended', () => this._clipEnded(id));
      }
      for (const id in this.clips) {                      // cumulative distance of the per-frame speed profiles (base px)
        const c = this.clips[id];
        if (c.speedProfile && c.speedProfile.length) { let acc = 0; c._cum = c.speedProfile.map((v) => (acc += v / (c.fps || 24))); c._total = acc; }
      }
      return Promise.all(jobs).then(() => {
        const ok = ['stand', 'walk', 'walkStart', 'walkStop'].every((id) => this.videos[id] && this.videos[id].readyState >= 2);
        if (!ok) { this.clipsEl.innerHTML = ''; this.videos = {}; }
        return ok;
      });
    }

    _k() { return this.settings.size / (this.pet.baseHeight || 300); }
    _clip(id) { return this.clips[id]; }
    _has(id) { return !!(this.clips[id] && this.videos && this.videos[id] && !this.videos[id].error); }
    _dur(id) { const c = this._clip(id); return c ? c.frames / (c.fps || 24) : 0; }

    _applySize() {
      const k = this._k();
      for (const id in this.videos) { const c = this.clips[id]; this.videos[id].style.width = (c.w * k) + 'px'; this.videos[id].style.height = (c.h * k) + 'px'; }
      this._placeActive();
      this.bubble.style.bottom = (this._headH() + 10) + 'px';
    }
    _applyRates() { for (const id in this.videos) this.videos[id].playbackRate = this._rate(id); }
    _rate(id) {
      const a = ACTIVITY[this.settings.activity] || ACTIVITY.normal;
      const base = clamp(this.settings.speed * a.speed, 0.5, 2.0);
      const ex = this.excited && performance.now() < this.excited ? 1.5 : 1;    // after the pointer: everything a bit quicker
      if (/^(walk|run)/.test(id)) return base * ex * (this.walk && this.walk.f ? this.walk.f : 1);
      return clamp(base, 0.6, 1.5) * ex;
    }

    /* place the active (and fading) video elements for the current world position */
    _placeActive() {
      const id = this.activeClip; if (!id) return;
      const v = this.videos[id], c = this.clips[id], k = this._k();
      v.style.transform = `translate(${(this.pos.x - c.startAnchor[0] * k).toFixed(1)}px, ${(this.pos.y - c.startAnchor[1] * k).toFixed(1)}px)`;
      this.anchorEl.style.transform = `translate(${this.pos.x.toFixed(1)}px, ${this.pos.y.toFixed(1)}px)`;
    }

    _setDataState(st) { this.root.dataset.state = st; this.onEvent('state', { state: st }); }

    /** play a clip at the current world position; the previous clip fades out where it was.
     *  Every clip waits rewound to its first frame. If it is not there yet (it was cut off mid-way a moment ago),
     *  it seeks first and the old clip stays on screen until the new frame is ready – otherwise the frame it was
     *  left on flashes up for a frame or two at the wrong spot (the flicker while walking). */
    _play(id, opts) {
      const v = this.videos[id]; if (!v) return false;
      opts = opts || {};
      const prev = this.activeClip;
      if (prev === id && !opts.restart) { this._placeActive(); return true; }
      const cut = !!opts.cut || this.settings.reduceMotion;
      const want = opts.at || 0;
      const fps = (this.clips[id] && this.clips[id].fps) || 24;
      const ready = prev === id || (!v.seeking && Math.abs((v.currentTime || 0) - want) < 0.5 / fps);
      // clips still on screen: the previous one, and any kept up by a switch that was still waiting for its frame
      let olds = [];
      if (this._pending) { olds = this._pending.olds; clearTimeout(this._pending.timer); this._pending = null; }
      if (prev && prev !== id && this.videos[prev]) {
        const pv = this.videos[prev];
        pv.classList.remove('is-active');
        if (pv._shown) olds.push({ v: pv, id: prev }); else this._retire(pv, prev, true);
      }
      olds = olds.filter((o) => o.id !== id);
      this.activeClip = id;
      if (!ready || opts.restart || want) { try { v.currentTime = want; } catch (e) {} }
      v.playbackRate = this._rate(id);
      this._placeActive();
      if (!opts.paused) { const p = v.play(); if (p && p.catch) p.catch(() => {}); }
      const swap = () => {
        this._pending = null;
        if (this.activeClip === id) { v.style.transition = 'none'; v.style.opacity = '1'; v._shown = true; v.classList.add('is-active'); }
        for (const o of olds) {
          if (o.id === this.activeClip) continue;
          // a hard cut keeps the old frame (same pose, same spot) one more frame, so there is never a frame without the cat
          if (cut) { o.v.pause(); requestAnimationFrame(() => { if (o.id !== this.activeClip) this._retire(o.v, o.id, true); }); }
          else this._retire(o.v, o.id, false);
        }
      };
      if (ready) swap();
      else {
        v.style.transition = 'none'; v.style.opacity = '0'; v._shown = false;
        const p = this._pending = { id, olds, timer: null };
        const go = () => { if (this._pending === p) swap(); };
        v.addEventListener('seeked', () => requestAnimationFrame(go), { once: true });
        p.timer = setTimeout(go, 250);
      }
      this.clipStart = performance.now();
      this.onEvent('clip', { clip: id });
      return true;
    }

    /** take a clip off the screen (fade or cut) and rewind it to its first frame, ready for next time */
    _retire(pv, id, cut) {
      pv._shown = false;
      const rewind = () => { if (this.activeClip === id) return; pv.pause(); try { if (pv.currentTime !== 0) pv.currentTime = 0; } catch (e) {} };
      if (cut) { pv.style.transition = 'none'; pv.style.opacity = '0'; rewind(); }
      else { pv.style.transition = `opacity ${FADE_MS}ms ease`; pv.style.opacity = '0'; setTimeout(rewind, FADE_MS + 30); }
    }

    /** world position after the running clip ends: chain anchors */
    _advanceAnchors(id) {
      const c = this.clips[id], k = this._k();
      this.pos.x += (c.endAnchor[0] - c.startAnchor[0]) * k;
      this.pos.y += (c.endAnchor[1] - c.startAnchor[1]) * k;
    }

    _clipEnded(id) {
      if (id !== this.activeClip || this.destroyed) return;
      const c = this.clips[id];
      if (c.loop) return;
      if (this.hold && this.hold.id === id && this.state === 'loop') {      // held clip: replay or rest on the last frame
        if (this.hold.plays > 0) { this.hold.plays--; this._play(id, { restart: true, cut: true }); }
        return;
      }
      this._advanceAnchors(id);
      if (c.to) this.pose = c.to;
      if (this.state === 'walking') {              // start clip finished → loop (or straight into the stop without a loop clip)
        if (this.walk.stopAtHandover || this.walk.noLoop) { this._beginStop(); return; }
        this.walk.phase = 'loop';
        this._play(this.walk.g.loop, { cut: true });
        return;
      }
      if (this.state === 'stopping') {
        const face = this.walk && this.walk.face; this.state = 'idle'; this.walk = null;
        if (face && FACING[this.pose] !== face) this.plan.unshift(...this._pathTo(face === 1 ? 'stand' : 'standL', this.pose));
        this._nextStep(); return;
      }
      if (this.state === 'jumping') { this._jumpLanded(); return; }
      if (this.state === 'transition') { this.state = 'idle'; this._nextStep(); return; }
      if (this.state !== 'drag' && this.state !== 'fall') { this.state = 'idle'; this._nextStep(); }
    }

    _box() { const c = this.activeClip && this.clips[this.activeClip]; return (c && c.box) || [0, 0, 100, 100]; }
    _headH() { const c = this.activeClip && this.clips[this.activeClip]; if (!c) return 100; return (c.startAnchor[1] - c.box[1]) * this._k(); }
    _bodyWidth() { const c = this.clips.stand; return c ? (c.box[2] - c.box[0]) * this._k() : 120; }
    _halfWidth() {
      const c = this.clips.stand || this.clips[this.activeClip];
      return (c ? Math.max(c.startAnchor[0] - c.box[0], c.box[2] - c.startAnchor[0]) : 60) * this._k() * 0.55;
    }
    /** client rect of the cat's body (active clip box) */
    _bodyRect() {
      const c = this.clips[this.activeClip]; const k = this._k();
      const cr = this.container.getBoundingClientRect();
      if (!c) return { left: cr.left, right: cr.left, top: cr.top, bottom: cr.top, width: 0, height: 0 };
      const ox = cr.left + this.pos.x - c.startAnchor[0] * k, oy = cr.top + this.pos.y - c.startAnchor[1] * k;
      return { left: ox + c.box[0] * k, right: ox + c.box[2] * k, top: oy + c.box[1] * k, bottom: oy + c.box[3] * k, width: (c.box[2] - c.box[0]) * k, height: (c.box[3] - c.box[1]) * k };
    }

    /* ---------- pose graph planner ---------- */

    _poseAfter() {
      if ((this.state === 'transition' || this.state === 'jumping') && this.activeClip && this.clips[this.activeClip]) return this.clips[this.activeClip].to || this.pose;
      if (this.state === 'walking' || this.state === 'stopping') return this.walk ? this.walk.g.stand : 'stand';
      if (this.state === 'climbing') return 'cling';
      return this.pose;
    }

    _graph() {
      if (this._g) return this._g;
      const g = {};
      for (const id in this.clips) {
        const c = this.clips[id];
        if (!c.from || !c.to || c.loop || c.from === c.to) continue;
        if (id === 'climbJump' || id === 'climbTop' || id === 'jumpDown' || id === 'pounce') continue;   // only used by composites
        (g[c.from] = g[c.from] || {});
        if (!g[c.from][c.to] || this._dur(id) < this._dur(g[c.from][c.to])) g[c.from][c.to] = id;
      }
      return (this._g = g);
    }

    _pathTo(target, from) {
      const start = from || this._poseAfter();
      if (start === target) return [];
      const g = this._graph();
      const q = [[start, []]]; const seen = new Set([start]);
      while (q.length) {
        const [p, path] = q.shift();
        if (p === target) return path.map((c) => ({ clip: c }));
        for (const n in g[p] || {}) if (!seen.has(n) && this._has(g[p][n])) { seen.add(n); q.push([n, path.concat([g[p][n]])]); }
      }
      return [];
    }

    /** replace the plan; a running clip finishes first, a walk ends through its stop clip */
    _setPlan(steps, now) {
      this.plan = steps.slice();
      if (this.state === 'walking') {
        // already walking the right way and the new target is still ahead: just walk on to it (no stop and restart)
        const s0 = steps[0], w = this.walk;
        if (s0 && s0.go != null && !s0.wrap && w.wrapTo == null && w.outX == null && !w.abort && ((s0.mode || 'walk') === w.mode || w.mode === 'run')) {
          const bd = this._bands(), tx = clamp(s0.go, bd.left, bd.right);
          const stopC = this.clips[w.g.stop], stopDist = stopC && stopC._total != null ? stopC._total * this._k() : 0;
          if ((tx - this.pos.x) * w.dir > stopDist * 0.9 + 20) {
            w.target = tx; w.face = s0.face || 0; w.stopAt = null; w.stopAtHandover = false;
            this.plan = steps.slice(1);
            return;
          }
        }
        this.walk.abort = true; return;
      }
      if (this.state === 'transition' || this.state === 'stopping' || this.state === 'drag' || this.state === 'fall' || this.state === 'jumping') return;
      if (this.state === 'climbing') { this.walk = null; this.state = 'idle'; }
      if (now || this.state === 'idle' || this.state === 'loop' || this.state === 'hidden') this._nextStep();
    }

    _nextStep() {
      if (this.destroyed) return;
      this.hold = null;
      const step = this.plan.shift();
      if (!step) { this._decide(); return; }
      if (step.go != null) {
        if (step.within && Math.abs(step.go - this.pos.x) < step.within) { this._nextStep(); return; }   // close enough: stay
        this._beginGo(step.go, step.mode || 'walk', step.face, step.wrap); return;
      }
      if (step.settle) {                   // get into a resting pose from wherever she is, then rest there
        const target = step.settle;
        this.plan.unshift(...this._pathTo(target, this.pose), { loop: target, seconds: step.seconds || 30 });
        this._nextStep(); return;
      }
      if (step.nudge != null) {
        const dx = step.nudge - this.pos.x;
        if (Math.abs(dx) < 1) { this._nextStep(); return; }
        if (Math.abs(dx) > 90) { this.plan.unshift({ go: step.nudge, mode: 'walk', face: step.face }, { nudge: step.nudge, face: step.face }); this._nextStep(); return; }
        this.nudge = { x: step.nudge };
        this.state = 'nudging';
        if (this.pose !== 'stand' && this.pose !== 'standL') { this.state = 'idle'; this.plan.unshift(...this._pathTo(step.face === -1 ? 'standL' : 'stand', this.pose), { nudge: step.nudge, face: step.face }); this._nextStep(); return; }
        this._play(this.pose === 'standL' ? 'standL' : 'stand');
        return;
      }
      if (step.climb) { this._beginClimbUp(step.climb); return; }
      if (step.jumpDown) { this._beginJumpDown(); return; }
      if (step.fn) { try { step.fn(); } catch (e) {} if (this.state === 'idle' || this.state === 'loop') this._nextStep(); return; }
      if (step.clip) {
        if (!this._has(step.clip)) { this._nextStep(); return; }
        const c = this.clips[step.clip];
        if (c.from && c.from !== this.pose && !step.force) {
          const path = step.retried ? [] : this._pathTo(c.from, this.pose);
          if (!path.length) { this._nextStep(); return; }                // unreachable: skip the clip
          this.plan.unshift(...path, Object.assign({}, step, { retried: true }));
          this._nextStep(); return;
        }
        this.state = 'transition';
        this._setDataState(step.clip);
        this._play(step.clip, { cut: !!step.cut });
        return;
      }
      if (step.loop === 'belly') { step.hold = 'belly'; step.plays = step.plays || 1; delete step.loop; }
      if (step.hold) {
        // play a short clip a couple of times, then rest on its last frame (belly wriggle)
        if (!this._has(step.hold)) { this._nextStep(); return; }
        this.pose = step.hold;
        this.hold = { id: step.hold, plays: Math.max(0, (step.plays || 1) - 1) };
        this._setDataState(step.hold);
        this._play(step.hold, { restart: true });
        this.state = 'loop'; this.stateUntil = performance.now() + (step.seconds || 5) * 1000;
        return;
      }
      if (step.loop) {
        // a standing loop follows the way the cat is facing
        if (step.loop === 'stand' && this.pose === 'standL' && this._has('standL')) step.loop = 'standL';
        else if (step.loop === 'standL' && this.pose === 'stand') step.loop = 'stand';
        if (!this._has(step.loop)) { this.state = 'idle'; this.stateUntil = performance.now() + 500; return; }
        this.pose = step.loop;
        if (step.loop === 'sit') { if (!this.sitSince) this.sitSince = performance.now(); }
        else if (step.loop !== 'sleep' && step.loop !== 'belly') this.sitSince = 0;
        this._setDataState(step.loop === 'sleep' && this.settings.workMode ? 'worksleep' : step.loop);
        this._play(step.loop);
        this.state = 'loop'; this.stateUntil = performance.now() + (step.seconds || 5) * 1000;
        return;
      }
      if (step.hide) { this.hide(); this.state = 'hidden'; this._setDataState('hidden'); return; }
      if (step.wait) { this.state = 'idle'; this.stateUntil = performance.now() + step.wait * 1000; return; }
      this._nextStep();
    }

    /* ---------- walking / running ---------- */

    _bands() {
      const b = this.bounds(); const half = this._halfWidth();
      if (this.surface.kind === 'window') return { left: this.surface.left + half * 0.4, right: this.surface.right - half * 0.4 };
      return { left: b.left + half, right: b.right - half };
    }

    /** walk (or run) to x. The pose graph brings the cat to the standing pose facing the right way first. */
    _beginGo(x, mode, face, wrap) {
      const bd = this._bands();
      let tx = clamp(x, bd.left, bd.right);
      let wrapTo = null, outX = null;
      if (wrap && this.surface.kind === 'floor') {
        // dash off the screen and come back from the other side
        const b = this.bounds(), W = this._bodyWidth() + 20;
        tx = wrap > 0 ? b.right + W : b.left - W;
        outX = wrap > 0 ? b.left - W : b.right + W;
        wrapTo = wrap > 0 ? rand(bd.left, bd.left + (bd.right - bd.left) * 0.5) : rand(bd.left + (bd.right - bd.left) * 0.5, bd.right);
      }
      const dir = Math.sign(tx - this.pos.x) || face || FACING[this.pose] || 1;
      if (mode === 'run' && wrapTo == null) {
        // a gallop cannot stop before the first stride of its start clip: shorter distances are walked (else she overshoots)
        const sc = this.clips[GAIT[dir].run.start], st = this.clips[GAIT[dir].run.stop];
        const minRun = sc && sc._cum && st && st._total != null ? ((sc.syncTimes && sc.syncTimes.length ? this._profCum(sc, sc.syncTimes[0]) : sc._total) + st._total * 0.75) * this._k() * 1.05 : 0;
        if (Math.abs(tx - this.pos.x) < minRun) mode = 'walk';
      }
      const g = (GAIT[dir] || GAIT[1])[mode === 'run' && this._has(GAIT[dir].run.start) && this._has(GAIT[dir].run.stop) ? 'run' : 'walk'];
      if (Math.abs(tx - this.pos.x) < 14 && wrapTo == null) {
        // already there: just face the requested way
        if (face && FACING[this.pose] !== face) { this.plan.unshift(...this._pathTo(face === 1 ? 'stand' : 'standL')); }
        this._nextStep(); return;
      }
      const standPose = g.stand;
      if (wrapTo == null && Math.abs(tx - this.pos.x) < 40 && (this.pose === 'stand' || this.pose === 'standL') && this.pose !== standPose) {
        // a few px behind her: shuffle over instead of turning round, walking and turning back
        this.plan.unshift({ nudge: tx, face: face || FACING[this.pose] });
        this._nextStep(); return;
      }
      if (this.pose !== standPose) {        // turn first, then walk
        const path = this._pathTo(standPose, this.pose);
        if (!path.length) { this._nextStep(); return; }
        this.plan.unshift(...path, { go: x, mode, face, wrap });
        this._nextStep(); return;
      }
      this.walk = { g, dir, face: face || 0, target: tx, phase: 'start', t: 0, f: 1, abort: false, stopAt: null, stopAtHandover: false, lastT: null, mode: g === GAIT[dir].run ? 'run' : 'walk', noLoop: !this._has(g.loop), wrapTo, outX };
      this.state = 'walking';
      this._setDataState(this.walk.mode);
      this._applyRates();
      if (this._has(g.start)) this._play(g.start);
      else { this.walk.phase = 'loop'; this._play(g.loop); }
    }

    _speed() {             // ground speed of the current gait loop, container px/s at the current rate
      const w = this.walk; const c = this.clips[w.g.loop] || this.clips[w.g.start];
      const base = (c && c.speed) || (w.mode === 'run' ? 480 : 190);
      return base * this._k() * this._rate(w.g.loop);
    }

    _profSpeed(c, t) {            // base px/s from the clip's measured profile at video time t
      if (!c || !c.speedProfile) return null;
      const i = clamp(Math.floor(t * (c.fps || 24)), 0, c.speedProfile.length - 1);
      return c.speedProfile[i];
    }
    _profCum(c, t) {              // base px covered by the clip up to video time t
      if (!c || !c._cum) return 0;
      const i = clamp(Math.floor(t * (c.fps || 24)), 0, c._cum.length - 1);
      return c._cum[i];
    }

    _tickWalk(dt) {
      const w = this.walk; if (!w) return;
      const startC = this.clips[w.g.start], loopC0 = this.clips[w.g.loop], stopC = this.clips[w.g.stop];
      const v = this.videos[w.phase === 'start' ? w.g.start : w.g.loop];
      const t = v ? (v.currentTime || 0) : 0;
      const k = this._k(), rate = this._rate(w.g.loop);
      const spLoop = this._speed();
      w.t += dt;
      // the feet drive the motion: measured per-frame speed of the start clip, then the loop's ground speed
      let sp = spLoop;
      if (w.phase === 'start') {
        const ps = this._profSpeed(startC, t);
        if (ps != null) sp = ps * k * rate;
        else { const tAcc = Math.min(0.9, this._dur(w.g.start) / rate * 0.5); sp = spLoop * smooth(w.t / Math.max(0.05, tAcc)); }
      }
      this.pos.x += w.dir * sp * dt;
      if (w.wrapTo != null && (w.target - this.pos.x) * w.dir <= 0) {      // fully off screen: reappear on the other side
        this.pos.x = w.outX; w.target = w.wrapTo; w.wrapTo = null; w.outX = null;
        w.abort = false; w.stopAt = null; w.stopAtHandover = false;
        this.onEvent('wrap', {});
      }
      const remaining = (w.target - this.pos.x) * w.dir;                  // signed: negative = already past the target
      const stopDist = stopC ? (stopC._total != null ? stopC._total * k : spLoop * this._stopSeconds(w) / 2) : 0;
      const abort = w.abort && w.wrapTo == null;                          // an off-screen dash always comes back first
      if (!stopC) { if (remaining < 2 || abort) { this.state = 'idle'; this.walk = null; this._nextStep(); } return; }

      // Where can the stop begin? Only at gait sync points (feet in the keyframe pose). Upcoming points are
      // listed by distance; the next one is taken once the target lies nearer to it than to the one after it.
      const need = remaining - stopDist;
      const loopC = loopC0;
      const lsync = (loopC && loopC.syncTimes && loopC.syncTimes.length) ? loopC.syncTimes : [0];
      const D = this._dur(w.g.loop);
      const loopSp = spLoop;                                              // px/s in the loop
      const upcoming = [];
      if (w.phase === 'start') {
        if (w.wrapTo != null) return;
        if (w.stopAt != null && w.stopAt.inStart) { if (t >= w.stopAt.t) this._beginStop(); return; }
        if (w.stopAtHandover) return;
        const cum0 = startC && startC._cum ? this._profCum(startC, t) : 0;
        const left = startC && startC._cum ? Math.max(0, startC._total - cum0) * k : Math.max(0, this._dur(w.g.start) / rate - w.t) * sp;
        for (const st of (startC && startC.syncTimes) || []) if (st > t + 0.05 && startC._cum) upcoming.push({ kind: 'start', t: st, dist: Math.max(0, this._profCum(startC, st) - cum0) * k });
        upcoming.push({ kind: 'handover', dist: left });
        if (!w.noLoop) for (let n = 0; n < 2; n++) for (const st of lsync) if (st > 0.02 || n > 0) upcoming.push({ kind: 'loop', dist: left + (st + n * D) / rate * loopSp });
      } else {
        if (w.stopAt != null) {
          const wrapped = w.lastT != null && t < w.lastT - 0.05;
          const passed = w.stopAt.wrap ? wrapped : (w.lastT != null && w.lastT < w.stopAt.t && t >= w.stopAt.t);
          w.lastT = t;
          if (passed) { this._beginStop(); return; }
          if (wrapped && !w.stopAt.wrap) w.stopAt = null;                  // missed it (video jumped): re-plan
          else return;
        }
        if (w.wrapTo != null) { w.lastT = t; return; }
        for (let n = 0; n < 3; n++) for (const st of lsync) {
          const dv = st > t + 0.03 ? st - t + n * D : (D - t) + st + n * D;
          upcoming.push({ kind: 'loop', t: st, wrap: !(st > t + 0.03) && n === 0 && st <= 0.02, dist: dv / rate * loopSp, n });
        }
        w.lastT = t;
      }
      upcoming.sort((p, q) => p.dist - q.dist);
      if (!upcoming.length) return;
      const first = upcoming[0], second = upcoming[1];
      const takeFirst = abort || need <= 0 || !second || need <= (first.dist + second.dist) / 2;
      if (!takeFirst) return;
      if (w.phase === 'start') {
        if (first.kind === 'start') w.stopAt = { t: first.t, inStart: true };
        else if (first.kind === 'handover') w.stopAtHandover = true;
        // a loop point: decided again once the loop runs
      } else if (first.n === 0 || first.n == null) {
        w.stopAt = { t: first.t, wrap: first.wrap };
        if (first.t <= 0.02) w.stopAt.wrap = true;
      }
      if (w.noLoop && !w.stopAtHandover && w.stopAt == null && remaining <= stopDist + 1) this._beginStop();
    }

    _stopSeconds(w) { return Math.min(1.6, this._dur(w.g.stop) / this._rate(w.g.stop) * 0.7); }

    _beginStop() {
      const w = this.walk; if (!w) return;
      w.f = 1; this._applyRates();
      w.phase = 'stop'; w.stopT = 0;
      const k = this._k(), sp = this._speed();
      const stopC = this.clips[w.g.stop];
      const T = this._stopSeconds(w);
      const natural = stopC && stopC._total != null ? stopC._total * k : sp * T / 2;
      const remaining = (w.target - this.pos.x) * w.dir;        // signed distance still to cover
      // the feet decide the distance; only a little stretch/squeeze to land on the target, never a slide
      w.stopScale = (remaining > 0 && natural > 1) ? clamp(remaining / natural, 0.75, 1.25) : 0.75;
      w.stopT0 = T;
      this.state = 'stopping';
      this._setDataState(w.g.stop);
      if (!this._play(w.g.stop, { cut: true })) { this.state = 'idle'; this.pose = w.g.stand; this.walk = null; this._nextStep(); }
    }

    _tickStop(dt) {
      const w = this.walk; if (!w) return;
      const stopC = this.clips[w.g.stop]; const v = this.videos[w.g.stop];
      const scale = w.stopScale == null ? 1 : w.stopScale;
      w.stopT += dt;
      const ps = this._profSpeed(stopC, v ? v.currentTime || 0 : w.stopT);
      let sp;
      if (ps != null) sp = ps * this._k() * this._rate(w.g.stop) * scale;
      else { const u = clamp(w.stopT / Math.max(0.1, w.stopT0), 0, 1); sp = this._speed() * scale * (1 - smooth(u)); }
      this.pos.x += w.dir * sp * dt;
    }

    /* ---------- climbing ---------- */

    _climbTarget() {
      if (!this.settings.climbWindows) return null;
      const b = this.bounds();
      const cands = [];
      for (const w of this.windows || []) {
        if (b.floorY - w.y < this.settings.size * 2.2 || w.w < this.settings.size * 1.5 || w.y < 4) continue;   // too low / tiny / maximized
        const t = this._climbTargetFor(w, null);
        if (t) cands.push(t);
      }
      if (!cands.length) return null;
      cands.sort((p, q) => Math.abs(p.standX - this.pos.x) - Math.abs(q.standX - this.pos.x));
      return cands[0];
    }

    _sameWin(a, b) { return !!(a && b && Math.abs(a.x - b.x) < 4 && Math.abs(a.y - b.y) < 4 && Math.abs(a.w - b.w) < 4); }
    /** climb target for a given window (its left edge has to reach the floor) */
    _climbTargetFor(w, atX) {
      const k = this._k(), b = this.bounds(), cj = this.clips.climbJump;
      if (!cj || !this._has('climb') || !this._has('climbTop')) return null;
      if (b.floorY - (w.y + w.h) > Math.max(30, this.settings.size * 0.35)) return null;     // has to reach (nearly) the floor
      if (b.floorY - w.y < this.settings.size * 1.6 || w.w < this.settings.size * 1.2) return null;
      const reach = (cj.panelX - cj.startAnchor[0]) * k;                  // feet → claws
      const minStand = b.left + this._halfWidth() * 0.6;
      // the left edge, if she can stand next to it and it is not far from where she should end up
      const edgeStand = w.x - reach;
      if (edgeStand >= minStand && (atX == null || atX - w.x < Math.max(400, w.w * 0.5))) return { win: w, x: w.x, standX: edgeStand, top: w.y };
      // otherwise up the front of the window, right below the spot
      const clawX = clamp(atX == null ? w.x + w.w * 0.3 : atX, Math.max(w.x + 12, minStand + reach), w.x + w.w - this._halfWidth());
      return { win: w, x: clawX, standX: clawX - reach, top: w.y, face: true };
    }

    /** the window being used, if the cat can climb it */
    _activeTarget() {
      if (!this.settings.sitActive || !this.activeWin) return null;
      const w = (this.windows || []).find((x) => this._sameWin(x, this.activeWin)) || this.activeWin;
      if (this.bounds().floorY - w.y < this.settings.size * 2.2 || w.w < this.settings.size * 1.5 || w.y < 4) return null;
      return this._climbTargetFor(w, null);
    }

    _planClimb(t) {
      this._leaveTopThen([{ go: t.standX, mode: Math.abs(t.standX - this.pos.x) > 600 ? 'run' : 'walk', face: 1 }, { nudge: t.standX, face: 1 }, { climb: t }, { loop: 'sit', seconds: rand(6, 20) }]);
    }

    _beginClimbUp(t) {
      // stand → climbJump (once) → climb loop while moving up → climbTop (sits on the window top)
      if (this.pose !== 'stand') { const p = this._pathTo('stand', this.pose); if (!p.length) { this._nextStep(); return; } this.plan.unshift(...p, { climb: t }); this._nextStep(); return; }
      const k = this._k(), cj = this.clips.climbJump;
      // snap exactly to the edge (small walk errors)
      this.pos.x = t.x - (cj.panelX - cj.startAnchor[0]) * k;
      this.climb = { t, phase: 'jump' };
      this.state = 'transition';
      this._setDataState('climbJump');
      this._play('climbJump');
      this.plan.unshift({ fn: () => this._climbLoop() });
    }

    _climbLoop() {
      const k = this._k(), ct = this.clips.climbTop, cl = this.clips.climb;
      const t = this.climb.t;
      // the loop ends when climbTop's panel top meets the window top
      this.climb.targetY = t.top - (ct.panelTop - ct.startAnchor[1]) * k;
      this.climb.speed = (Math.max(cl.climbSpeed || 0, 110) * k) * this._rate('climb');
      this.state = 'climbing'; this.pose = 'cling';
      this._setDataState('climb');
      this._play('climb', { cut: true });
      if (this.pos.y <= this.climb.targetY) this._climbTopNow();
    }

    _tickClimb(dt) {
      const c = this.climb; if (!c) return;
      this.pos.y -= c.speed * dt;
      if (this.pos.y <= c.targetY) { this.pos.y = c.targetY; this._climbTopNow(); }
    }

    _climbTopNow() {
      const t = this.climb.t;
      this.state = 'transition';
      this._setDataState('climbTop');
      this._play('climbTop');
      this.plan.unshift({ fn: () => {
        this.surface = { kind: 'window', y: t.top, left: t.win.x, right: t.win.x + t.win.w, win: t.win };
        this.pose = 'sit';
        this.climb = null;
        this.onEvent('onTop', { win: t.win });
      } });
    }

    /** sitting on a window top: go to its left corner and jump down (then continue with `then`) */
    _leaveTopThen(then) {
      if (this.surface.kind !== 'window') { this._setPlan(then, true); return; }
      const k = this._k(), jd = this.clips.jumpDown;
      if (!jd) { this._fallOff(); this.plan = then.slice(); return; }
      const cornerX = this.surface.left + (jd.startAnchor[0] - jd.panelX) * k;
      const steps = [{ go: cornerX, mode: 'walk', face: 1 }, { nudge: cornerX, face: 1 }];
      this.plan = steps.concat([{ jumpDown: true }], then);
      if (this.state === 'walking') { this.walk.abort = true; return; }
      if (this.state === 'transition' || this.state === 'stopping' || this.state === 'drag' || this.state === 'fall' || this.state === 'jumping') return;
      this._nextStep();
    }

    _beginJumpDown() {
      if (this.surface.kind !== 'window') { this._nextStep(); return; }
      const path = this._pathTo('sit', this.pose);
      if (this.pose !== 'sit') { if (!path.length) { this._fallOff(); return; } this.plan.unshift(...path, { jumpDown: true }); this._nextStep(); return; }
      const k = this._k(), jd = this.clips.jumpDown, b = this.bounds();
      // snap to the corner, then play the jump; the drop in the clip is fixed – the rest is a physics fall
      this.pos.x = this.surface.left + (jd.startAnchor[0] - jd.panelX) * k;
      const clipDrop = (jd.endAnchor[1] - jd.startAnchor[1]) * k;
      const extra = (b.floorY - this.pos.y) - clipDrop;
      this.jump = { extra: Math.max(0, extra), done: false, air: jd.air || null, win: this.surface.win };
      this.state = 'jumping';
      this._setDataState('jumpDown');
      this._play('jumpDown');
    }

    _tickJump(dt) {
      const j = this.jump; if (!j || !j.air) return;
      const v = this.videos.jumpDown; const t = v.currentTime || 0;
      if (!j.done && j.extra > 0 && t >= j.air[0]) {
        // hold the mid-air frame while the extra height is covered by gravity
        if (!j.falling) { j.falling = true; j.vy = 450; v.pause(); }
        j.vy += GRAVITY * dt;
        const dy = Math.min(j.extra, j.vy * dt);
        this.pos.y += dy; j.extra -= dy;
        if (j.extra <= 0.5) { j.done = true; const p = v.play(); if (p && p.catch) p.catch(() => {}); }
      }
    }

    _jumpLanded() {
      const b = this.bounds();
      this._setSurfaceFloor(b);
      this.pos.y = b.floorY;
      this.jump = null;
      this.state = 'idle';
      this._nextStep();
    }

    _setSurfaceFloor(b) { this.surface = { kind: 'floor', y: b.floorY, left: b.left, right: b.right }; }

    /** the window under the cat is gone: fall to the floor */
    _fallOff() {
      const b = this.bounds();
      this._setSurfaceFloor(b);
      this.plan = []; this.walk = null; this.climb = null; this.jump = null;
      if (this.state === 'drag') return;
      this.vel.y = 0;
      this.state = 'fall';
      this._setDataState('fall');
      this._holdAir();
    }

    _holdAir() {
      const c = this.clips.hop;
      if (!c) return;
      this._play('hop', { cut: true, paused: true, at: c.holdTime || 0.9 });
      this.videos.hop.pause();
    }

    /* ---------- moods & decisions ---------- */

    /** moods pace the day: sleepy / calm / cuddly / playful, each for a few minutes */
    _pickMood(now) {
      const a = ACTIVITY[this.settings.activity] || ACTIVITY.normal;
      const night = this._isNight();
      const w = { sleepy: a.moodSleepy, calm: a.moodCalm, cuddly: a.moodCuddly, playful: a.moodPlayful };
      if (night) { w.sleepy *= 3; w.playful *= 0.3; }
      if (this.mood) w[this.mood] *= 0.4;                 // prefer a change
      this.mood = weighted(w);
      this.moodUntil = now + rand(4, 12) * 60000 * a.moodScale;
      this.onEvent('mood', { mood: this.mood });
    }
    setMood(m) { if (['sleepy', 'calm', 'cuddly', 'playful'].includes(m)) { this.mood = m; this.moodUntil = performance.now() + 10 * 60000; this.onEvent('mood', { mood: m }); } }

    _rest(kind) {                               // how long to idle after something, by mood
      const m = { sleepy: 1.8, calm: 1.3, cuddly: 1.0, playful: 0.55 }[this.mood] || 1;
      const a = ACTIVITY[this.settings.activity] || ACTIVITY.normal;
      return (kind === 'sit' ? rand(18, 50) : rand(3, 8)) * m * a.restScale;
    }

    _decide() {
      const s = this.settings, b = this.bounds();
      const a = ACTIVITY[s.activity] || ACTIVITY.normal;
      const night = this._isNight();
      const now = performance.now();
      if (!this.mood || now > this.moodUntil) this._pickMood(now);
      const mood = this.mood;
      if (s.workMode) {
        if (s.workBehavior === 'hide') { this._leaveTopThen([{ hide: true }]); return; }
        const half = this._halfWidth() + 10;
        const cx = s.workCorner === 'left' ? b.left + half : b.right - half;
        if (this.surface.kind === 'window' || (Math.abs(cx - this.pos.x) > 30 && this.pose !== 'sleep')) {
          this._leaveTopThen([{ go: cx, mode: 'walk', face: s.workCorner === 'left' ? -1 : 1 }, { clip: 'sitDown' }, { clip: 'lieDown' }, { loop: 'sleep', seconds: 3600 }]); return;
        }
        this._setPlan(this._pathTo('sleep').concat([{ loop: 'sleep', seconds: 3600 }]), true);
        return;
      }
      if (!this.bubble.hidden && this.currentBubble && !this.currentBubble.chatter) { this._setPlan([{ loop: this._restLoop(), seconds: 3 }], true); return; }

      const pose = this.pose;
      const onTop = this.surface.kind === 'window';
      const mouseNear = this.mouse.x != null && now - this.mouse.seen < 120000;
      const w = {};
      if (pose === 'stand' || pose === 'standL') {
        const bd = this._bands();
        if (mood === 'sleepy') { w.sitDown = 5; w.stand = 2; w.walk = 0.8; }
        else if (mood === 'calm') { w.walk = 2.5; w.sitDown = 3; w.stand = 2; w.rub = 1; w.climb = 0.6; w.hop = 0.3; }
        else if (mood === 'cuddly') { w.askPet = mouseNear ? 2.5 : 1; w.follow = mouseNear ? 2 : 0; w.sitDown = 2.5; w.stand = 1.5; w.walk = 1; w.rub = 0.8; }
        else { w.walk = 2; w.run = 2; w.dash = 0.8; w.chase = 1.6; w.folder = 1.3; w.climb = 1.3; w.hop = 1; w.leap = 0.8; w.sitDown = 1; w.rub = 0.5; }
        w.sitActive = (!onTop && mood !== 'sleepy' && this._activeTarget()) ? (mood === 'cuddly' ? 1.8 : 1) : 0;
        if (onTop) { w.run = 0; w.dash = 0; w.chase = 0; w.folder = 0; w.climb = 0; w.rub = 0; w.follow = 0; w.leaveTop = 1.5; }
        if (this.quiet) { w.run = 0; w.dash = 0; w.chase = 0; w.folder = 0; w.climb = 0; w.hop = 0; w.leap = 0; w.askPet = 0; w.sitActive = 0; }
        const mode = this._mode();
        // sleepy: she picks a place to sleep (a window top, a corner, next to a folder …)
        w.nap = (mood === 'sleepy' ? 2.5 : mood === 'calm' ? 0.35 : 0) * a.sleepWeight;
        if (mode === 'spontaneous') { w.climb = (w.climb || 0) * 1.5; w.walk = (w.walk || 0) * 1.2; w.nap *= 1.3; }
        if (this.stay && now < this.stay.until) {     // sent somewhere by a click: stay around that spot
          for (const key of ['walk', 'run', 'dash', 'chase', 'folder', 'climb', 'rub', 'follow', 'sitActive', 'leaveTop', 'askPet', 'nap']) w[key] = 0;
          w.sitDown = 4; w.stand = 1.5;
        }
        if (!this._rubTarget()) w.rub = 0;
        if (!this._climbTarget()) w.climb = 0;
        if (!this._folderTarget()) w.folder = 0;
        if (mode === 'hunt') w.chase = (this._has('leap') && !onTop && this._cursorRest(2500) && this._farFromLastHunt()) ? (w.chase || 0) * 0.8 : 0;   // the pointer instead of the butterfly
        else if (!s.butterfly || !this._has('leap')) w.chase = 0;
        if (!this._has('runStart') || !this._has('runStop')) { w.run = 0; w.dash = 0; }
        if (night) { w.sitDown = (w.sitDown || 1) * 2; w.run = (w.run || 0) * 0.3; w.dash = 0; w.nap *= 2; }
        switch (weighted(w)) {
          case 'walk': case 'run': {
            const run = weighted(w) === 'run';
            let tx; for (let i = 0; i < 8; i++) { tx = rand(bd.left, bd.right); if (Math.abs(tx - this.pos.x) > (run ? 260 : 160)) break; }
            this._setPlan([{ go: tx, mode: run ? 'run' : 'walk' }, { loop: 'stand', seconds: this._rest() }], true); return;
          }
          case 'dash': { const dir = Math.random() < 0.5 ? 1 : -1; this._setPlan([{ go: 0, mode: 'run', wrap: dir }, { loop: 'stand', seconds: this._rest() }], true); return; }
          case 'sitDown': this._setPlan(this._pathTo('sit').concat([{ loop: 'sit', seconds: this._rest('sit') }]), true); return;
          case 'hop': this._setPlan(this._pathTo('stand').concat([{ clip: 'hop' }, { loop: 'stand', seconds: this._rest() }]), true); return;
          case 'leap': this._setPlan(this._pathTo('stand').concat([{ clip: 'leap' }, { loop: 'stand', seconds: this._rest() }]), true); return;
          case 'rub': { const t = this._rubTarget(); this._setPlan([{ go: t.x, mode: 'walk', face: 1 }, { nudge: t.x, face: 1 }, { clip: 'rub' }, { loop: 'stand', seconds: this._rest() }], true); return; }
          case 'climb': { const t = this._climbTarget(); this._planClimb(t); return; }
          case 'sitActive': { const t = this._activeTarget(); this._planClimb(t); return; }
          case 'folder': { const t = this._folderTarget(); this._setPlan([{ go: t.x, mode: 'walk', face: 1 }, { nudge: t.x, face: 1 }, { clip: 'folder' }, { loop: 'stand', seconds: this._rest() }], true); return; }
          case 'chase': if (mode === 'hunt') this._huntAt(this.cur.x, this.cur.y, false); else this._startChase(false); return;
          case 'nap': this._napPlan(); return;
          case 'follow': { const tx = this.mouse.x - Math.sign(this.mouse.x - this.pos.x || 1) * 90; this._setPlan([{ go: tx, mode: 'walk' }, { loop: 'stand', seconds: this._rest() }], true); return; }
          case 'askPet': this._askPet(); return;
          case 'leaveTop': this._leaveTopThen([{ loop: 'standL', seconds: this._rest() }]); return;
          default: this._setPlan([{ loop: pose, seconds: this._rest() }], true); return;
        }
      }
      if (pose === 'sit') {
        if (mood === 'sleepy') { w.sleep = 3; w.sit = 3; w.groom = 1; w.standUp = 0.4; }
        else if (mood === 'cuddly') { w.belly = mouseNear ? 2.5 : 1; w.groom = 1; w.sit = 3; w.standUp = 1.2; w.sleep = 0.3; }
        else if (mood === 'calm') { w.groom = 1.5; w.sit = 4; w.standUp = 1.5; w.sleep = 0.6; w.belly = 0.4; }
        else { w.standUp = 3; w.belly = 0.8; w.groom = 0.8; w.sit = 1.5; w.sleep = 0.1; }
        if (night) { w.sleep = (w.sleep || 0.5) * 4; w.standUp = (w.standUp || 1) * 0.4; }
        w.sleep *= a.sleepWeight;
        // she sits for a good while before she lies down to sleep
        const sat = this.sitSince ? (now - this.sitSince) / 1000 : 0;
        if (sat < (mood === 'sleepy' || night ? a.minSit * 0.4 : a.minSit)) w.sleep = 0;
        if (this.stay && now < this.stay.until) w.standUp = 0.15;
        if (!this._has('rollOver')) w.belly = 0;
        switch (weighted(w)) {
          case 'groom': this._setPlan([{ clip: 'groom' }, { loop: 'sit', seconds: this._rest('sit') * 0.5 }], true); return;
          case 'belly': this._belly(false); return;
          case 'sleep': this._setPlan([{ clip: 'lieDown' }, { loop: 'sleep', seconds: (night ? rand(180, 900) : rand(40, 200)) * a.sleepScale * (mood === 'sleepy' ? 1.6 : 1) }], true); return;
          case 'standUp': this._setPlan([{ clip: 'standUp' }, { loop: 'stand', seconds: this._rest() }], true); return;
          default: this._setPlan([{ loop: 'sit', seconds: this._rest('sit') }], true); return;
        }
      }
      if (pose === 'sleep') {
        const more = mood === 'sleepy' ? 0.85 : (night ? 0.8 : 0.4);
        if (Math.random() < more) { this._setPlan([{ loop: 'sleep', seconds: rand(40, 150) }], true); return; }
        this._setPlan([{ clip: 'wakeUp' }, { loop: 'sit', seconds: this._rest('sit') * 0.5 }], true);
        this.say(pick(this._phr().wake), 1500);
        return;
      }
      if (pose === 'belly') { this._setPlan([{ clip: 'rollBack' }, { loop: 'sit', seconds: this._rest('sit') * 0.5 }], true); return; }
      if (pose === 'crouch') { this._setPlan([{ clip: 'pounce' }, { loop: 'stand', seconds: 2 }], true); return; }
      if (pose === 'cling') { this._fallOff(); return; }
      this._setPlan(this._pathTo('stand').concat([{ loop: 'stand', seconds: 3 }]), true);
    }

    /** cuddly: come close to the pointer, sit and ask to be petted, then offer the belly */
    _askPet() {
      const steps = [];
      if (this.mouse.x != null && Math.abs(this.mouse.x - this.pos.x) > 200) steps.push({ go: this.mouse.x - Math.sign(this.mouse.x - this.pos.x) * 90, mode: 'walk' });
      steps.push(...this._pathTo('sit', this.pose === 'stand' || this.pose === 'standL' ? (steps.length ? 'stand' : this.pose) : this.pose));
      steps.push({ fn: () => this.say(pick(this._phr().pet), 2500) }, { loop: 'sit', seconds: rand(4, 8) }, { fn: () => this._belly(false) });
      this._setPlan(steps, true);
    }

    /** roll onto the back and stay there (longer while being petted) */
    _belly(fromClick) {
      if (!this._has('rollOver') || !this._has('belly') || !this._has('rollBack')) return;
      const path = this._pathTo('sit', this.pose);
      if (this.pose !== 'sit' && !path.length) return;
      const seconds = fromClick ? rand(6, 10) : rand(5, 9);
      this._setPlan(path.concat([{ fn: () => { if (!fromClick) this.say(pick(this._phr().pet), 2200); } }, { clip: 'rollOver' }, { hold: 'belly', plays: 2, seconds }, { clip: 'rollBack' }, { loop: 'sit', seconds: this._rest('sit') * 0.5 }]), true);
    }

    _restLoop() { return this.pose === 'walk' ? 'stand' : this.pose === 'walkL' || this.pose === 'runL' ? 'standL' : this.pose === 'run' ? 'stand' : this.pose === 'cling' ? 'stand' : this.pose; }
    _standLoopFor(tx) { return tx < this.pos.x && this._has('standL') ? 'standL' : 'stand'; }

    /** a window/screen edge to rub against: {x: cat anchor target} (the rub clip has the panel on the right) */
    _rubTarget() {
      const s = this.settings, b = this.bounds(), k = this._k();
      const c = this.clips.rub; if (!c) return null;
      const reach = (c.panelX - c.startAnchor[0]) * k;
      const cands = [];
      if (s.rubWindows) for (const e of this.edges) { if (e.kind !== 'window' || e.side !== 'left') continue; const x = e.x - reach; if (x > b.left + reach * 0.5 && x < b.right - reach) cands.push({ x }); }
      if (!cands.length && s.rubScreenEdges) cands.push({ x: b.right - reach });
      if (!cands.length) return null;
      cands.sort((p, q) => Math.abs(p.x - this.pos.x) - Math.abs(q.x - this.pos.x));
      return Math.random() < 0.7 ? cands[0] : pick(cands);
    }

    _folderTarget(near) {
      const s = this.settings, b = this.bounds(), k = this._k();
      const c = this.clips.folder; if (!s.playFolders || !c || !c.folderBox) return null;
      const fb = c.folderBox;
      const cands = [];
      for (const ic of this.icons) {
        if (Math.abs((ic.y + ic.h) - b.floorY) > Math.max(30, ic.h * 0.6)) continue;      // must sit on the floor
        const x = ic.x + ic.w / 2 - ((fb[0] + fb[2]) / 2 - c.startAnchor[0]) * k;
        if (x < b.left + this._halfWidth() || x > b.right - this._halfWidth()) continue;
        if (near != null && Math.abs(ic.x + ic.w / 2 - near) > 120) continue;
        cands.push({ x, icon: ic });
      }
      if (!cands.length) return null;
      cands.sort((p, q) => Math.abs(p.x - this.pos.x) - Math.abs(q.x - this.pos.x));
      return cands[0];
    }

    /* ---------- butterfly chase ---------- */

    _swat() {            // where the leap's paws reach, relative to the cat's feet (container px)
      const c = this.clips.leap, k = this._k();
      return c && c.swat ? { x: c.swat[0] * k, y: c.swat[1] * k, t: c.swatTime || 2.4 } : { x: 60 * k, y: -380 * k, t: 2.4 };
    }

    _startChase(force) {
      if (!this._has('leap') || this.surface.kind === 'window') return;
      const b = this.bounds(), bd = this._bands();
      const sw = this._swat();
      const bf = { x: this.pos.x + sw.x + rand(-30, 30), y: this.pos.y + sw.y + rand(-20, 10), tx: 0, ty: 0, t: 0, dart: null };
      bf.tx = bf.x; bf.ty = bf.y;
      this.butterfly = bf;
      this.bfly.hidden = false;
      const rounds = 2 + Math.floor(Math.random() * 2);
      const steps = [...this._pathTo('stand')];
      const leapAt = () => { steps.push({ fn: () => { bf.tx = this.pos.x + sw.x; bf.ty = this.pos.y + sw.y; bf.dart = sw.t - 0.12; } }, { clip: 'leap' }); };
      leapAt();
      for (let i = 0; i < rounds; i++) {
        // the butterfly flees; the cat runs after it so that it ends up where the next leap reaches
        steps.push({ fn: () => {
          let cx; for (let k = 0; k < 8; k++) { cx = rand(bd.left + 40, bd.right - 40); if (Math.abs(cx - this.pos.x) > 320) break; }
          bf.tx = cx + sw.x; bf.ty = this.pos.y + sw.y * 0.75;
          this.plan.unshift({ go: cx, mode: Math.abs(cx - this.pos.x) > 250 ? 'run' : 'walk', face: 1 });
        } });
        if (this._has('stalk') && this._has('crouch') && this._has('pounce') && Math.random() < 0.5) {
          steps.push({ clip: 'crouch' }, { loop: 'stalk', seconds: rand(1.5, 3) }, { fn: () => { bf.dart = 0.4; } }, { clip: 'pounce' });
        } else leapAt();
      }
      steps.push({ fn: () => { bf.ty = -80; bf.tx = bf.x + rand(-120, 120); } });
      steps.push({ clip: 'sitDown' }, { loop: 'sit', seconds: rand(3, 6) }, { fn: () => { this.butterfly = null; this.bfly.hidden = true; } });
      this._setPlan(steps, true);
      this.onEvent('chase', {});
    }

    /* ---------- hunting the pointer (mode "hunt", instead of the butterfly) ---------- */

    _cursorAt(x, y) {
      const c = this.cur, now = performance.now();
      if (!c.t || Math.hypot(x - c.ax, y - c.ay) > 6) { c.ax = x; c.ay = y; c.movedAt = now; }   // a new resting place
      c.x = x; c.y = y; c.t = now;
    }
    /** the pointer is on this screen and has not moved for ms */
    _cursorRest(ms) {
      const c = this.cur; if (!c.t || c.x == null) return false;
      const b = this.bounds();
      if (c.x < b.left || c.x > b.right || c.y < 0 || c.y > b.floorY + 2) return false;
      return performance.now() - c.movedAt >= ms;
    }
    _farFromLastHunt() { const h = this.lastHuntSpot; return !h || this.cur.x == null || Math.hypot(this.cur.x - h.x, this.cur.y - h.y) > 90; }

    /** awake and free to run after something */
    _huntable() {
      if (!this.ready || this.settings.workMode || this.quiet || !this.visible || !this._has('leap')) return false;
      if (this.pose === 'sleep' || this.activeClip === 'lieDown' || this.activeClip === 'sleep') return false;   // asleep: leave her be
      if (this.state === 'drag' || this.state === 'fall' || this.state === 'climbing' || this.state === 'jumping') return false;
      if (this.currentBubble && !this.currentBubble.chatter) return false;    // a reminder is showing
      return true;
    }

    /** a click: if the pointer then stays where it clicked, she comes for it (a click and move on = nothing) */
    _huntClick(x, y) {
      if (!this._huntable()) return false;
      this._cursorAt(x, y);
      this.huntReq = { x, y, t: performance.now() };
      return true;
    }

    _tickHunt(now) {
      if (this._mode() !== 'hunt') { this.huntReq = null; this.huntGame = null; return; }
      const c = this.cur, r = this.huntReq;
      if (r) {
        if (c.x == null || Math.hypot(c.x - r.x, c.y - r.y) > 30 || now - r.t > 5000) this.huntReq = null;
        else if (now - r.t > 600 && now - c.movedAt > 500 && now - this.lastHuntAt > 3000) {
          this.huntReq = null;
          const h = this.lastHuntSpot, same = h && Math.hypot(c.x - h.x, c.y - h.y) < 60 && now - this.lastHuntAt < 20000;   // already got that one
          if (!same && this._huntable()) this._huntAt(c.x, c.y, true);
        }
      }
      // a game is on: when the pointer comes to rest somewhere else, she goes after it again (a few rounds)
      const g = this.huntGame;
      if (g && !this.huntReq && now > this.huntBusy) {
        if (now > g.until || g.rounds >= 5) this.huntGame = null;
        else if (this.state === 'loop' && this._cursorRest(900) && this._farFromLastHunt() && this._huntable()) this._huntAt(c.x, c.y, false);
      }
    }

    /** run below the pointer, eye it, jump at it, then sit down and wait for it to move */
    _huntAt(x, y, fromClick) {
      if (x == null) return;
      const now = performance.now(), b = this.bounds(), sw = this._swat(), half = this._halfWidth();
      const standX = clamp(x - sw.x, b.left + half, b.right - half);       // the leap faces right: its paws reach the pointer
      const far = Math.abs(standX - this.pos.x);
      this.lastHuntAt = now; this.lastHuntSpot = { x, y };
      this.huntBusy = now + 60000;
      const g = this.huntGame = (this.huntGame && now < this.huntGame.until) ? this.huntGame : { rounds: 0 };
      g.rounds++; g.until = now + 90000;
      this.stay = null;
      this.excited = now + 60000; this._applyRates();
      const caught = () => {
        this.excited = 0; this._applyRates();
        this.huntBusy = 0; g.until = performance.now() + 30000; this.huntGame = g;
        this.lastHuntSpot = { x: this.cur.x != null ? this.cur.x : x, y: this.cur.y != null ? this.cur.y : y };
      };
      // close enough (she sits right below it): no walking, she jumps from where she is
      const near = this.surface.kind === 'floor' && far < this.settings.size * 0.7;
      const steps = near ? this._pathTo('stand') : [{ go: standX, mode: far > 260 ? 'run' : 'walk', face: 1 }, { nudge: standX, face: 1 }];
      this._leaveTopThen(steps.concat([
        { loop: 'stand', seconds: rand(0.3, 0.6) },     // eyes on it …
        { clip: 'leap' },                               // … pounce
        { fn: caught },
        { clip: 'sitDown' },
        { loop: 'sit', seconds: rand(30, 60) }          // then she sits and waits for it to move again
      ]));
      this.onEvent('hunt', { x, y, click: !!fromClick });
    }

    /** a sleepy cat chooses where to sleep: up on a window, in a corner, next to a folder or just somewhere */
    _napPlan() {
      const a = ACTIVITY[this.settings.activity] || ACTIVITY.normal;
      const bd = this._bands(), half = this._halfWidth();
      const sleepFor = rand(60, 240) * a.sleepScale * (this._isNight() ? 2 : 1);
      const rest = [{ settle: 'sit', seconds: rand(25, 60) }, { clip: 'lieDown' }, { loop: 'sleep', seconds: sleepFor }];   // sits a while first
      if (this.surface.kind === 'window') { this._setPlan([{ go: rand(bd.left, bd.right), mode: 'walk', within: 40 }].concat(rest), true); return; }
      const opts = { spot: 1, corner: 1, here: 0.5 };
      const ct = this._climbTarget(); if (ct) opts.window = 1.6;
      const ft = this._folderTarget(); if (ft) opts.folder = 0.8;
      let plan, where = weighted(opts);
      switch (where) {
        case 'window': {
          const w = ct.win, topX = rand(w.x + half, Math.max(w.x + half, w.x + w.w - half * 1.5));
          plan = [{ go: ct.standX, mode: Math.abs(ct.standX - this.pos.x) > 600 ? 'run' : 'walk', face: 1 }, { nudge: ct.standX, face: 1 }, { climb: ct },
            { loop: 'sit', seconds: rand(2, 5) }, { go: topX, mode: 'walk', within: 40 }].concat(rest);
          break;
        }
        case 'corner': { const left = Math.random() < 0.5; plan = [{ go: left ? bd.left : bd.right, mode: 'walk', face: left ? -1 : 1 }].concat(rest); break; }
        case 'folder': plan = [{ go: ft.x - half * 0.3, mode: 'walk', face: 1 }].concat(rest); break;
        case 'here': plan = rest; break;
        default: { let tx; for (let i = 0; i < 6; i++) { tx = rand(bd.left, bd.right); if (Math.abs(tx - this.pos.x) > 200) break; } plan = [{ go: tx, mode: 'walk' }].concat(rest); }
      }
      this._setPlan(plan, true);
      this.onEvent('nap', { where });
    }

    _tickTimer(force) {
      if (!this.pomodoro) return;
      const now = Date.now();
      if (!force && now - (this._timerLast || 0) < 500) return;
      this._timerLast = now;
      const left = Math.max(0, Math.round((this.pomodoro.endsAt - now) / 1000));
      this.timerText.textContent = String(Math.floor(left / 60)).padStart(2, '0') + ':' + String(left % 60).padStart(2, '0');
      this.timerEl.style.bottom = (this._headH() + (this.bubble.hidden ? 8 : 60)) + 'px';
    }

    _tickButterfly(dt) {
      const bf = this.butterfly; if (!bf) return;
      bf.t += dt;
      // darts away when the paws arrive
      if (bf.dart != null && this.activeClip && (this.activeClip === 'leap' || this.activeClip === 'pounce')) {
        const v = this.videos[this.activeClip];
        if (v && v.currentTime >= bf.dart) {
          const b = this.bounds(); bf.dart = null;
          bf.tx = clamp(bf.x + (Math.random() < 0.5 ? -1 : 1) * rand(160, 260), b.left + 40, b.right - 40); bf.ty = Math.max(20, bf.y - rand(60, 120));
        }
      }
      const sp = (bf.dart == null ? 3.2 : 2.4) * dt;
      bf.x += (bf.tx - bf.x) * Math.min(1, sp);
      bf.y += (bf.ty - bf.y) * Math.min(1, sp);
      const fx = bf.x + Math.sin(bf.t * 5.1) * 7 + Math.sin(bf.t * 1.7) * 10;
      const fy = bf.y + Math.sin(bf.t * 7.3) * 5 + Math.cos(bf.t * 2.3) * 8;
      this.bfly.style.transform = `translate(${(fx - 20).toFixed(1)}px, ${(fy - 15).toFixed(1)}px) scaleX(${bf.tx >= bf.x ? 1 : -1})`;
      if (bf.ty < 0 && bf.y < 0) { this.butterfly = null; this.bfly.hidden = true; }
    }

    /* ---------- misc ---------- */

    _isNight() {
      const h = new Date().getHours();
      const s = this.settings.nightStart, e = this.settings.nightEnd;
      return s > e ? (h >= s || h < e) : (h >= s && h < e);
    }

    _workModeChanged() {
      const s = this.settings;
      this._closeBubble(true);
      if (s.workMode) { if (s.workBehavior === 'hide') this._leaveTopThen([{ hide: true }]); else { this.show(); this._decide(); } }
      else { this.show(); if (this.state === 'hidden') this.state = 'idle'; this._setPlan(this.pose === 'sleep' ? [{ clip: 'wakeUp' }, { loop: 'sit', seconds: 2 }] : [{ loop: this._restLoop(), seconds: 1 }], true); }
      this.root.style.opacity = (s.workMode && s.workBehavior === 'sleep') ? s.workOpacity : 1;
      this.onEvent('workMode', { on: s.workMode });
    }

    _phr() { return PHRASES[this.settings.lang] || PHRASES.sk; }

    /* ---------- pointer / drag ---------- */

    _local(cx, cy) { const r = this.container.getBoundingClientRect(); return { x: cx - r.left, y: cy - r.top }; }

    _pointerMove(cx, cy) {
      const l = this._local(cx, cy);
      this.mouse.x = l.x; this.mouse.y = l.y; this.mouse.cx = cx; this.mouse.cy = cy; this.mouse.seen = performance.now();
      this._cursorAt(l.x, l.y);
      if (this.dragging) {
        this.dragging.moved = this.dragging.moved || Math.hypot(cx - this.dragging.sx, cy - this.dragging.sy) > 5;
        if (this.dragging.moved && this.state !== 'drag') this._dragBegin();
        if (this.state === 'drag') {
          const b = this.bounds();
          this.pos.x = clamp(l.x - this.dragging.ox, b.left, b.right);
          this.pos.y = Math.min(b.floorY, l.y - this.dragging.oy);
        }
        return;
      }
      if (!this.visible) { this._setHover(false); return; }
      this._setHover(this._hit(cx, cy, false, 16));
    }

    _hit(cx, cy, bodyOnly, pad) {
      const r = this._bodyRect();
      const inset = pad ? -pad : Math.min(10, r.width * 0.08);
      if (cx >= r.left + inset && cx <= r.right - inset && cy >= r.top + inset && cy <= r.bottom) return true;
      if (!bodyOnly && !this.bubble.hidden) {
        const rb = this.bubble.getBoundingClientRect();
        if (cx >= rb.left && cx <= rb.right && cy >= rb.top && cy <= rb.bottom) return true;
      }
      return false;
    }

    _setHover(on) {
      if (on === this.hovering) return;
      this.hovering = on;
      this.root.classList.toggle('is-hover', on);
      this.container.style.cursor = on ? 'grab' : '';
      this._interactive(on || !!this.dragging);
    }
    _interactive(on) { if (this._lastInteractive === on) return; this._lastInteractive = on; this.onInteractive(on); }

    _dragStart(e) {
      if (!this.visible) return;
      e.preventDefault && e.preventDefault();
      const l = this._local(e.clientX, e.clientY);
      this.dragging = { sx: e.clientX, sy: e.clientY, ox: l.x - this.pos.x, oy: l.y - this.pos.y, moved: false };
      this._interactive(true);
    }
    _dragBegin() {
      this._closeBubble(true);
      this.plan = []; this.walk = null; this.climb = null; this.jump = null; this.hold = null;
      this.huntReq = null; this.huntBusy = 0; this.excited = 0;
      if (this.butterfly) { this.butterfly = null; this.bfly.hidden = true; }
      // a sleeping cat is carried as she is and keeps sleeping
      this.carrySleep = this.pose === 'sleep' && this.activeClip === 'sleep';
      this.state = 'drag';
      this._setDataState(this.carrySleep ? 'dragSleep' : 'drag');
      if (this.carrySleep) return;
      // the drag/fall pose is the standing anchor: switch the world point to the stand anchor first
      this.pose = 'stand';
      this._holdAir();
    }
    _dragEnd() {
      if (!this.dragging) return;
      const d = this.dragging; this.dragging = null;
      if (this.state === 'drag') {
        const b = this.bounds();
        // dropped onto a window? land on its top edge instead of falling to the floor
        const hit = this._windowUnder();
        this.vel.y = 0;
        if (hit) {
          const win = hit.win;
          this.surface = { kind: 'window', y: win.y, left: win.x, right: win.x + win.w, win };
          if (hit.inside) this.vel.y = -Math.sqrt(2 * GRAVITY * (this.pos.y - win.y + 25 * this._k()));   // released over the window: hop up onto it
        } else this._setSurfaceFloor(b);
        this.state = 'fall'; this._setDataState(this.carrySleep ? 'dragSleep' : 'fall'); this.onEvent('drop');
      }
      else if (!d.moved) this._clicked();
      this._interactive(this.hovering);
    }
    /** where a released cat lands: the window she is held over (hop up onto it) or the first window top below her feet */
    _windowUnder() {
      const k = this._k(), half = this._halfWidth(), b = this.bounds();
      const x = this.pos.x, y = this.pos.y;
      const wins = (this.windows || []).filter((w) => w.w >= this.settings.size * 1.2 && w.y > 4 && x >= w.x + half * 0.4 && x <= w.x + w.w - half * 0.4);
      // windows come front-to-back: the first one whose body is under the pointer wins
      for (const w of wins) if (y > w.y + 6 * k && y < Math.min(w.y + w.h, b.floorY - 10)) return { win: w, inside: true };
      let best = null;
      for (const w of wins) { const dy = w.y - y; if (dy >= -6 * k && (!best || dy < best.dy)) best = { dy, win: w }; }
      return best ? { win: best.win, inside: false } : null;
    }
    /** front-most window containing a point */
    _windowAt(x, y) {
      for (const w of this.windows || []) if (x >= w.x && x <= w.x + w.w && y >= w.y && y <= w.y + w.h && w.y > 4) return w;
      return null;
    }
    _tickFall(dt) {
      const onWin = this.surface.kind === 'window';
      const floor = onWin ? this.surface.y : this.bounds().floorY;
      const prev = this.pos.y;
      this.vel.y += GRAVITY * dt;
      this.pos.y += this.vel.y * dt;
      // land when falling through the surface (a hop up onto a window starts below its top edge)
      if (this.vel.y > 0 && this.pos.y >= floor && (!onWin || prev <= floor + 1)) {
        this.pos.y = floor;
        if (this.vel.y > 700 && !this.carrySleep) { this.vel.y = -this.vel.y * 0.25; }
        else { this.vel.y = 0; this._landed(); }
      } else if (!onWin && this.pos.y > floor) this.pos.y = floor;
    }
    _landed() {
      if (this.carrySleep) {                         // carried while asleep: sleeps on where she was put
        this.carrySleep = false; this.pose = 'sleep'; this.state = 'idle';
        if (this.surface.kind === 'window') this.onEvent('onTop', { win: this.surface.win });
        this._setPlan([{ loop: 'sleep', seconds: rand(60, 240) }], true); return;
      }
      this.pose = 'stand'; this.state = 'idle';
      if (this.surface.kind === 'window') {
        this.onEvent('onTop', { win: this.surface.win });
        this.stay = { until: performance.now() + rand(3, 8) * 60000 };
        this._setPlan([{ loop: 'stand', seconds: rand(1, 2) }, { settle: 'sit', seconds: rand(30, 90) }], true); return;
      }
      this.say(pick(this._phr().drop), 1200);
      // dropped next to a desktop folder? play with it
      const t = this._folderTarget(this.pos.x);
      if (t && Math.abs(t.x - this.pos.x) < 160) { this._setPlan([{ loop: 'stand', seconds: 0.8 }, { go: t.x, mode: 'walk', face: 1 }, { nudge: t.x, face: 1 }, { clip: 'folder' }, { loop: 'stand', seconds: rand(1, 3) }], true); return; }
      this._setPlan([{ loop: 'stand', seconds: rand(1.5, 4) }], true);
    }

    _clicked() {
      if (this.settings.workMode && this.pose === 'sleep') { this.say('…', 900); return; }
      this.onEvent('click');
      this.huntReq = null; this.huntBusy = 0; this.excited = 0;
      this._hearts();
      this._purr(this._poseAfter() === 'belly' ? 6 : 3.5);
      if (this.state === 'drag' || this.state === 'fall' || this.state === 'climbing' || this.state === 'jumping') return;
      const pose = this._poseAfter();
      if (pose === 'belly' || (this.activeClip === 'rollOver')) {
        // being petted on the belly: purr, wriggle once more and stay there a little longer
        this.say(pick(this._phr().purr), 1400, true);
        if (this.state === 'loop' && this.hold && this.hold.id === 'belly') {
          const v = this.videos.belly;
          if (v && (v.ended || v.paused)) this._play('belly', { restart: true, cut: true }); else this.hold.plays = Math.min(1, this.hold.plays + 1);
          this.stateUntil = Math.max(this.stateUntil, performance.now() + 6000);
        } else if (this.plan.length && this.plan[0].hold === 'belly') this.plan[0].seconds = Math.max(this.plan[0].seconds || 0, 8);
        return;
      }
      if (pose === 'sleep') { this._setPlan([{ clip: 'wakeUp' }, { loop: 'sit', seconds: 2 }], true); return; }
      this.say(pick(this._phr().click), 1600);
      if (pose === 'sit') { if (Math.random() < 0.65 && this._has('rollOver')) this._belly(true); else this._setPlan([{ clip: 'groom' }, { loop: 'sit', seconds: rand(2, 5) }], true); return; }
      if (pose === 'standL') { this._setPlan([{ loop: 'standL', seconds: 1 }, { clip: 'turnR' }, { clip: 'hop' }, { loop: 'stand', seconds: 2 }], true); return; }
      if (this.state === 'walking') { this._setPlan([{ clip: 'hop' }, { loop: 'stand', seconds: 2 }]); return; }
      this._setPlan(this._pathTo('stand').concat([{ clip: Math.random() < 0.5 ? 'hop' : 'leap' }, { loop: 'stand', seconds: rand(1, 3) }]), true);
    }

    _hearts() {
      if (this.settings.reduceMotion) return;
      const n = 3 + Math.floor(Math.random() * 3);
      const h0 = this._headH();
      for (let i = 0; i < n; i++) {
        const h = document.createElement('span');
        h.className = 'cat-heart';
        h.textContent = Math.random() < 0.8 ? '♥' : '✦';
        h.style.left = rand(-40, 40) + 'px';
        h.style.bottom = (h0 * 0.6 + rand(-10, 20)) + 'px';
        h.style.animationDelay = (i * 90) + 'ms';
        h.style.fontSize = rand(12, 20) + 'px';
        this.fx.appendChild(h);
        h.addEventListener('animationend', () => h.remove());
      }
    }
    _zzz() {
      if (this.settings.reduceMotion) return;
      const z = document.createElement('span');
      z.className = 'cat-zzz'; z.textContent = 'z';
      z.style.left = '30px';
      z.style.bottom = this._headH() + 'px';
      this.fx.appendChild(z);
      z.addEventListener('animationend', () => z.remove());
    }
    _audio() { const AC = window.AudioContext || window.webkitAudioContext; this._ac = this._ac || new AC(); return this._ac; }
    /** purring (recorded, looped): fades in, keeps going while she is petted, fades out */
    _purr(seconds) {
      if (!this.settings.sounds) return;
      const file = this.pet.sounds && this.pet.sounds.purr; if (!file) return;
      if (!this.purrEl) {
        try { const a = new Audio(this.baseUrl + file); a.loop = true; a.volume = 0; a.preload = 'auto'; this.purrEl = a; } catch (e) { return; }
      }
      const a = this.purrEl;
      this.purrUntil = Math.max(this.purrUntil || 0, performance.now() + seconds * 1000);
      if (a.paused) { try { a.currentTime = Math.random() * Math.max(0, (a.duration || 10) - 4); } catch (e) {} const p = a.play(); if (p && p.catch) p.catch(() => {}); }
    }
    _tickPurr(dt) {
      const a = this.purrEl; if (!a || a.paused) return;
      const target = (this.settings.sounds && performance.now() < (this.purrUntil || 0)) ? 0.6 : 0;
      const v = a.volume + (target - a.volume) * Math.min(1, dt * (target > a.volume ? 3 : 1.6));
      a.volume = clamp(v, 0, 1);
      if (target === 0 && a.volume < 0.015) { a.volume = 0; a.pause(); }
    }
    _chirp() {
      if (!this.settings.sounds) return;
      try {
        const ac = this._audio(), t = ac.currentTime;
        const o = ac.createOscillator(), g = ac.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(620, t); o.frequency.exponentialRampToValueAtTime(880, t + 0.12); o.frequency.exponentialRampToValueAtTime(520, t + 0.3);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.12, t + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.32);
        o.connect(g).connect(ac.destination); o.start(t); o.stop(t + 0.35);
      } catch (e) { /* no audio */ }
    }
    _chime() {
      if (!this.settings.sounds) return;
      try {
        const ac = this._audio(), t = ac.currentTime;
        [523.25, 783.99].forEach((f, i) => {
          const o = ac.createOscillator(), g = ac.createGain();
          o.type = 'triangle'; o.frequency.value = f;
          g.gain.setValueAtTime(0.0001, t + i * 0.18); g.gain.exponentialRampToValueAtTime(0.1, t + i * 0.18 + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.18 + 0.5);
          o.connect(g).connect(ac.destination); o.start(t + i * 0.18); o.stop(t + i * 0.18 + 0.55);
        });
      } catch (e) { /* no audio */ }
    }

    /* ---------- bubbles ---------- */

    _nextBubble() {
      if (!this.bubble.hidden || !this.queue.length) return;
      const b = this.queue.shift();
      this.currentBubble = b;
      if (!b.chatter) {
        if (!this.visible) this.show();
        if (this.state === 'hidden') this.state = 'idle';
        const plan = this._reminderPlan(b.action);
        if (plan) { if (this.state === 'drag' || this.state === 'fall' || this.state === 'climbing' || this.state === 'jumping') this.plan = plan; else this._setPlan(plan, true); }
        else {
          // stop what you're doing and look at the person
          if (this.pose === 'sleep') this._setPlan([{ clip: 'wakeUp' }, { loop: 'sit', seconds: 3600 }], true);
          else if (this.state === 'walking' || this.state === 'stopping') this._setPlan([{ loop: 'stand', seconds: 3600 }]);
          else if (this.state === 'loop') { this.plan = []; this.stateUntil = performance.now() + 3600000; }
          else if (this.state === 'climbing' || this.state === 'jumping' || this.state === 'fall' || this.state === 'drag') { /* finish the move first */ }
          else this.plan = [{ loop: this._restLoop(), seconds: 3600 }];
        }
        this._chime();
        this.onEvent('reminderShown', b);
      }
      this.bubbleText.textContent = b.text;
      this.bubble.classList.toggle('is-important', !!b.important);
      this.bubble.classList.toggle('is-chatter', !!b.chatter);
      this.bubble.hidden = false;
      this.bubble.style.bottom = (this._headH() + 10) + 'px';
      this._placeBubble();
      clearTimeout(this.bubbleTimer);
      const ms = b.ms || (b.important ? 0 : this.settings.bubbleSeconds * 1000);
      if (ms > 0) this.bubbleTimer = setTimeout(() => this._closeBubble(), ms);
    }

    /** what the cat does while a reminder shows: sleep | sit | hop | leap | rub | belly | come | climb | folder */
    _reminderPlan(action) {
      if (!action || action === 'none') return null;
      const hold = { loop: null, seconds: 3600 };
      const after = (loop) => Object.assign({}, hold, { loop });
      const onTop = this.surface.kind === 'window';
      switch (action) {
        case 'sleep': return this._pathTo('sleep').concat([after('sleep')]);
        case 'sit': return this._pathTo('sit').concat([after('sit')]);
        case 'hop': return this._pathTo('stand').concat([{ clip: 'hop' }, after('stand')]);
        case 'leap': return this._pathTo('stand').concat([{ clip: 'leap' }, after('stand')]);
        case 'belly': return this._has('rollOver') ? this._pathTo('sit').concat([{ clip: 'rollOver' }, { hold: 'belly', plays: 2, seconds: 3600 }]) : this._pathTo('sit').concat([after('sit')]);
        case 'rub': { const t = !onTop && this._rubTarget(); return t ? [{ go: t.x, mode: 'walk', face: 1 }, { nudge: t.x, face: 1 }, { clip: 'rub' }, after('stand')] : this._pathTo('sit').concat([after('sit')]); }
        case 'folder': { const t = !onTop && this._folderTarget(); return t ? [{ go: t.x, mode: 'walk', face: 1 }, { nudge: t.x, face: 1 }, { clip: 'folder' }, after('stand')] : this._pathTo('stand').concat([{ clip: 'hop' }, after('stand')]); }
        case 'climb': { const t = !onTop && this._climbTarget(); return t ? [{ go: t.standX, mode: 'walk', face: 1 }, { nudge: t.standX, face: 1 }, { climb: t }, after('sit')] : this._pathTo('sit').concat([after('sit')]); }
        case 'come': { const x = this.mouse.x != null ? this.mouse.x - Math.sign(this.mouse.x - this.pos.x || 1) * 90 : this.pos.x; return onTop ? [after('sit')] : [{ go: x, mode: Math.abs(x - this.pos.x) > 500 ? 'run' : 'walk' }, after('stand')]; }
        default: return null;
      }
    }

    _closeBubble(silent) {
      if (this.bubble.hidden) return;
      clearTimeout(this.bubbleTimer);
      this.bubble.hidden = true;
      const b = this.currentBubble; this.currentBubble = null;
      if (b && !b.chatter) {
        this.onEvent('reminderClosed', b);
        if (!silent) {
          if (this.settings.workMode && this.settings.workBehavior === 'hide') this._leaveTopThen([{ hide: true }]);
          else if (this.state === 'loop') this.stateUntil = Math.min(this.stateUntil, performance.now() + (this.pose === 'sleep' ? rand(20000, 60000) : 1500));
          else if (this.state === 'idle') this.stateUntil = 0;
          for (const st of this.plan) if ((st.loop || st.hold) && st.seconds >= 3600) st.seconds = st.loop === 'sleep' ? rand(30, 90) : rand(2, 5);
        }
      }
      if (this.mouse.cx != null) this._setHover(this._hit(this.mouse.cx, this.mouse.cy));
      setTimeout(() => this._nextBubble(), 400);
    }

    _placeBubble() {
      this.bubble.style.setProperty('--bx', '0px');
      const cb = this.container.getBoundingClientRect();
      const rb = this.bubble.getBoundingClientRect();
      let shift = 0;
      if (rb.left < cb.left + 8) shift = cb.left + 8 - rb.left;
      else if (rb.right > cb.right - 8) shift = cb.right - 8 - rb.right;
      this.bubble.style.setProperty('--bx', shift + 'px');
    }

    /* ---------- main loop ---------- */

    _loop(ts) {
      if (this.destroyed) return;
      requestAnimationFrame(this._loop);
      const dt = Math.min(0.05, (ts - (this.lastTs || ts)) / 1000);
      this.lastTs = ts;
      const b = this.bounds();
      if (this.surface.kind === 'floor' && this.surface.y !== b.floorY && this.state !== 'drag' && this.state !== 'fall') { this.surface.y = b.floorY; this.pos.y = b.floorY; }
      switch (this.state) {
        case 'walking': this._tickWalk(dt); break;
        case 'nudging': {
          const dx = this.nudge.x - this.pos.x;
          const step = Math.sign(dx) * Math.min(Math.abs(dx), 70 * dt);
          this.pos.x += step;
          if (Math.abs(this.nudge.x - this.pos.x) < 0.5) { this.pos.x = this.nudge.x; this.nudge = null; this.state = 'idle'; this._nextStep(); }
          break;
        }
        case 'stopping': this._tickStop(dt); break;
        case 'climbing': this._tickClimb(dt); break;
        case 'jumping': this._tickJump(dt); break;
        case 'loop': case 'idle':
          if (this.pose === 'sleep') { this.zzzTimer += dt; if (this.zzzTimer > 2.2) { this.zzzTimer = 0; this._zzz(); } }
          if (ts >= this.stateUntil) this._nextStep();
          break;
        case 'fall': this._tickFall(dt); break;
        case 'transition': case 'drag': case 'hidden': break;
      }
      if ((this.state === 'walking' || this.state === 'stopping') && !(this.walk && (this.walk.wrapTo != null || this.walk.outX != null))) {   // poses have different anchors: only clamp while moving
        const bd = this._bands();
        if (this.pos.x > bd.left - 2 && this.pos.x < bd.right + 2) this.pos.x = clamp(this.pos.x, bd.left, bd.right);
      }
      this._tickButterfly(dt);
      this._tickHunt(ts);
      this._tickTimer(false);
      this._tickPurr(dt);
      this._placeActive();
      if (this.lastTop !== (this.surface.kind)) { this.lastTop = this.surface.kind; this.root.dataset.surface = this.surface.kind; }
    }
  }

  return { Cat, DEFAULT_SETTINGS, PHRASES, videoSupported };
});
