#!/bin/sh
# Build the update package for the current version (and optionally publish it as a GitHub release).
#   ./make-update.sh            -> ../desk-cat-update-X.Y.Z.zip
#   ./make-update.sh publish    -> also creates release vX.Y.Z in the update repository (needs the gh CLI, logged in)
set -e
cd "$(dirname "$0")"
VER=$(node -p "require('./package.json').version")
REPO=$(node -p "(require('./package.json').deskcat||{}).updateRepo||''")
OUT="../desk-cat-update-$VER.zip"
rm -f "$OUT"
(cd .. && zip -q -r "desk-cat-update-$VER.zip" "$(basename "$OLDPWD")" -x "*/node_modules/*" "*/dist/*" "*/.DS_Store")
echo "created $OUT"
if [ "$1" = "publish" ]; then
  # needs a clone of the update repository next to the project: ../../deskcat-updates
  R="${UPDATES_DIR:-../../deskcat-updates}"
  mkdir -p "$R/releases"
  cp "$OUT" "$R/releases/"
  SIZE=$(wc -c < "$OUT" | tr -d ' ')
  node -e "require('fs').writeFileSync(process.argv[1], JSON.stringify({version: process.argv[2], file: 'releases/desk-cat-update-' + process.argv[2] + '.zip', size: +process.argv[3], notes: process.argv[4] || ''}, null, 2) + '\n')" "$R/latest.json" "$VER" "$SIZE" "${NOTES:-}"
  (cd "$R" && git add latest.json "releases/desk-cat-update-$VER.zip" && git commit -m "Desk Cat $VER" && git push)
fi
