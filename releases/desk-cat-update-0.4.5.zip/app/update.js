/* Apply an update package (zip) onto an unpacked install: the zip's files are copied over the app folder.
 * Only stored and deflated entries are supported (what `zip` and Finder/Explorer produce). */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

function readEntries(buf) {
  // end of central directory
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 70000); i--) { if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; } }
  if (eocd < 0) throw new Error('not a zip file');
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const entries = [];
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('bad central directory');
    const method = buf.readUInt16LE(p + 10);
    const csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nlen = buf.readUInt16LE(p + 28), elen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32);
    const off = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nlen);
    entries.push({ name, method, csize, usize, off });
    p += 46 + nlen + elen + clen;
  }
  return entries;
}

function entryData(buf, e) {
  if (buf.readUInt32LE(e.off) !== 0x04034b50) throw new Error('bad local header for ' + e.name);
  const nlen = buf.readUInt16LE(e.off + 26), elen = buf.readUInt16LE(e.off + 28);
  const start = e.off + 30 + nlen + elen;
  const data = buf.subarray(start, start + e.csize);
  if (e.method === 0) return data;
  if (e.method === 8) return zlib.inflateRawSync(data);
  throw new Error('unsupported compression in ' + e.name);
}

/** returns the number of files written */
function applyZip(zipPath, destDir) {
  const buf = fs.readFileSync(zipPath);
  const entries = readEntries(buf).filter((e) => !e.name.startsWith('__MACOSX/') && !e.name.includes('/.DS_Store') && e.name !== '.DS_Store');
  // strip a single top-level folder (e.g. "app/" or "desk-cat/") when the package.json sits inside it
  const roots = new Set(entries.map((e) => e.name.split('/')[0]));
  let prefix = '';
  if (roots.size === 1 && entries.some((e) => e.name === [...roots][0] + '/package.json')) prefix = [...roots][0] + '/';
  const dest = path.resolve(destDir);
  let written = 0;
  for (const e of entries) {
    let rel = e.name.startsWith(prefix) ? e.name.slice(prefix.length) : e.name;
    if (!rel || rel.startsWith('node_modules/') || rel.startsWith('dist/')) continue;
    const target = path.resolve(dest, rel);
    if (!target.startsWith(dest + path.sep)) continue;                  // never write outside the app folder
    if (rel.endsWith('/')) { fs.mkdirSync(target, { recursive: true }); continue; }
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, entryData(buf, e));
    written++;
  }
  if (!written) throw new Error('empty package');
  return written;
}

function copyTree(src, dst) {
  // works on the packaged app too (Electron's fs reads inside app.asar transparently)
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    if (e.name === 'node_modules' || e.name === 'dist' || e.name === '.DS_Store') continue;
    const a = path.join(src, e.name), b = path.join(dst, e.name);
    if (e.isDirectory()) copyTree(a, b);
    else fs.writeFileSync(b, fs.readFileSync(a));
  }
}

function overrideDir(app) { return path.join(app.getPath('userData'), 'app-update'); }

/** installed app: build <userData>/app-update = running code + the zip's files; boot.js starts it if its version is newer */
function applyToOverride(zipPath, currentDir, dest) {
  const stage = dest + '.new';
  fs.rmSync(stage, { recursive: true, force: true });
  copyTree(currentDir, stage);
  const n = applyZip(zipPath, stage);
  let ver = null;
  try { ver = JSON.parse(fs.readFileSync(path.join(stage, 'package.json'), 'utf8')).version; } catch (e) { /* checked below */ }
  if (!ver || !fs.existsSync(path.join(stage, 'main.js'))) { fs.rmSync(stage, { recursive: true, force: true }); throw new Error('the package has no app in it'); }
  fs.rmSync(dest, { recursive: true, force: true });
  fs.renameSync(stage, dest);
  return n;
}

module.exports = { applyZip, readEntries, applyToOverride, overrideDir, copyTree };
