/* Settings persistence: one JSON file in the app's userData folder. */
const fs = require('fs');
const path = require('path');
const { app } = require('electron');

const DEFAULTS = {
  lang: 'sk',
  pet: 'mycat',
  size: 150,
  speed: 1.0,
  activity: 'normal',
  mode: 'click',          // spontaneous | click | hunt
  followMouse: true,      // older versions: replaced by mode
  rubWindows: true,
  rubScreenEdges: true,
  climbWindows: true,
  playFolders: true,
  butterfly: true,
  sounds: false,
  bubbleSeconds: 12,
  workMode: false,
  workBehavior: 'sleep',
  workCorner: 'right',
  workOpacity: 0.65,
  workSchedule: { enabled: false, from: '09:00', to: '17:00', days: [1, 2, 3, 4, 5] },
  quiet: { enabled: false, from: '21:00', to: '08:00' },
  pomodoro: { work: 25, brk: 5 },
  summary: { enabled: true, at: '17:30' },
  sitActive: true,
  autoUpdate: true,
  lastUpdateCheck: 0,
  updateNotified: '',
  updateRepo: '',
  nightEnabled: true,
  nightStart: 22,
  nightEnd: 7,
  reduceMotion: false,
  launchAtLogin: false,
  hidden: false,
  reminders: null // filled with language defaults on first run
};

class Store {
  constructor() {
    this.file = path.join(app.getPath('userData'), 'settings.json');
    this.data = Object.assign({}, DEFAULTS);
    this.load();
  }
  load() {
    try {
      const raw = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      this.data = Object.assign({}, DEFAULTS, raw);
      this.data.workSchedule = Object.assign({}, DEFAULTS.workSchedule, raw.workSchedule || {});
      if (raw.mode == null) this.data.mode = raw.followMouse === false ? 'spontaneous' : 'click';   // settings from before 0.4.5
    } catch (e) { /* first run */ }
    if (!Array.isArray(this.data.reminders)) {
      const I18N = require('./i18n');
      this.data.reminders = I18N.get(this.data.lang).defaultReminders.map((r, i) => Object.assign({ id: 'r' + Date.now() + i }, r));
      this.save();
    }
  }
  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2));
    } catch (e) { console.error('settings save failed', e); }
  }
  get(k) { return k ? this.data[k] : this.data; }
  set(partial) { Object.assign(this.data, partial); this.save(); return this.data; }
  /** settings that the cat engine understands */
  engineSettings() {
    const d = this.data;
    return {
      size: d.size, speed: d.speed, activity: d.activity, mode: d.mode, followMouse: d.mode !== 'spontaneous', rubWindows: d.rubWindows, rubScreenEdges: d.rubScreenEdges, climbWindows: d.climbWindows, playFolders: d.playFolders, butterfly: d.butterfly, sitActive: d.sitActive, sounds: d.sounds,
      bubbleSeconds: d.bubbleSeconds, workMode: d.workMode, workBehavior: d.workBehavior, workCorner: d.workCorner,
      workOpacity: d.workOpacity, nightStart: d.nightEnabled ? d.nightStart : -1, nightEnd: d.nightEnabled ? d.nightEnd : -1,
      reduceMotion: d.reduceMotion, lang: d.lang
    };
  }
}

module.exports = { Store, DEFAULTS };
