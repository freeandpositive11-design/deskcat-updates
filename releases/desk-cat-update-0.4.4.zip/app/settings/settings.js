/* Settings window logic. Every change is saved immediately. */
(async function () {
  const api = window.deskcat;
  let state = await api.getSettings();
  let S = state.strings.settings;
  let data = state.data;
  const $ = (id) => document.getElementById(id);

  /* ---------- i18n ---------- */
  function applyStrings() {
    S = state.strings.settings;
    document.querySelectorAll('[data-i18n]').forEach((el) => { const k = el.dataset.i18n; if (S[k] != null) el.textContent = S[k]; });
    document.querySelectorAll('#tabs button').forEach((b) => { b.textContent = S.tabs[b.dataset.tab]; });
    document.title = S.title;
    renderDays($('schDays'), data.workSchedule.days, (days) => save({ workSchedule: Object.assign({}, data.workSchedule, { days }) }));
    renderReminders();
    renderPets();
  }

  const DAY_KEYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  function renderDays(container, selected, onChange) {
    container.innerHTML = '';
    [1, 2, 3, 4, 5, 6, 0].forEach((d) => {
      const l = document.createElement('label');
      const i = document.createElement('input'); i.type = 'checkbox'; i.checked = selected.includes(d);
      const s = document.createElement('span'); s.textContent = S[DAY_KEYS[d]];
      i.addEventListener('change', () => {
        const days = [...container.querySelectorAll('input')].map((inp, idx) => inp.checked ? [1, 2, 3, 4, 5, 6, 0][idx] : null).filter((v) => v !== null);
        onChange(days);
      });
      l.append(i, s); container.appendChild(l);
    });
  }

  /* ---------- tabs ---------- */
  function showTab(name) {
    document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
    document.querySelectorAll('.page').forEach((p) => p.classList.toggle('active', p.dataset.page === name));
  }
  document.querySelectorAll('#tabs button').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.tab)));
  showTab((location.hash || '#cat').slice(1));
  api.on('settings:tab', (t) => showTab(t));
  api.on('settings:changed', (d) => { data = d; fillForm(); });

  /* ---------- save ---------- */
  let savedTimer;
  async function save(partial) {
    data = await api.setSettings(partial);
    $('saved').classList.add('show');
    clearTimeout(savedTimer); savedTimer = setTimeout(() => $('saved').classList.remove('show'), 1200);
  }

  /* ---------- form ---------- */
  function fillForm() {
    $('size').value = data.size; $('size-out').textContent = data.size + ' px';
    $('speed').value = data.speed; $('speed-out').textContent = Number(data.speed).toFixed(1) + '×';
    $('activity').value = data.activity;
    $('followMouse').checked = data.followMouse;
    $('rubWindows').checked = data.rubWindows !== false;
    $('rubScreenEdges').checked = data.rubScreenEdges !== false;
    $('climbWindows').checked = data.climbWindows !== false;
    $('playFolders').checked = data.playFolders !== false;
    $('butterfly').checked = data.butterfly !== false;
    $('sounds').checked = data.sounds;
    $('bubbleSeconds').value = data.bubbleSeconds;
    $('nightEnabled').checked = data.nightEnabled;
    $('nightStart').value = data.nightStart; $('nightEnd').value = data.nightEnd;
    $('night-times').hidden = !data.nightEnabled;
    $('reduceMotion').checked = data.reduceMotion;
    $('workMode').checked = data.workMode;
    $('workBehavior').value = data.workBehavior;
    $('workCorner').value = data.workCorner;
    $('workOpacity').value = data.workOpacity; $('workOpacity-out').textContent = Math.round(data.workOpacity * 100) + ' %';
    const q = data.quiet || { enabled: false, from: '21:00', to: '08:00' }, pm = data.pomodoro || { work: 25, brk: 5 }, sm = data.summary || { enabled: true, at: '17:30' };
    $('quietEnabled').checked = !!q.enabled; $('quietFrom').value = q.from || '21:00'; $('quietTo').value = q.to || '08:00';
    $('pomoWork').value = pm.work || 25; $('pomoBreak').value = pm.brk || 5;
    $('summaryEnabled').checked = sm.enabled !== false; $('summaryAt').value = sm.at || '17:30';
    $('sitActive').checked = data.sitActive !== false;
    $('schEnabled').checked = data.workSchedule.enabled;
    $('schFrom').value = data.workSchedule.from; $('schTo').value = data.workSchedule.to;
    $('lang').value = data.lang;
    $('launchAtLogin').checked = data.launchAtLogin;
    $('version').textContent = state.version;
  }

  const bind = (id, key, parse, after) => {
    const el = $(id);
    el.addEventListener(el.type === 'range' || el.type === 'text' || el.type === 'number' ? 'input' : 'change', () => {
      const v = parse ? parse(el) : el.value;
      if (after) after(v);
      save({ [key]: v });
    });
  };
  bind('size', 'size', (el) => Number(el.value), (v) => $('size-out').textContent = v + ' px');
  bind('speed', 'speed', (el) => Number(el.value), (v) => $('speed-out').textContent = v.toFixed(1) + '×');
  bind('activity', 'activity');
  bind('followMouse', 'followMouse', (el) => el.checked);
  bind('rubWindows', 'rubWindows', (el) => el.checked);
  bind('rubScreenEdges', 'rubScreenEdges', (el) => el.checked);
  (async () => {
    try {
      const info = await api.updateInfo();
      $('update-info').textContent = '';
    } catch (e) {}
  })();
  const showUpd = (st) => {
    if (!st) return;
    const t = (S.updStatus[st.status] || '').replace('{v}', st.latest || '').replace('{p}', Math.round((st.progress || 0) * 100)).replace('{e}', st.error || '');
    $('upd-status').textContent = t;
    $('upd-install').hidden = st.status !== 'available';
    $('upd-install').textContent = S.updInstall.replace('{v}', st.latest || '');
    $('upd-check').disabled = st.status === 'checking' || st.status === 'downloading' || st.status === 'installing';
  };
  api.updateState().then(showUpd).catch(() => {});
  api.on('update:state', showUpd);
  $('upd-check').addEventListener('click', async () => showUpd(await api.updateCheck()));
  $('upd-install').addEventListener('click', () => { $('upd-install').disabled = true; api.updateInstall(); });
  $('autoUpdate').checked = data.autoUpdate !== false;
  api.updateState().then((st) => { $('updateRepo').value = (st && st.repo) || ''; }).catch(() => {});
  $('updateRepo').addEventListener('change', async () => {
    // accepts "owner/repo" or a github.com link
    const v = $('updateRepo').value.trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/i, '').replace(/\/+$/, '');
    $('updateRepo').value = v;
    await save({ updateRepo: v });
  });
  bind('autoUpdate', 'autoUpdate', (el) => el.checked);
  const showDiag = async () => {
    try {
      const d = await api.diag();
      $('diag').textContent = S.diag.replace('{w}', d.windows).replace('{e}', d.edges).replace('{c}', d.clicks ? S.yes : S.no);
      $('mac-wallpaper').hidden = !d.mac;
    } catch (e) {}
  };
  showDiag(); setInterval(showDiag, 4000);
  $('update-btn').addEventListener('click', async () => {
    $('update-status').textContent = '…';
    const res = await api.updateFromZip();
    $('update-status').textContent = res.ok ? S.updateDone.replace('{n}', res.files) : (res.reason === 'cancelled' ? '' : S.updateFailed + ' ' + res.reason);
  });
  bind('climbWindows', 'climbWindows', (el) => el.checked);
  bind('playFolders', 'playFolders', (el) => el.checked);
  bind('butterfly', 'butterfly', (el) => el.checked);
  bind('sounds', 'sounds', (el) => el.checked);
  bind('bubbleSeconds', 'bubbleSeconds', (el) => Math.max(3, Number(el.value) || 12));
  bind('nightEnabled', 'nightEnabled', (el) => el.checked, (v) => $('night-times').hidden = !v);
  bind('nightStart', 'nightStart', (el) => Math.min(23, Math.max(0, Number(el.value) || 0)));
  bind('nightEnd', 'nightEnd', (el) => Math.min(23, Math.max(0, Number(el.value) || 0)));
  bind('reduceMotion', 'reduceMotion', (el) => el.checked);
  bind('workMode', 'workMode', (el) => el.checked);
  bind('workBehavior', 'workBehavior');
  bind('workCorner', 'workCorner');
  bind('workOpacity', 'workOpacity', (el) => Number(el.value), (v) => $('workOpacity-out').textContent = Math.round(v * 100) + ' %');
  const nested = (key, field, el, get) => el.addEventListener('change', () => save({ [key]: Object.assign({}, data[key] || {}, { [field]: get(el) }) }));
  nested('quiet', 'enabled', $('quietEnabled'), (el) => el.checked);
  nested('quiet', 'from', $('quietFrom'), (el) => el.value || '21:00');
  nested('quiet', 'to', $('quietTo'), (el) => el.value || '08:00');
  nested('pomodoro', 'work', $('pomoWork'), (el) => Math.max(1, Number(el.value) || 25));
  nested('pomodoro', 'brk', $('pomoBreak'), (el) => Math.max(1, Number(el.value) || 5));
  nested('summary', 'enabled', $('summaryEnabled'), (el) => el.checked);
  nested('summary', 'at', $('summaryAt'), (el) => el.value || '17:30');
  bind('sitActive', 'sitActive', (el) => el.checked);
  $('schEnabled').addEventListener('change', () => save({ workSchedule: Object.assign({}, data.workSchedule, { enabled: $('schEnabled').checked }) }));
  $('schFrom').addEventListener('change', () => save({ workSchedule: Object.assign({}, data.workSchedule, { from: $('schFrom').value || '09:00' }) }));
  $('schTo').addEventListener('change', () => save({ workSchedule: Object.assign({}, data.workSchedule, { to: $('schTo').value || '17:00' }) }));
  $('launchAtLogin').addEventListener('change', () => save({ launchAtLogin: $('launchAtLogin').checked }));
  $('lang').addEventListener('change', async () => {
    await save({ lang: $('lang').value });
    state = await api.getSettings(); data = state.data; applyStrings(); fillForm();
  });
  $('close').addEventListener('click', () => api.closeWindow());

  /* ---------- reminders ---------- */
  function renderReminders() {
    const list = $('rem-list'); list.innerHTML = '';
    const rems = data.reminders || [];
    $('rem-empty').hidden = rems.length > 0;
    rems.forEach((r) => list.appendChild(reminderRow(r)));
  }

  function saveReminders() { save({ reminders: data.reminders }); }

  const ACTIONS = ['none', 'come', 'hop', 'leap', 'sit', 'sleep', 'belly', 'rub', 'folder', 'climb'];
  function reminderRow(r) {
    const row = document.createElement('div');
    row.className = 'rem' + (r.enabled ? '' : ' off');
    const en = document.createElement('input'); en.type = 'checkbox'; en.checked = !!r.enabled; en.title = S.remEnabled;
    en.addEventListener('change', () => { r.enabled = en.checked; row.classList.toggle('off', !r.enabled); saveReminders(); });
    const main = document.createElement('div'); main.className = 'line main';
    const text = document.createElement('input'); text.type = 'text'; text.value = r.text || ''; text.placeholder = S.remText;
    let t; text.addEventListener('input', () => { r.text = text.value; clearTimeout(t); t = setTimeout(saveReminders, 400); });
    main.appendChild(text);

    // when: every N minutes | at a time on given days | after N minutes of work without a break
    const when = document.createElement('div'); when.className = 'line';
    const whenL = document.createElement('span'); whenL.className = 'lbl'; whenL.textContent = S.remWhen + ':';
    const kind = document.createElement('select');
    kind.innerHTML = `<option value="interval">${S.remEvery}</option><option value="time">${S.remAt}</option><option value="work">${S.remWork}</option>`;
    kind.value = ['time', 'work'].includes(r.kind) ? r.kind : 'interval';
    const every = document.createElement('input'); every.type = 'number'; every.min = 1; every.max = 720; every.value = r.every || (r.kind === 'work' ? 50 : 45);
    const everyUnit = document.createElement('span'); everyUnit.textContent = S.minutes;
    const at = document.createElement('input'); at.type = 'time'; at.value = r.at || '10:00'; at.step = 60;
    const days = document.createElement('span'); days.className = 'days';
    const workHint = document.createElement('small'); workHint.className = 'hint'; workHint.textContent = S.remWorkHint;
    const refresh = () => {
      const k = kind.value;
      every.hidden = k === 'time'; everyUnit.hidden = k === 'time'; everyUnit.textContent = k === 'work' ? S.minutesWork : S.minutes;
      at.hidden = k !== 'time'; days.hidden = k !== 'time'; workHint.hidden = k !== 'work';
    };
    kind.addEventListener('change', () => { r.kind = kind.value; refresh(); saveReminders(); });
    every.addEventListener('change', () => { r.every = Math.max(1, Number(every.value) || 45); saveReminders(); });
    at.addEventListener('change', () => { r.at = at.value || '10:00'; saveReminders(); });
    r.days = Array.isArray(r.days) ? r.days : [1, 2, 3, 4, 5, 6, 0];
    renderDays(days, r.days, (d) => { r.days = d; saveReminders(); });
    when.append(whenL, kind, every, everyUnit, at, days, workHint);

    // what the cat does
    const act = document.createElement('div'); act.className = 'line';
    const actL = document.createElement('span'); actL.className = 'lbl'; actL.textContent = S.remAction + ':';
    const action = document.createElement('select');
    action.innerHTML = ACTIONS.map((a) => `<option value="${a}">${S.actions[a]}</option>`).join('');
    action.value = ACTIONS.includes(r.action) ? r.action : 'none';
    action.addEventListener('change', () => { r.action = action.value; saveReminders(); });
    const imp = document.createElement('label'); imp.className = 'chk';
    const impI = document.createElement('input'); impI.type = 'checkbox'; impI.checked = !!r.important;
    impI.addEventListener('change', () => { r.important = impI.checked; saveReminders(); });
    imp.append(impI, document.createTextNode(S.remImportant));
    const test = document.createElement('button'); test.type = 'button'; test.className = 'btn small'; test.textContent = S.test;
    test.addEventListener('click', () => api.testReminder({ text: r.text, important: r.important, action: r.action }));
    const del = document.createElement('button'); del.type = 'button'; del.className = 'btn small'; del.textContent = S.remove;
    del.addEventListener('click', () => { data.reminders = data.reminders.filter((x) => x !== r); saveReminders(); renderReminders(); });
    act.append(actL, action, imp, test, del);
    refresh();
    row.append(en, main, when, act);
    return row;
  }

  $('rem-add').addEventListener('click', () => {
    data.reminders = data.reminders || [];
    data.reminders.push({ id: 'r' + Date.now(), text: '', kind: 'interval', every: 45, at: '10:00', days: [1, 2, 3, 4, 5], important: false, enabled: true, action: 'none' });
    saveReminders(); renderReminders();
    const inputs = $('rem-list').querySelectorAll('input[type="text"]'); if (inputs.length) inputs[inputs.length - 1].focus();
  });

  /* ---------- pets ---------- */
  function renderPets() {
    const list = $('pet-list'); list.innerHTML = '';
    state.pets.forEach((p) => {
      const row = document.createElement('label'); row.className = 'pet';
      const radio = document.createElement('input'); radio.type = 'radio'; radio.name = 'pet'; radio.value = p.id; radio.checked = p.id === data.pet;
      radio.addEventListener('change', () => save({ pet: p.id }));
      const img = document.createElement('img'); img.alt = ''; const f = p.meta.thumb ? { file: p.meta.thumb } : (p.meta.frames && (p.meta.frames.sit || p.meta.frames.walk1)); if (f) img.src = p.baseUrl + f.file;
      const name = document.createElement('span'); name.textContent = p.name;
      const sp = document.createElement('span'); sp.className = 'sp';
      row.append(radio, img, name, sp);
      if (p.builtIn) { const tag = document.createElement('span'); tag.className = 'tag'; tag.textContent = S.builtIn; row.appendChild(tag); }
      else {
        const del = document.createElement('button'); del.type = 'button'; del.className = 'btn small'; del.textContent = S.petDelete;
        del.addEventListener('click', async (e) => { e.preventDefault(); state.pets = await api.deletePet(p.id); state = await api.getSettings(); data = state.data; renderPets(); });
        row.appendChild(del);
      }
      list.appendChild(row);
    });
  }
  $('pet-folder').addEventListener('click', () => api.openPetsFolder());

  // sprite sheet import
  const FRAME_NAMES = ['walk1', 'walk2', 'walk3', 'walk4', 'sit', 'sleep', 'groom', 'stretch', 'jump'];
  let importResult = null;
  $('pet-file').addEventListener('change', async () => {
    const file = $('pet-file').files[0]; if (!file) return;
    $('pet-status').textContent = '…'; $('pet-save').disabled = true; $('pet-preview').innerHTML = ''; importResult = null;
    try {
      const bmp = await createImageBitmap(file);
      const frames = splitSheet(bmp);
      $('pet-status').textContent = S.petFound + ': ' + frames.length + (frames.length === 8 || frames.length === 9 ? '' : ' – ' + S.petNeed);
      frames.forEach((f) => { const im = document.createElement('img'); im.src = f.dataUrl; im.title = f.name || ''; $('pet-preview').appendChild(im); });
      if (frames.length === 8 || frames.length === 9) {
        frames.forEach((f, i) => f.name = FRAME_NAMES[i]);
        const baseHeight = Math.round(frames.slice(0, 4).reduce((a, f) => a + f.h, 0) / 4);
        importResult = { frames, baseHeight };
        $('pet-save').disabled = false;
      }
    } catch (e) { $('pet-status').textContent = String(e.message || e); }
  });

  $('pet-save').addEventListener('click', async () => {
    if (!importResult) return;
    const name = $('pet-name').value.trim() || 'Cat';
    $('pet-save').disabled = true;
    const res = await api.importPet({ name, frames: importResult.frames, baseHeight: importResult.baseHeight });
    state = await api.getSettings(); data = state.data;
    renderPets();
    $('pet-status').textContent = S.petSaved;
    $('pet-preview').innerHTML = ''; $('pet-file').value = ''; importResult = null;
    await save({ pet: res.id }); renderPets();
  });

  /** Split a transparent sprite sheet into connected blobs, left to right. */
  function splitSheet(bmp) {
    const W = bmp.width, H = bmp.height;
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const ctx = c.getContext('2d', { willReadFrequently: true }); ctx.drawImage(bmp, 0, 0);
    const px = ctx.getImageData(0, 0, W, H).data;
    const mask = new Uint8Array(W * H);
    for (let i = 0, j = 3; i < W * H; i++, j += 4) mask[i] = px[j] > 64 ? 1 : 0;
    const label = new Int32Array(W * H);
    const comps = [];
    const stack = new Int32Array(W * H);
    for (let start = 0; start < W * H; start++) {
      if (!mask[start] || label[start]) continue;
      const id = comps.length + 1;
      let sp = 0, size = 0, x0 = W, x1 = 0, y0 = H, y1 = 0;
      stack[sp++] = start; label[start] = id;
      while (sp) {
        const p = stack[--sp]; size++;
        const x = p % W, y = (p - x) / W;
        if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
        if (x > 0 && mask[p - 1] && !label[p - 1]) { label[p - 1] = id; stack[sp++] = p - 1; }
        if (x < W - 1 && mask[p + 1] && !label[p + 1]) { label[p + 1] = id; stack[sp++] = p + 1; }
        if (y > 0 && mask[p - W] && !label[p - W]) { label[p - W] = id; stack[sp++] = p - W; }
        if (y < H - 1 && mask[p + W] && !label[p + W]) { label[p + W] = id; stack[sp++] = p + W; }
      }
      comps.push({ id, size, x0, x1, y0, y1, members: [id] });
    }
    if (!comps.length) throw new Error('empty image');
    const maxSize = Math.max(...comps.map((c) => c.size));
    const big = comps.filter((c) => c.size >= maxSize * 0.08).sort((a, b) => a.x0 - b.x0);
    const small = comps.filter((c) => c.size < maxSize * 0.08);
    // attach small bits (whiskers, dots) to the nearest big blob
    const pad = Math.round(W * 0.02);
    for (const s of small) {
      const cx = (s.x0 + s.x1) / 2, cy = (s.y0 + s.y1) / 2;
      let best = null, bd = Infinity;
      for (const b of big) {
        const dx = Math.max(b.x0 - pad - cx, 0, cx - (b.x1 + pad)), dy = Math.max(b.y0 - pad - cy, 0, cy - (b.y1 + pad));
        const d = Math.hypot(dx, dy); if (d < bd) { bd = d; best = b; }
      }
      if (best && bd === 0) { best.members.push(s.id); best.x0 = Math.min(best.x0, s.x0); best.x1 = Math.max(best.x1, s.x1); best.y0 = Math.min(best.y0, s.y0); best.y1 = Math.max(best.y1, s.y1); }
    }
    return big.map((b) => {
      const w = b.x1 - b.x0 + 1, h = b.y1 - b.y0 + 1;
      const out = document.createElement('canvas'); out.width = w + 4; out.height = h + 4;
      const octx = out.getContext('2d');
      const img = octx.createImageData(w, h);
      const members = new Set(b.members);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        const p = (b.y0 + y) * W + (b.x0 + x);
        if (!members.has(label[p])) continue;
        const si = p * 4, di = (y * w + x) * 4;
        img.data[di] = px[si]; img.data[di + 1] = px[si + 1]; img.data[di + 2] = px[si + 2]; img.data[di + 3] = px[si + 3];
      }
      octx.putImageData(img, 2, 2);
      return { w: w + 4, h: h + 4, dataUrl: out.toDataURL('image/png') };
    });
  }

  /* ---------- go ---------- */
  applyStrings();
  fillForm();
})();
