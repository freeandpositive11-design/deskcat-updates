/* UI strings (Slovak + English). Used by the main process (tray menu) and the settings window. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.I18N = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const sk = {
    appName: 'Mačka na ploche',
    tray: {
      show: 'Ukázať mačku', hide: 'Schovať mačku', work: 'Pracovný režim', callHere: 'Zavolať ku kurzoru',
      sleep: 'Choď spať', reminders: 'Pripomienky…', settings: 'Nastavenia…', launch: 'Spustiť po prihlásení', quit: 'Ukončiť',
      pomoStart: 'Pomodoro: začať', pomoStop: 'Pomodoro: zastaviť', summary: 'Dnešný súhrn',
      updateInstall: '⬆︎ Nainštalovať aktualizáciu {v}', updateBubble: 'Je tu nová verzia {v} 🐾 Nainštaluješ ju v menu alebo v Nastaveniach.',
      shortcut: 'Skratka: ⌃⇧M schová / ukáže'
    },
    ctx: { pet: 'Pohladkať', sleep: 'Choď spať', wake: 'Zobuď sa', work: 'Pracovný režim', hide: 'Schovať (⌃⇧M ukáže)', settings: 'Nastavenia…' },
    settings: {
      title: 'Nastavenia', tabs: { cat: 'Mačka', work: 'Pracovný režim', reminders: 'Pripomienky', pets: 'Mačky', general: 'Všeobecné' },
      name: 'Meno', size: 'Veľkosť', speed: 'Rýchlosť', activity: 'Aktivita', activityHint: 'Ako často sa hýbe',
      calm: 'Pokojná', normal: 'Normálna', playful: 'Hravá', follow: 'Ide tam, kam klikneš', followHint: 'Klikni kdekoľvek na ploche a príde tam; klikni na okno a vylezie naň (okno musí siahať dole). Ostane tam pár minút.',
      rubWindows: 'Obtiera sa o okná', rubWindowsHint: 'O bočnú hranu okna, ktoré siaha až dole k nej', rubScreenEdges: 'Obtiera sa aj o okraj obrazovky', climbWindows: 'Šplhá sa na okná', climbWindowsHint: 'Po ľavej hrane okna, ktoré siaha až dole, vylezie na jeho vrch', playFolders: 'Hrá sa s priečinkami na ploche', playFoldersHint: 'Len s ikonami pri spodnom okraji (na Macu sa opýta na prístup k Finderu)', butterfly: 'Naháňa motýľa', sounds: 'Zvuky', soundsHint: 'Tiché mrnknutie a cinknutie pri pripomienke',
      bubbleSeconds: 'Bežná pripomienka zmizne po', seconds: 's',
      workOn: 'Pracovný režim je zapnutý', workBehavior: 'Keď pracuješ', workSleep: 'Spí v rohu', workHide: 'Úplne sa schová', corner: 'Roh', left: 'Vľavo', right: 'Vpravo',
      workOpacity: 'Priehľadnosť v rohu', schedule: 'Zapínať podľa času', from: 'Od', to: 'Do', days: 'Dni',
      workNote: 'V pracovnom režime ťa vyruší iba pripomienka označená ako dôležitá.',
      remText: 'Text', remWhen: 'Kedy', remAt: 'O čase', remEvery: 'Každých', remWork: 'Po práci bez prestávky', minutes: 'min', minutesWork: 'min práce', remImportant: 'Dôležitá', remEnabled: 'Zapnutá',
      remWorkHint: 'Počíta sa čas, keď píšeš alebo hýbeš myšou; prestávka = 5 minút bez aktivity.', remAction: 'Mačka pri tom',
      actions: { none: 'len pozrie na teba', come: 'príde ku kurzoru', hop: 'poskočí', leap: 'vyskočí', sit: 'sadne si', sleep: 'ľahne si a spí', belly: 'vyvalí sa na chrbát', rub: 'obtrie sa o okno', folder: 'ide k priečinku', climb: 'vylezie na okno' },
      quiet: 'Tiché hodiny', quietHint: 'Mačka len odpočíva a nevyrušuje; prídu iba dôležité pripomienky.', quietFrom: 'Od', quietTo: 'Do',
      pomodoro: 'Pomodoro', pomodoroHint: 'Spúšťa sa z menu v lište. Pri mačke beží malý odpočet; na konci príde s prestávkou.', pomoWork: 'Práca (min)', pomoBreak: 'Prestávka (min)',
      summaryOn: 'Denný súhrn', summaryHint: 'Koľko si dnes pracovala a koľko bolo prestávok; aj z menu v lište.', summaryAt: 'Povie ho o',
      sitActive: 'Sadne si na okno, v ktorom píšeš', sitActiveHint: 'Občas vylezie na vrch aktívneho okna (musí siahať dole a mať voľnú ľavú hranu). Na Macu sa systém raz opýta na prístupnosť.',
      diag: 'Mačka vidí okien: {w} (siaha dole: {e}) · sleduje kliknutia: {c}', yes: 'áno', no: 'nie',
      macWallpaper: 'Mac: aby sa okná pri kliknutí na plochu neodsúvali nabok, v Systémových nastaveniach → Plocha a Dock prepni „Kliknutím na tapetu zobraziť plochu“ na „Iba v Stage Manageri“.',
      update: 'Aktualizácia', updateBtn: 'Nainštalovať z .zip…', updCheck: 'Vyhľadať aktualizácie', updInstall: 'Aktualizovať na {v}', updAuto: 'Kontrolovať automaticky (raz za deň)', updRepo: 'Zdroj aktualizácií', updRepoHint: 'GitHub repozitár (meno/repo) s vydaniami',
      updStatus: { idle: '', checking: 'Hľadám…', uptodate: 'Máš najnovšiu verziu.', available: 'Je dostupná verzia {v}.', downloading: 'Sťahujem… {p} %', installing: 'Inštalujem…', restarting: 'Hotovo, appka sa reštartuje…', error: 'Nepodarilo sa: {e}', nosource: 'Zdroj aktualizácií nie je nastavený.' },
      updZipHint: 'Bez internetu: balík .zip, ktorý ti niekto pošle.', updatePackaged: 'Inštalovaná verzia: aktualizuj spustením nového inštalátora.', updateUnpacked: 'Vyber balík .zip, súbory sa skopírujú do {dir} a appka sa reštartuje.', updateDone: 'Hotovo – skopírovaných {n} súborov, appka sa reštartuje.', updateFailed: 'Nepodarilo sa:',
      add: 'Pridať pripomienku', remove: 'Odstrániť', test: 'Vyskúšať', remEmpty: 'Zatiaľ žiadne pripomienky. Pridaj napríklad „Napi sa vody“ každých 45 minút.',
      remImportantHint: 'Dôležitá pripomienka ostane, kým ju nezavrieš, a zobrazí sa aj v pracovnom režime.',
      petChoose: 'Aktívna mačka', petImport: 'Pridať mačku zo sprite sheetu', petImportHint: 'PNG s priehľadným pozadím a pózami v jednom rade v poradí: 4× chôdza, sedenie, spánok, umývanie, natiahnutie (voliteľne 9. skok). Presne podľa zadania pre ChatGPT.',
      petName: 'Meno novej mačky', petFile: 'Vybrať PNG…', petSave: 'Uložiť mačku', petFound: 'Nájdených póz', petNeed: 'Treba 8 alebo 9 póz.', petSaved: 'Mačka uložená. Vyber ju vyššie.',
      petFolder: 'Otvoriť priečinok s mačkami', petDelete: 'Odstrániť', builtIn: 'vstavaná',
      language: 'Jazyk', launch: 'Spustiť po prihlásení', shortcutInfo: 'Skratka ⌃⇧M (Ctrl+Shift+M) mačku schová alebo ukáže.',
      night: 'Nočný režim (viac spí)', nightFrom: 'Od', nightTo: 'Do', reduceMotion: 'Menej animácií',
      save: 'Uložiť', saved: 'Uložené', close: 'Zavrieť', mon: 'Po', tue: 'Ut', wed: 'St', thu: 'Št', fri: 'Pi', sat: 'So', sun: 'Ne',
      version: 'Verzia'
    },
    defaultReminders: [
      { text: 'Napi sa vody 💧', kind: 'interval', every: 45, important: false, enabled: true, action: 'hop' },
      { text: 'Daj si prestávku, natiahni sa 🐈', kind: 'work', every: 50, important: false, enabled: true, action: 'come' }
    ],
    pomodoro: { workEnd: 'Prestávka! ☕', breakEnd: 'Späť do práce 💪', work: 'práca', brk: 'prestávka' },
    summaryWords: { today: 'Dnes', work: 'práce', breaks: ['prestávka', 'prestávky', 'prestávok'], pomo: 'pomodoro' },
  };
  const en = {
    appName: 'Desk Cat',
    tray: {
      show: 'Show cat', hide: 'Hide cat', work: 'Work mode', callHere: 'Call to cursor',
      sleep: 'Go to sleep', reminders: 'Reminders…', settings: 'Settings…', launch: 'Launch at login', quit: 'Quit',
      pomoStart: 'Pomodoro: start', pomoStop: 'Pomodoro: stop', summary: "Today's summary",
      updateInstall: '⬆︎ Install update {v}', updateBubble: 'Version {v} is out 🐾 Install it from the menu or in Settings.',
      shortcut: 'Shortcut: ⌃⇧M hides / shows'
    },
    ctx: { pet: 'Pet', sleep: 'Go to sleep', wake: 'Wake up', work: 'Work mode', hide: 'Hide (⌃⇧M shows)', settings: 'Settings…' },
    settings: {
      title: 'Settings', tabs: { cat: 'Cat', work: 'Work mode', reminders: 'Reminders', pets: 'Cats', general: 'General' },
      name: 'Name', size: 'Size', speed: 'Speed', activity: 'Activity', activityHint: 'How often it moves',
      calm: 'Calm', normal: 'Normal', playful: 'Playful', follow: 'Goes where you click', followHint: 'Click anywhere on the desktop and she comes there; click a window and she climbs onto it (it must reach the bottom). She stays a few minutes.',
      rubWindows: 'Rubs against windows', rubWindowsHint: 'Against the side edge of a window that reaches down to her', rubScreenEdges: 'Also rubs against the screen edges', climbWindows: 'Climbs onto windows', climbWindowsHint: 'Up the left edge of a window that reaches the floor, then sits on top', playFolders: 'Plays with desktop folders', playFoldersHint: 'Only icons near the bottom edge (macOS asks for Finder access)', butterfly: 'Chases a butterfly', sounds: 'Sounds', soundsHint: 'Soft chirp and a chime for reminders',
      bubbleSeconds: 'Normal reminder disappears after', seconds: 's',
      workOn: 'Work mode is on', workBehavior: 'While you work', workSleep: 'Sleeps in a corner', workHide: 'Hides completely', corner: 'Corner', left: 'Left', right: 'Right',
      workOpacity: 'Opacity in the corner', schedule: 'Turn on by schedule', from: 'From', to: 'To', days: 'Days',
      workNote: 'In work mode only reminders marked important will interrupt you.',
      remText: 'Text', remWhen: 'When', remAt: 'At time', remEvery: 'Every', remWork: 'After working without a break', minutes: 'min', minutesWork: 'min of work', remImportant: 'Important', remEnabled: 'Enabled',
      remWorkHint: 'Counts time while you type or move the mouse; a break = 5 minutes without activity.', remAction: 'The cat will',
      actions: { none: 'just look at you', come: 'come to the cursor', hop: 'hop', leap: 'leap up', sit: 'sit down', sleep: 'lie down and sleep', belly: 'roll onto her back', rub: 'rub against a window', folder: 'go to a folder', climb: 'climb onto a window' },
      quiet: 'Quiet hours', quietHint: 'The cat only rests and never interrupts; only important reminders come through.', quietFrom: 'From', quietTo: 'To',
      pomodoro: 'Pomodoro', pomodoroHint: 'Started from the tray menu. A small countdown runs next to the cat; she brings the break at the end.', pomoWork: 'Work (min)', pomoBreak: 'Break (min)',
      summaryOn: 'Daily summary', summaryHint: 'How long you worked today and how many breaks; also from the tray menu.', summaryAt: 'Tell it at',
      sitActive: 'Sits on the window you type in', sitActiveHint: 'Now and then climbs onto the active window (it must reach the floor with a free left edge). macOS asks once for Accessibility access.',
      diag: 'Windows the cat sees: {w} (reaching the bottom: {e}) · watches clicks: {c}', yes: 'yes', no: 'no',
      macWallpaper: 'Mac: so that windows do not slide away when you click the desktop, set System Settings → Desktop & Dock → “Click wallpaper to reveal desktop” to “Only in Stage Manager”.',
      update: 'Update', updateBtn: 'Install from .zip…', updCheck: 'Check for updates', updInstall: 'Update to {v}', updAuto: 'Check automatically (once a day)', updRepo: 'Update source', updRepoHint: 'GitHub repository (owner/repo) with releases',
      updStatus: { idle: '', checking: 'Checking…', uptodate: 'You have the latest version.', available: 'Version {v} is available.', downloading: 'Downloading… {p} %', installing: 'Installing…', restarting: 'Done, restarting…', error: 'Failed: {e}', nosource: 'No update source is set.' },
      updZipHint: 'Offline: a .zip package someone sends you.', updatePackaged: 'Installed build: update by running a newer installer.', updateUnpacked: 'Pick a .zip package; its files are copied into {dir} and the app restarts.', updateDone: 'Done – {n} files copied, restarting.', updateFailed: 'Failed:',
      add: 'Add reminder', remove: 'Remove', test: 'Test', remEmpty: 'No reminders yet. Add e.g. “Drink water” every 45 minutes.',
      remImportantHint: 'An important reminder stays until you close it and shows even in work mode.',
      petChoose: 'Active cat', petImport: 'Add a cat from a sprite sheet', petImportHint: 'PNG with transparent background, poses in one row in this order: 4× walk, sit, sleep, groom, stretch (optional 9th: jump).',
      petName: 'New cat name', petFile: 'Choose PNG…', petSave: 'Save cat', petFound: 'Poses found', petNeed: '8 or 9 poses required.', petSaved: 'Cat saved. Select it above.',
      petFolder: 'Open cats folder', petDelete: 'Delete', builtIn: 'built-in',
      language: 'Language', launch: 'Launch at login', shortcutInfo: 'Shortcut ⌃⇧M (Ctrl+Shift+M) hides or shows the cat.',
      night: 'Night mode (sleeps more)', nightFrom: 'From', nightTo: 'To', reduceMotion: 'Fewer animations',
      save: 'Save', saved: 'Saved', close: 'Close', mon: 'Mo', tue: 'Tu', wed: 'We', thu: 'Th', fri: 'Fr', sat: 'Sa', sun: 'Su',
      version: 'Version'
    },
    defaultReminders: [
      { text: 'Drink some water 💧', kind: 'interval', every: 45, important: false, enabled: true, action: 'hop' },
      { text: 'Take a break and stretch 🐈', kind: 'work', every: 50, important: false, enabled: true, action: 'come' }
    ],
    pomodoro: { workEnd: 'Break time! ☕', breakEnd: 'Back to work 💪', work: 'work', brk: 'break' },
    summaryWords: { today: 'Today', work: 'of work', breaks: ['break', 'breaks', 'breaks'], pomo: 'pomodoro' },
  };
  return { sk, en, get(lang) { return this[lang] || sk; } };
});
